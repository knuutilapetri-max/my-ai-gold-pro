
;

(() => {
"use strict";
// Binance provides crypto streams; BiQuote provides free multi-market ticks/OHLC where supported; Twelve Data is optional fallback.
let symbol="BTCUSDT", symbolMeta=null, availableSymbols=[];
let tdApiKey=sessionStorage.getItem("tdApiKeySession")||"", tdRefreshTimer=null, tdBusy=false, binanceBusy=false, binanceReconnectTimer=null, biquoteConnection=null, biquoteBusy=false, biquoteReconnectTimer=null, biquoteLastTick=null;
const TD_INTERVALS={"1m":"1min","5m":"5min","15m":"15min","30m":"30min","1h":"1h","4h":"4h","1d":"1day"};
const TD_REFRESH_MS=20*60*1000;
const paperKey=(kind)=>`goldProMulti_${symbol}_${kind}`;
const TF=[["1m","M1",0.04],["5m","M5",0.08],["15m","M15",0.18],["30m","M30",0.14],["1h","H1",0.20],["4h","H4",0.22],["1d","D1",0.14]];
const $=id=>document.getElementById(id);
let data={}, binanceCandles={}, biquoteCandles={}, lastSignal="HOLD", running=true, refreshTimer=null, fastTimer=null, refreshBusy=false, ws=null, lastPrice=null, eurusdt=1.1, lastAnalysis=null, notifyReady=false, alertState={}, alertPrimed=false;
let paperRunning=false,paperTrades=[],paperOpen=[],lastPaperBar=0;
const PAPER_BUDGET_EUR=10000, PAPER_RISK_PCT=2, PAPER_RISK_EUR=PAPER_BUDGET_EUR*PAPER_RISK_PCT/100;
let trackedPosition=null;
let entryWatchLast={BUY:null,SELL:null};
let entryWatchConfig={sides:[],tf:"5m"};
try{const oldWatch=JSON.parse(localStorage.getItem("goldProEntryWatch")||"null");if(oldWatch?.side)entryWatchLast[oldWatch.side]=oldWatch;const savedStates=JSON.parse(localStorage.getItem("goldProEntryWatchStates")||"null");if(savedStates)entryWatchLast={...entryWatchLast,...savedStates};}catch(e){}
try{entryWatchConfig=JSON.parse(localStorage.getItem("goldProEntryWatchConfig")||"null")||entryWatchConfig;}catch(e){}
if(!Array.isArray(entryWatchConfig.sides))entryWatchConfig.sides=entryWatchConfig.side? [entryWatchConfig.side] : [];
entryWatchConfig.sides=entryWatchConfig.sides.filter(x=>x==="BUY"||x==="SELL");

const fmt=(n,d=2)=>Number.isFinite(n)?n.toLocaleString("fi-FI",{minimumFractionDigits:d,maximumFractionDigits:d}):"--";
// Entry-näkymän hintatarkkuus: valuuttaparit näytetään täydellä käytännöllisellä tarkkuudella.
const isFxInstrument=()=>{
 const s=String(symbol||"").toUpperCase().replace(/[^A-Z]/g,"");
 return /^(OANDA)?(EURUSD|GBPUSD|AUDUSD|NZDUSD|USDCAD|USDCHF|USDJPY|EURJPY|GBPJPY|EURGBP|EURAUD|EURCHF|GBPCHF|AUDJPY|CADJPY|CHFJPY|NZDJPY)$/.test(s)
  || /(?:EURUSD|GBPUSD|AUDUSD|NZDUSD|USDCAD|USDCHF|USDJPY|EURJPY|GBPJPY|EURGBP|EURAUD|EURCHF|GBPCHF|AUDJPY|CADJPY|CHFJPY|NZDJPY)$/.test(s);
};
// Kaikki markkinahinnat, entryt ja tasot käyttävät instrumentin mukaan riittävää desimaalitarkkuutta.
const priceDecimalsForValue=(n)=>{
 const s=String(symbol||"").toUpperCase();
 if(isFxInstrument()) return s.includes("JPY")?3:5;
 const v=Math.abs(Number(n));
 if(!Number.isFinite(v)||v===0) return 2;
 // Pienihintaiset kryptot tarvitsevat enemmän desimaaleja kuin BTC/ETH.
 if(isBinanceSpot()||isBinancePerp()||/USDT|BTC|ETH|SOL|BNB|XRP|ADA|DOGE|DOT|AVAX|LINK/.test(s))
  return v>=10000?2:v>=1000?3:v>=1?4:v>=0.01?6:8;
 return 2;
};
const fmtEntryPrice=(n)=>fmt(Number(n),priceDecimalsForValue(n));

const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
async function getJSON(url){const r=await fetch(url,{cache:"no-store"});if(!r.ok)throw new Error("HTTP "+r.status+" "+url);return r.json()}
function ema(vals,p){if(vals.length<p)return NaN;let k=2/(p+1),e=vals.slice(0,p).reduce((a,b)=>a+b,0)/p;for(let i=p;i<vals.length;i++)e=vals[i]*k+e*(1-k);return e}
function rsi(vals,p=14){if(vals.length<=p)return 50;let g=0,l=0;for(let i=vals.length-p;i<vals.length;i++){let d=vals[i]-vals[i-1];if(d>0)g+=d;else l-=d}if(l===0)return 100;return 100-100/(1+g/l)}
function atr(c,p=14){if(c.length<=p)return 0;let tr=[];for(let i=1;i<c.length;i++)tr.push(Math.max(c[i].h-c[i].l,Math.abs(c[i].h-c[i-1].c),Math.abs(c[i].l-c[i-1].c)));return tr.slice(-p).reduce((a,b)=>a+b,0)/p}
function macd(vals){let a=ema(vals,12),b=ema(vals,26);let diffs=[];for(let i=25;i<vals.length;i++){let part=vals.slice(0,i+1);diffs.push(ema(part,12)-ema(part,26))}return {line:a-b,signal:ema(diffs,9),hist:(a-b)-ema(diffs,9)}}
function parseK(k){return {t:+k[0],o:+k[1],h:+k[2],l:+k[3],c:+k[4],v:+k[5]}}
function analyzeTF(candles){let c=candles.slice(0,-1);if(c.length<55)throw new Error("Liian vähän kynttilöitä");let close=c.map(x=>x.c),e20=ema(close,20),e50=ema(close,50),rr=rsi(close),m=macd(close),a=atr(c),last=c[c.length-1],prev=c[c.length-2],vavg=c.slice(-21,-1).reduce((s,x)=>s+x.v,0)/20,vol=last.v/(vavg||1),mom=close.at(-1)-close.at(-6),range20=c.slice(-21,-1),high=Math.max(...range20.map(x=>x.h)),low=Math.min(...range20.map(x=>x.l));
let trend=e20>e50*1.00005?"UP":e20<e50*0.99995?"DOWN":"SIDE";
let dir=0;if(trend==="UP")dir+=0.48;if(trend==="DOWN")dir-=0.48;if(last.c>e20)dir+=0.18;else dir-=0.18;if(m.hist>0)dir+=0.18;else dir-=0.18;if(rr>54)dir+=0.12;else if(rr<46)dir-=0.12;if(mom>0)dir+=0.10;else dir-=0.10;
return {trend,dir:clamp(dir,-1,1),rsi:rr,ema20:e20,ema50:e50,macd:m,atr:a,atrPct:a/last.c*100,volume:vol,close:last.c,high,low,breakUp:last.c>high,breakDown:last.c<low,momentum:mom,candles:c};
}
function patterns(tf){let c=tf.candles,last=c.at(-1),prev=c.at(-2),recent=c.slice(-12),body=Math.abs(last.c-last.o),range=Math.max(.00001,last.h-last.l),upper=last.h-Math.max(last.c,last.o),lower=Math.min(last.c,last.o)-last.l;
let vals=[
["Trend continuation",tf.trend!=="SIDE"&&Math.sign(tf.dir)===Math.sign(tf.momentum)?"Vahva":tf.trend!=="SIDE"?"Mahdollinen":"Heikko"],
["Breakout",tf.breakUp?"Ylös":tf.breakDown?"Alas":"Ei vahvistettu"],
["Pullback",tf.trend==="UP"&&last.c>tf.ema50&&last.c<tf.ema20?"Mahdollinen osto":tf.trend==="DOWN"&&last.c<tf.ema50&&last.c>tf.ema20?"Mahdollinen myynti":"Ei havaittu"],
["Reversal",(lower>body*1.8&&last.c>last.o)?"Bullish wick":(upper>body*1.8&&last.c<last.o)?"Bearish wick":"Ei vahvistettu"],
["Range bound",tf.trend==="SIDE"?"Mahdollinen":"Ei"],
["Volatility expansion",tf.atrPct>0.20?"Korkea":tf.atrPct>0.10?"Kohtalainen":"Matala"],
["Momentum surge",Math.abs(tf.momentum)/tf.close>0.0015?"Havaittu":"Ei havaittu"],
["Mean reversion",tf.rsi<30?"Yliostettu alas":tf.rsi>70?"Yliostettu ylös":"Neutraali"]
];return vals}
function weightedSignal(){
  let buy=0,sell=0,total=0,available=0;
  for(const [iv,label,w] of TF){
    const x=data[iv]; if(!x) continue;
    total+=w; available++;
    if(x.dir>0) buy+=w*x.dir; else sell+=w*(-x.dir);
  }
  const net=(buy-sell)/(total||1);
  const m15=data["15m"], h1=data["1h"], h4=data["4h"];
  if(!m15||!h1||!h4) return {signal:"HOLD",tier:"HEIKKO",riskFactor:0,conf:0,net,reason:"Kaikkia pääaikajaksoja ei ole vielä saatavilla."};
  const side=net>=0?"BUY":"SELL";
  const aligned=(x)=>side==="BUY"?x.dir>0:x.dir<0;
  const core=(aligned(m15)?1:0)+(aligned(h1)?1:0)+(aligned(h4)?1:0);
  const entryConfirm=(side==="BUY" ? m15.close>m15.ema20 && m15.macd.hist>0 : m15.close<m15.ema20 && m15.macd.hist<0);
  const opposing=available-(side==="BUY"?buy>0?supportCount(1):0:supportCount(-1));
  const strength=Math.abs(net);
  const conf=clamp(50+strength*45+(core/3)*10+(entryConfirm?7:0),50,95);
  let tier="HEIKKO",riskFactor=0,signal="HOLD";
  if(core>=2 && strength>=0.12 && entryConfirm){
    if(core===3 && strength>=0.30 && conf>=70){tier="VAHVA";riskFactor=1;signal=side;}
    else if(conf>=58){tier="KOHTALAINEN";riskFactor=0.5;signal=side;}
  } else if(core>=2 && strength>=0.18 && conf>=62){
    tier="KOHTALAINEN";riskFactor=0.5;signal=side;
  }
  const reason=tier==="VAHVA"?"Päätrendit ja sisääntulo vahvistavat samaa suuntaa.":tier==="KOHTALAINEN"?"Useimmat pääaikajaksot tukevat suuntaa, mutta vahvistus ei ole täydellinen.":"Vahvistus on liian heikko. Odota parempaa sisääntuloa.";
  return {signal,tier,riskFactor,conf,net,core,entryConfirm,reason};
}
function timeframeSignal(tf){
  if(!tf) return {signal:"HOLD",tier:"HEIKKO",riskFactor:0,conf:0,reason:"Aikajakson dataa ei ole saatavilla."};
  const side=tf.dir>=0?"BUY":"SELL";
  const confirm=side==="BUY" ? tf.close>tf.ema20 && tf.macd.hist>0 : tf.close<tf.ema20 && tf.macd.hist<0;
  const strength=Math.abs(tf.dir);
  const conf=clamp(50+strength*45+(confirm?10:0),0,95);
  if(!confirm || strength<0.20) return {signal:"HOLD",tier:"HEIKKO",riskFactor:0,conf,reason:"Tämän aikajakson suunta tai sisääntulon vahvistus ei vielä riitä."};
  if(strength>=0.58) return {signal:side,tier:"VAHVA",riskFactor:1,conf,reason:"Aikajakson trendi, EMA20 ja MACD tukevat samaa suuntaa."};
  return {signal:side,tier:"KOHTALAINEN",riskFactor:0.5,conf,reason:"Aikajakson suunta tukee kauppaa, mutta vahvistus on kohtalainen."};
}
function candleTimeframeMs(iv){return ({ "1m":60000,"5m":300000,"15m":900000,"30m":1800000,"1h":3600000,"4h":14400000,"1d":86400000 })[iv]||900000}
function countdownText(ms){
  if(ms<=0) return "Sulkeutuu juuri nyt";
  const s=Math.floor(ms/1000),h=Math.floor(s/3600),m=Math.floor((s%3600)/60),sec=s%60;
  return h>0?`${h} h ${m} min`:m>0?`${m} min ${sec} s`:`${sec} s`;
}
function supportCount(sign){return TF.reduce((n,[iv,,w])=>n+(data[iv]&&Math.sign(data[iv].dir)===sign?1:0),0)}

function toHeikinAshi(candles){
  const out=[];let prevOpen=null,prevClose=null;
  for(const k of candles){
    const haClose=(k.o+k.h+k.l+k.c)/4;
    const haOpen=prevOpen===null?(k.o+k.c)/2:(prevOpen+prevClose)/2;
    const haHigh=Math.max(k.h,haOpen,haClose),haLow=Math.min(k.l,haOpen,haClose);
    out.push({o:haOpen,h:haHigh,l:haLow,c:haClose});
    prevOpen=haOpen;prevClose=haClose;
  }
  return out;
}
function drawChart(c){
  const cv=$("chart"),ctx=cv.getContext("2d"),w=cv.width,h=cv.height;
  ctx.clearRect(0,0,w,h);if(!c||!c.length)return;
  const bars=toHeikinAshi(c.slice(-55)),padL=68,padR=12,padT=18,padB=18;
  const min=Math.min(...bars.map(x=>x.l)),max=Math.max(...bars.map(x=>x.h));
  const span=max-min||1,plotH=h-padT-padB,plotW=w-padL-padR;
  const y=v=>padT+(max-v)/span*plotH;
  ctx.font="15px system-ui";ctx.lineWidth=1;ctx.strokeStyle="#30394a";ctx.fillStyle="#9ba7ba";
  for(let i=0;i<=4;i++){const yy=padT+i*plotH/4,val=max-i*span/4;ctx.beginPath();ctx.moveTo(padL,yy);ctx.lineTo(w-padR,yy);ctx.stroke();ctx.fillText(fmtEntryPrice(val),4,yy+5)}
  const step=plotW/bars.length,bodyW=Math.max(3,step*.62);
  bars.forEach((b,i)=>{
    const x=padL+i*step+step/2,up=b.c>=b.o,color=up?"#35c98a":"#ff6475";
    ctx.strokeStyle=color;ctx.fillStyle=color;ctx.lineWidth=Math.max(1,step*.12);
    ctx.beginPath();ctx.moveTo(x,y(b.h));ctx.lineTo(x,y(b.l));ctx.stroke();
    const top=y(Math.max(b.o,b.c)),bottom=y(Math.min(b.o,b.c)),bh=Math.max(2,bottom-top);
    ctx.fillRect(x-bodyW/2,top,bodyW,bh);
  });
}

function candleTag(tf){
 const c=tf.candles, a=c.at(-1),b=c.at(-2);if(!a||!b)return "Ei kuviotietoa";
 const body=Math.abs(a.c-a.o),range=Math.max(a.h-a.l,1e-9),up=a.h-Math.max(a.o,a.c),dn=Math.min(a.o,a.c)-a.l;
 if(body/range<.12)return "Doji";
 if(dn>body*2&&up<body*.8&&a.c>a.o)return "Bullish hammer";
 if(up>body*2&&dn<body*.8&&a.c<b.o)return "Shooting star";
 if(a.c>a.o&&b.c<b.o&&a.o<=b.c&&a.c>=b.o)return "Bullish engulfing";
 if(a.c<a.o&&b.c>b.o&&a.o>=b.c&&a.c<=b.o)return "Bearish engulfing";
 return "Ei selvää kuviota";
}
function volatilityRatio(tf){
 const c=tf.candles;if(c.length<35)return null;
 const tr=(i)=>{const x=c[i],p=c[i-1];return Math.max(x.h-x.l,Math.abs(x.h-p.c),Math.abs(x.l-p.c))};
 const recent=Array.from({length:14},(_,k)=>tr(c.length-14+k)).reduce((a,b)=>a+b,0)/14;
 const prior=Array.from({length:14},(_,k)=>tr(c.length-28+k)).reduce((a,b)=>a+b,0)/14;
 return prior?recent/prior:1;
}

function startTrackedPosition(side){
 const price=Number(lastPrice||lastAnalysis?.price),iv=$("planTf")?.value||"15m",tf=data[iv];
 if(!Number.isFinite(price)||price<=0||!tf){$("positionTracker").textContent="Markkinadata ei ole saatavilla. Positiota ei aloitettu.";return}
 const entry=price,atrNow=tf.atr,slDist=Math.max(atrNow*1.5,entry*.0005);
 const sl=side==="BUY"?entry-slDist:entry+slDist;
 const capital=Math.max(1,Number($("capital").value)||500),riskPct=clamp(Number($("riskPct").value)||1,.1,5);
 const riskEUR=capital*riskPct/100,lev=clamp(Number($("leverage").value)||1,1,100);
 const riskUSDT=riskEUR*eurusdt,qtyByRisk=riskUSDT/slDist,qtyMax=capital*eurusdt*lev/entry;
 const requestedQty=Math.max(0,Number($("manualQty").value)||0);
 const qty=Math.min(requestedQty>0?requestedQty:qtyByRisk,qtyMax),notional=qty*entry,margin=notional/eurusdt/lev;
 const actualRiskEUR=qty*slDist/eurusdt;
 trackedPosition={side,entry,sl,qty,capital,lev,riskEUR:actualRiskEUR,margin,iv,openedAt:Date.now(),initialRisk:actualRiskEUR};
 try{localStorage.setItem("goldProTrackedPosition",JSON.stringify(trackedPosition));}catch(e){}
 updatePositionTracker();
}
function updatePositionTracker(){
 const el=$("positionTracker");if(!el)return;
 if(!trackedPosition){el.textContent="Ei seurattavaa positiota. Valitse BUY tai SELL, kun haluat aloittaa simuloidun seurannan. Tämä ei avaa eikä sulje oikeita toimeksiantoja.";return}
 const p=Number(lastPrice||lastAnalysis?.price),pos=trackedPosition;
 if(!Number.isFinite(p)){el.textContent="Odotetaan tuoretta markkinahintaa.";return}
 const pnlUSDT=(pos.side==="BUY"?(p-pos.entry):(pos.entry-p))*pos.qty;
 const pnlEUR=pnlUSDT/Math.max(eurusdt,1e-9);
 const adverse=pos.side==="BUY"?p<pos.entry:p>pos.entry;
 const moveAgainst=pos.side==="BUY"?pos.entry-p:p-pos.entry;
 const r=moveAgainst/Math.max(Math.abs(pos.entry-pos.sl),1e-9);
 const opp=Object.entries({"M5":"5m","M15":"15m","H1":"1h","H4":"4h"}).filter(([label,iv])=>data[iv]&&(pos.side==="BUY"?data[iv].dir<-.25:data[iv].dir>.25)).map(x=>x[0]);
 let hedge="Hedgeä ei vielä ehdoteta: seurataan hinnan ja aikajaksojen kehitystä.";
 if(adverse&&r>=.5&&opp.length>=2)hedge=`HEDGE-ARVIO: hinta on liikkunut positiota vastaan ${fmt(r,2)}R ja ${opp.join(", ")} tukevat vastakkaista suuntaa. Harkitse osittaista suojausta, esimerkiksi 25–50 % position koosta, mutta tarkista kulut, marginaali ja likvidointihinta.`;
 else if(adverse&&r>=.8)hedge="HEDGE-HUOMIO: tappio lähestyy 0,8R. Tarkista position riski ja harkitse osittaista suojausta tai position pienentämistä.";
 const cls=pnlEUR>=0?"positionPositive":"positionNegative";
 el.innerHTML=`<b>Seurattava ${pos.side}</b> · avattu ${new Date(pos.openedAt).toLocaleTimeString("fi-FI")}<br>Entry ${fmtEntryPrice(pos.entry)} · nykyhinta ${fmtEntryPrice(p)} · määrä ${fmt(pos.qty,4)} XAU<br>Arvioitu avoin tulos: <span class="${cls}">${pnlEUR>=0?"+":""}${fmt(pnlEUR,2)} €</span> · riski SL:ään ${fmt(pos.initialRisk,2)} €<br>SL ${fmtEntryPrice(pos.sl)} · vivun oletus ${pos.lev}x · marginaaliarvio ${fmt(pos.margin,2)} €<br><b>${hedge}</b><br><span class="tiny">Laskelma ei sisällä kaupankäyntikuluja, spreadiä, slippagea eikä funding-maksuja. Tämä on simuloitu seuranta, ei Binance-positio.</span>`;
}
function restoreTrackedPosition(){
 try{trackedPosition=JSON.parse(localStorage.getItem("goldProTrackedPosition")||"null");}catch(e){trackedPosition=null}
}
function endTrackedPosition(){
 trackedPosition=null;try{localStorage.removeItem("goldProTrackedPosition")}catch(e){}
 updatePositionTracker();
}
function updateMarketBrief(){
 const ids=["5m","15m","1h","4h"],labels={"5m":"M5","15m":"M15","1h":"H1","4h":"H4"};
 const available=ids.filter(iv=>data[iv]);
 if(available.length<4){$("briefHeadline").textContent="Odotetaan M5, M15, H1 ja H4 -markkinadataa.";return}
 const stats=ids.map(iv=>{
  const tf=data[iv],dir=tf.dir>=.25?"BUY":tf.dir<=-.25?"SELL":"HOLD";
  const breakout=tf.breakUp?"Breakout ↑":tf.breakDown?"Breakout ↓":"Ei breakoutia";
  const vol=volatilityRatio(tf),surge=Math.abs(tf.momentum)/Math.max(tf.atr,1e-9);
  const momentum=surge>=.65?"Voimakas":surge>=.35?"Kohtalainen":"Tavanomainen";
  const volText=Number.isFinite(vol)?(vol>=1.5?"Volatiliteetti kasvaa":vol<=.7?"Volatiliteetti laskee":"Volatiliteetti normaali"):"Volatiliteetti --";
  return {iv,tf,dir,breakout,vol,surge,momentum,volText,candle:candleTag(tf)};
 });
 $("briefGrid").innerHTML=stats.map(s=>{
  const cls=s.dir==="BUY"?"up":s.dir==="SELL"?"down":"flat";
  return `<div><small>${labels[s.iv]} · RSI ${fmt(s.tf.rsi,1)}</small><b class="${cls}">${s.dir}</b><div class="tiny">${s.breakout}</div><div class="tiny">${s.momentum} momentum</div><div class="tiny">${s.volText}</div></div>`;
 }).join("");
 const breaks=stats.filter(s=>s.tf.breakUp||s.tf.breakDown);
 const surges=stats.filter(s=>s.surge>=.65);
 const buy=stats.filter(s=>s.dir==="BUY").length,sell=stats.filter(s=>s.dir==="SELL").length;
 let headline="Ei vahvistettua merkittävää uutta tapahtumaa";
 if(breaks.length)headline="Breakout-havainto: "+breaks.map(s=>labels[s.iv]+" "+(s.tf.breakUp?"ylös":"alas")).join(", ");
 else if(surges.length)headline="Poikkeuksellisen voimakas momentum: "+surges.map(s=>labels[s.iv]).join(", ");
 else if(buy>=3)headline="BUY-asetelma vahvistuu usealla aikajaksolla";
 else if(sell>=3)headline="SELL-asetelma vahvistuu usealla aikajaksolla";
 $("briefHeadline").textContent=headline;
 const details=stats.map(s=>`${labels[s.iv]}: ${s.candle}; volyymi ${fmt(s.tf.volume,2)}x keskiarvoon; ${s.momentum.toLowerCase()} momentum; ${s.volText.toLowerCase()}.`).join(" ");
 $("briefDetails").textContent=details;
 const planIv=$("planTf")?.value||"15m",p=data[planIv],price=lastPrice||lastAnalysis?.price;
 if(p&&price){
  const side=p.dir>=.25?"BUY":p.dir<=-.25?"SELL":"HOLD";
  const entry=p.ema20,slDist=p.atr*1.5,sl=side==="BUY"?Math.min(p.low-p.atr*.15,entry-slDist):side==="SELL"?Math.max(p.high+p.atr*.15,entry+slDist):null;
  if(sl&&Number.isFinite(sl)){
   const r=Math.abs(entry-sl),targets=side==="BUY"?[entry+r,entry+2*r,entry+3*r]:[entry-r,entry-2*r,entry-3*r];
   $("briefLevels").textContent=`${planIv.toUpperCase()} ehdollinen ${side}: Entry-alue ${fmtEntryPrice(entry-p.atr*.15)}–${fmtEntryPrice(entry+p.atr*.15)} · SL ${fmtEntryPrice(sl)} · TP1 ${fmtEntryPrice(targets[0])} · TP2 ${fmtEntryPrice(targets[1])} · TP3 ${fmtEntryPrice(targets[2])}. Tarkista, ettei entry ole jo ohitettu.`;
  }else $("briefLevels").textContent=`${planIv.toUpperCase()}: HOLD. Ei riittävää suuntavahvistusta entry-suunnitelmalle.`;
 }
 $("briefHedge").textContent="Hedge: avoimen position suunta, koko ja vipu eivät ole tiedossa. Älä avaa suojausta pelkän markkinahavainnon perusteella.";
 $("briefUpdated").textContent="Päivitetty "+new Date().toLocaleTimeString("fi-FI")+" · päivitys 1 min välein";
}

function updateEntryWatch(side,lo,hi,sl,price,planIv){
 const key=side==="BUY"?"Buy":"Sell";
 const stateEl=$("entryWatch"+key+"State"),reasonEl=$("entryWatch"+key+"Reason");
 if(!stateEl||!reasonEl)return;
 const watchData=data[planIv];
 const set=(status,reason)=>{
  stateEl.textContent=status;
  stateEl.style.color=status==="VAHVISTUI"?"#35c98a":status==="MITÄTÖITY"||status==="MENI OHI"?"#ff6475":status==="ALUEELLA"?"#f0b84e":"#9ba7ba";
  $("entryWatch"+key+"Zone").textContent=Number.isFinite(lo)&&Number.isFinite(hi)?`${fmtEntryPrice(lo)} – ${fmtEntryPrice(hi)}`:"--";
  $("entryWatch"+key+"Price").textContent=Number.isFinite(price)?fmtEntryPrice(price):"--";
  reasonEl.textContent=reason;
  const prev=entryWatchLast[side]||{};
  if(prev.status!==status && prev.status && notifyReady && "Notification" in window && Notification.permission==="granted"){
   new Notification("MY AI GOLD PRO · "+side+" ENTRY "+status,{body:`${planIv.toUpperCase()} · alue ${fmtEntryPrice(lo)}–${fmtEntryPrice(hi)} · hinta ${fmtEntryPrice(price)}. ${reason}`});
  }
  entryWatchLast[side]={side,status,zoneLo:lo,zoneHi:hi,updatedAt:Date.now()};
  try{localStorage.setItem("goldProEntryWatchStates",JSON.stringify(entryWatchLast));}catch(e){}
 };
 if(!watchData||!Number.isFinite(lo)||!Number.isFinite(hi)){
  set("ODOTTAA","Odotetaan valitun aikajakson markkinadataa.");
  return;
 }
 const recent=watchData.candles.slice(-4);
 const touched=recent.some(c=>c.l<=hi&&c.h>=lo);
 const confirm=side==="BUY"
  ? recent.some(c=>c.l<=hi&&c.h>=lo&&c.c>c.o&&c.c>lo)
  : recent.some(c=>c.h>=lo&&c.l<=hi&&c.c<c.o&&c.c<hi);
 const invalid=side==="BUY"?(Number.isFinite(sl)&&price<=sl):(Number.isFinite(sl)&&price>=sl);
 const inZone=price>=lo&&price<=hi;
 if(invalid){
  set("MITÄTÖITY",`Hinta on rikkonut suunnitelman stop-tason ${fmtEntryPrice(sl)}. Vanhaa asetelmaa ei pidä käyttää.`);
 }else if(inZone){
  set("ALUEELLA",`Hinta on entry-alueella. Odota sulkeutunutta ${planIv.toUpperCase()}-kynttilää, joka vahvistaa suunnan.`);
 }else if(confirm && (side==="BUY"?price>hi:price<lo)){
  set("VAHVISTUI",`${planIv.toUpperCase()}-kynttilöissä näkyy entry-alueelta poistumisen suuntavahvistus. Tarkista silti tuore hinta, spread ja riskitaso.`);
 }else if(touched && (side==="BUY"?price>hi:price<lo)){
  set("MENI OHI","Hinta kävi entry-alueella mutta jatkoi sen ohi ilman tunnistettua sulkeutuneen kynttilän vahvistusta. Älä jahtaa liikettä.");
 }else{
  set("ODOTTAA",side==="BUY"?(price>hi?"Hinta on entry-alueen yläpuolella. Odotetaan mahdollista pullbackia.":"Hinta on entry-alueen alapuolella. Odotetaan rakenteen palautumista.")
   :(price<lo?"Hinta on entry-alueen alapuolella. Odotetaan mahdollista pullbackia.":"Hinta on entry-alueen yläpuolella. Odotetaan rakenteen palautumista."));
 }
}

function updateAssetSummary(a,p,planIv,planSignal){
 const box=$("assetSummaryContent"),stamp=$("assetSummaryUpdated");
 if(!box||!a)return;
 const chosen=$("assetSelect")?.selectedOptions?.[0]?.textContent?.trim()||symbol||"Valittu asset";
 const available=TF.map(([iv,label])=>({iv,label,tf:data[iv]})).filter(x=>x.tf);
 const up=available.filter(x=>x.tf.trend==="UP").map(x=>x.label);
 const down=available.filter(x=>x.tf.trend==="DOWN").map(x=>x.label);
 const side=planSignal?.signal||a.signal?.signal||"HOLD",tier=planSignal?.tier||a.signal?.tier||"HEIKKO",m=a.m15;
 const momentum=m.rsi>55?"nousupainotteinen":m.rsi<45?"laskupainotteinen":"neutraali";
 const volatility=m.atrPct>=0.8?"korkea":m.atrPct>=0.35?"kohtalainen":"matala";
 const volume=m.volume>=1.5?"tavallista aktiivisempi":m.volume<=0.7?"tavallista hiljaisempi":"lähellä keskimääräistä";
 const structure=m.breakUp?"ylöspäin tehty läpimurto":m.breakDown?"alaspäin tehty läpimurto":"tuoretta läpimurtoa ei havaittu";
 const forecast=a.forecast>0.2?"nousupainotteinen":a.forecast< -0.2?"laskupainotteinen":"neutraali";
 const change=Number.isFinite(a.change24)?`${a.change24>=0?"+":""}${fmt(a.change24,2)} %`:"ei saatavilla";
 const agreement=up.length>down.length?"nousu":down.length>up.length?"lasku":"ristiriitainen tai sivuttainen";
 const timeframeText=available.length?`${up.length} nousussa (${up.join(", ")||"ei yhtään"}), ${down.length} laskussa (${down.join(", ")||"ei yhtään"}), ${available.length-up.length-down.length} sivuttaisessa.`:"Aikajaksojen dataa ei ole vielä riittävästi.";
 const overall=side==="BUY"?`Valitun ${planIv.toUpperCase()}-aikajakson signaali on BUY (${tier}).`:side==="SELL"?`Valitun ${planIv.toUpperCase()}-aikajakson signaali on SELL (${tier}).`:`Valitun ${planIv.toUpperCase()}-aikajakson signaali on HOLD. Uutta kauppaa ei vahvisteta tällä hetkellä.`;
 let coherence;
 if(side==="BUY"&&up.length>down.length&&momentum==="nousupainotteinen") coherence="Aikajaksojen enemmistö ja M15-momentum tukevat nousupainotteista tulkintaa.";
 else if(side==="SELL"&&down.length>up.length&&momentum==="laskupainotteinen") coherence="Aikajaksojen enemmistö ja M15-momentum tukevat laskupainotteista tulkintaa.";
 else if(side==="HOLD") coherence="Kokonaisuus ei tällä hetkellä anna riittävän vahvaa sisääntulovahvistusta. Odota hinnan ja indikaattorien selkeytymistä.";
 else coherence="Analyysissä on ristiriitaisia havaintoja. Signaali ja muut mittarit eivät muodosta täysin yhtenäistä kokonaisuutta.";
 const action=side==="HOLD"?"Älä pakota kauppaa. Odota vahvistusta.":tier==="VAHVA"?"Vahvistus on vahva sovelluksen sääntöjen mukaan, mutta tarkista entry, stop loss ja position koko.":"Vahvistus on kohtalainen. Käytä pienempää kokoa ja varmista sisääntulo.";
 const assetKey=String(symbol||"").toUpperCase().replace(/^.*:/,"").replace(/\.P$/,"");
 const assetGroup=$("assetSelect")?.selectedOptions?.[0]?.parentElement?.label||"";
 const assetCurrencies=(assetKey.match(/^[A-Z]{6}$/)||[])[0];
 const currencyCodes=assetCurrencies?[assetKey.slice(0,3),assetKey.slice(3,6)]:[];
 const aliases=new Set([assetKey]);
 if(/XAUUSD|GOLD/.test(assetKey)){aliases.add("XAUUSD");aliases.add("USD");}
 if(/BTC|ETH|SOL|CRYPTO|KRYPT/.test(assetKey)||/Krypto/i.test(assetGroup)){aliases.add("BTCUSDT");aliases.add("USD");}
 if(currencyCodes.length)currencyCodes.forEach(x=>aliases.add(x));
 if(/NASDAQ|SPX|SP500|US500|DJI|DOW|RUT|AAPL|MSFT|NVDA|AMZN|META|GOOGL|TSLA/.test(assetKey)){aliases.add("NASDAQ");aliases.add("SP500");aliases.add("USD");}
 if(/DAX|GER40/.test(assetKey)){aliases.add("DAX");aliases.add("EUR");}
 if(/FTSE|UK100/.test(assetKey)){aliases.add("FTSE");aliases.add("GBP");}
 if(/NIKKEI|NI225|JPN225/.test(assetKey)){aliases.add("Nikkei");aliases.add("JPY");}
 if(/OIL|WTI|BRENT/.test(assetKey)){aliases.add("USOIL");aliases.add("CAD pairs");}
 const now=Date.now(),horizon=7*24*60*60*1000;
 const upcoming=(Array.isArray(econEvents)?econEvents:[]).map(e=>({e,d:econDate(e.time||e.date),a:econAnalyze(e)}))
  .filter(x=>x.d&&x.d.getTime()>=now&&x.d.getTime()<=now+horizon)
  .filter(x=>{
    const affected=x.a.assets||[];
    const country=String(x.e.country||"").toUpperCase();
    const exact=affected.some(v=>aliases.has(String(v).toUpperCase()));
    const currencyMatch=currencyCodes.includes(country)||((aliases.has("USD"))&&country==="US");
    const genericCrypto=aliases.has("BTCUSDT")&&(/US|CN|EU|JP|GB|USD|EUR|CNY|JPY|GBP/.test(country));
    return exact||currencyMatch||genericCrypto;
  })
  .sort((x,y)=>{
    const rank=v=>v.a.impact==="KORKEA"?0:v.a.impact==="KESKITASO"?1:2;
    return rank(x)-rank(y)||x.d-y.d;
  }).slice(0,6);
 const historical=(Array.isArray(econEvents)?econEvents:[]).map(e=>({e,d:econDate(e.time||e.date),a:econAnalyze(e)}))
  .filter(x=>x.d&&x.d.getTime()<now&&now-x.d.getTime()<=30*24*60*60*1000)
  .filter(x=>{
    const affected=x.a.assets||[],country=String(x.e.country||"").toUpperCase();
    return affected.some(v=>aliases.has(String(v).toUpperCase()))||currencyCodes.includes(country)||(aliases.has("USD")&&country==="US")||(aliases.has("BTCUSDT")&&/US|CN|EU|JP|GB/.test(country));
  }).sort((x,y)=>y.d-x.d).slice(0,8);
 const esc=v=>String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
 const candles=(data[planIv]?.candles||a.m15?.candles||[]).slice().sort((x,y)=>x.t-y.t);
 const historicalHtml=historical.map(({e,d,a})=>{
   const t=d.getTime(),before=candles.filter(k=>k.t<=t).at(-1);
   const after=candles.find(k=>k.t>=t+60*60*1000);
   const actual=e.actual??"ei saatavilla",estimate=e.estimate??"ei saatavilla";
   let reaction="Hintareaktiota ei voida laskea: tapahtuman ympäriltä ei ole riittävästi ladattuja kynttilöitä.";
   if(before&&after&&Number.isFinite(before.c)&&Number.isFinite(after.c)&&before.c!==0){
     const pct=(after.c-before.c)/before.c*100;
     reaction=`Noin 1 h tapahtuman jälkeen hinta oli ${pct>=0?"noussut":"laskenut"} ${Math.abs(pct).toFixed(3)} % (${fmtEntryPrice(before.c)} → ${fmtEntryPrice(after.c)}).`;
   }
   const surprise=econAnalyze(e).detail||"Toteuman ja ennusteen vertailua ei saatavilla.";
   return `<div style="padding:8px 0;border-top:1px solid rgba(255,255,255,.10)">
    <b>${esc(e.event||e.name||"Talousjulkaisu")} · ${esc(e.country||"")}</b>
    <div>${esc(econFinnishDate(d))} · vaikutusluokka ${esc(a.impact)}</div>
    <div>Toteuma: ${esc(actual)} · ennuste: ${esc(estimate)} · edellinen: ${esc(e.prev??"ei saatavilla")}</div>
    <div>${esc(surprise)}</div><div><b>Hinnan liike:</b> ${esc(reaction)}</div>
   </div>`;
 }).join("");
 const eventHtml=upcoming.length?upcoming.map(({e,d,a})=>`<div style="padding:8px 0;border-top:1px solid rgba(255,255,255,.10)">
  <div style="display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap"><b>${esc(e.event||e.name||"Talousjulkaisu")} · ${esc(e.country||"")}</b><b>${esc(a.impact)}</b></div>
  <div>${esc(econFinnishDate(d))} · ${Math.max(0,Math.round((d.getTime()-now)/60000))<60?`${Math.max(0,Math.round((d.getTime()-now)/60000))} min kuluttua`:`${Math.floor((d.getTime()-now)/3600000)} h kuluttua`}</div>
  <div>${esc(a.detail)}</div>
  <div><b>Mahdollinen vaikutus ${esc(assetKey)}-kohteeseen:</b> ${esc((a.assets||[]).join(", "))}. Vaikutussuunta riippuu toteumasta suhteessa ennusteeseen ja markkinan odotuksista.</div>
 </div>`).join(""):'<div style="padding:8px 0">Kalenterista ei löytynyt seuraavan 7 vuorokauden aikana tälle assetille tunnistettuja tapahtumia. Päivitä talouskalenteri nähdäksesi uusimmat julkaisut.</div>';
 box.innerHTML=`<div style="font-size:14px;font-weight:800;margin-bottom:7px">${chosen}</div>
 <p><b>Markkinatilanne:</b> ${overall} Hinta ${Number.isFinite(p)?fmtEntryPrice(p):"ei saatavilla"}, 24 h muutos ${change}.</p>
 <p><b>Aikajaksojen yhteenveto:</b> ${timeframeText} Kokonaispainotus on ${agreement}suuntainen.</p>
 <p><b>Momentum ja volatiliteetti:</b> M15 RSI ${fmt(m.rsi,1)} (${momentum}); ATR ${fmtEntryPrice(m.atr)} ja volatiliteetti ${volatility}. Volyymi on ${volume}.</p>
 <p><b>Hintarakenne:</b> ${structure}. Suunta-arvio on ${forecast}. Tarkista läpimurron suunta kynttilöistä ja hintarakenteesta.</p>
 <p><b>Mittareiden yhteistulkinta:</b> ${coherence}</p>
 <p><b>Toimintahuomio:</b> ${action} Tämä on tekninen tilannekuva, ei tuottolupaus eikä automaattinen toimeksianto.</p>
 <div style="margin-top:12px;padding-top:10px;border-top:2px solid rgba(220,180,80,.55)">
  <div style="font-size:13px;font-weight:800;margin-bottom:5px">TULEVAT TAPAHTUMAT, JOTKA SAATTAVAT VAIKUTTAA ASSETTIIN</div>
  <div style="margin-bottom:5px;color:#aeb7c9">Seuraavat 7 vuorokautta · tapahtumat suodatettu valitun instrumentin ja siihen liittyvien valuuttojen perusteella.</div>
  ${eventHtml}
 </div>
 <div style="margin-top:12px;padding-top:10px;border-top:2px solid rgba(220,180,80,.55)">
  <div style="font-size:13px;font-weight:800;margin-bottom:5px">MENNEET TAPAHTUMAT JA HINTAKEHITYS</div>
  <div style="margin-bottom:5px;color:#aeb7c9">Viimeiset 30 päivää · valitun assetin kanssa yhteensopiviksi luokitellut julkaisut. Hinnan muutos mitataan ladatuista ${planIv.toUpperCase()}-kynttilöistä noin tunnin ajalta tapahtuman jälkeen.</div>
  ${historicalHtml||"Kalenterin ladatuissa tiedoissa ei ole viimeisten 30 päivän sopivia menneitä tapahtumia. Historiaa ei täydennetä arvaamalla."}
  <div style="margin-top:6px;color:#aeb7c9">Huomio: tapahtuman jälkeinen hinnanmuutos on ajallinen yhteys, ei todiste siitä, että tapahtuma yksin aiheutti liikkeen. Muut uutiset, odotukset, likviditeetti ja markkinatilanne vaikuttavat myös. Jos kynttilädata ei kata tapahtuma-aikaa, reaktiota ei näytetä.</div>
 </div>`;
 stamp.textContent="Päivitetty "+new Date().toLocaleTimeString("fi-FI");
}

function render(){let a=lastAnalysis;if(!a)return;let p=lastPrice??a.price;$("price").textContent=fmtEntryPrice(p);$("updated").textContent="Päivitetty "+new Date().toLocaleTimeString("fi-FI")+" · EUR/USDT "+fmt(eurusdt,4);$("change24").textContent=a.change24==null?"--":(a.change24>=0?"+":"")+fmt(a.change24,2)+"%";$("change24").className=a.change24>=0?"up":"down";
$("signal").textContent=a.signal.signal;$("confidence").textContent=a.signal.tier+" · vahvuusarvio "+fmt(a.signal.conf,0)+"%";$("signalBox").className="signal "+(a.signal.signal==="BUY"?"buy":a.signal.signal==="SELL"?"sell":"hold");
$("rsi").textContent=fmt(a.m15.rsi,1);$("atr").textContent=fmt(a.m15.atr,2);$("regime").textContent=a.regime;
$("timeframes").innerHTML=TF.map(([iv,label])=>{let x=data[iv],dir=x?.trend||"—",cls=dir==="UP"?"up":dir==="DOWN"?"down":"flat",txt=dir==="UP"?"NOUSU":dir==="DOWN"?"LASKU":"SIVUTT." ;return `<div class="tf"><b>${label}</b><span class="${cls}">${txt}</span><div class="tiny">RSI ${x?fmt(x.rsi,0):"--"}</div></div>`}).join("");
$("patterns").innerHTML=a.patterns.map(([n,v])=>`<div class="pattern">${n}<span>${v}</span></div>`).join("");
let feats=[["Trend strength",Math.abs(a.signal.net)*100],["Volatility regime",clamp(a.m15.atrPct*250,0,100)],["Volume profile",clamp(a.m15.volume*35,0,100)],["Momentum oscillator",clamp(50+(a.m15.rsi-50)*2,0,100)],["Market structure",a.m15.breakUp||a.m15.breakDown?85:45],["Forecast direction",clamp(50+a.forecast*40,0,100)]];
$("features").innerHTML=feats.map(([n,v])=>`<div style="margin:10px 0"><div class="row"><span class="tiny">${n}</span><b style="font-size:12px">${fmt(v,0)}/100</b></div><div class="bar"><i style="width:${v}%"></i></div></div>`).join("");
const iv=$("planTf")?.value||"15m",q=data[iv]||a.m15,mac=q.macd||{},liveRows=[
["Hinta",fmtEntryPrice(q.close),"Viimeisin analyysissä käytetty päätöshinta."],
["EMA 20",fmtEntryPrice(q.ema20),q.close>q.ema20?"Hinta EMA20:n yläpuolella, lyhyt kuva nousupainotteinen.":"Hinta EMA20:n alapuolella, lyhyt kuva laskupainotteinen."],
["EMA 50",fmtEntryPrice(q.ema50),q.ema20>q.ema50?"EMA20 EMA50:n yläpuolella, keskiarvot tukevat nousua.":"EMA20 EMA50:n alapuolella, keskiarvot tukevat laskua."],
["RSI",fmt(q.rsi,1),q.rsi>=70?"Yliostettu alue, mutta ei yksin myyntisignaali.":q.rsi<=30?"Ylimyyty alue, mutta ei yksin ostosignaali.":q.rsi>50?"Yli 50: nousumomentum.": "Alle 50: laskumomentum."],
["MACD-histogrammi",fmt(mac.hist,6),mac.hist>0?"Positiivinen, tukee nousumomentumia.":mac.hist<0?"Negatiivinen, tukee laskumomentumia.":"Lähellä nollaa, momentumi neutraali."],
["ATR",fmt(q.atr,6), "Hintaliikkeen tyypillinen vaihteluväli, ei suunta."],
["ATR %",fmt(q.atrPct,3)+"%",q.atrPct>1?"Suhteellisesti voimakas heilunta.": "Suhteellinen volatiliteetti arvioidaan yhdessä instrumentin normaalin tason kanssa."],
["Volyymi / keskiarvo",fmt(q.volume,2)+"x",q.volume>=1.5?"Tavallista vilkkaampi aktiivisuus.":q.volume<0.7?"Tavallista hiljaisempi aktiivisuus.":"Lähellä vertailukeskiarvoa."],
["Momentum",fmt(q.momentum,6),q.momentum>0?"Viiden kynttilän hintamuutos positiivinen.":q.momentum<0?"Viiden kynttilän hintamuutos negatiivinen.":"Hintamuutos lähellä nollaa."],
["Trendin suunta",q.trend,q.trend==="UP"?"EMA-rakenne nousupainotteinen.":q.trend==="DOWN"?"EMA-rakenne laskupainotteinen.":"Ei selvää EMA-trendiä."],
["Markkinarakenne",q.breakUp?"Breakout ylös":q.breakDown?"Breakout alas":"Ei vahvistettua breakoutia",q.breakUp?"Päätöshinta ylitti tarkastellun aiemman huipun.":q.breakDown?"Päätöshinta alitti tarkastellun aiemman pohjan.":"Aiemman vaihteluvälin rajaa ei rikottu."],
["Kynttiläkuvio",candleTag(q),"Kynttiläkuvio on havainto, joka vaatii muun hintarakenteen vahvistuksen."]
];
$("indicatorLiveMeta").textContent=iv.toUpperCase()+" · "+new Date().toLocaleTimeString("fi-FI");
$("indicatorLiveValues").innerHTML=liveRows.map(([n,v,desc])=>`<div style="display:grid;grid-template-columns:minmax(110px, .8fr) minmax(90px, .7fr) 2fr;gap:7px;padding:6px 0;border-bottom:1px solid var(--line)"><b>${n}</b><b>${v}</b><span>${desc}</span></div>`).join("");
const positive=(q.trend==="UP"&&q.rsi>50&&mac.hist>0&&q.momentum>0),negative=(q.trend==="DOWN"&&q.rsi<50&&mac.hist<0&&q.momentum<0);
$("indicatorLiveInterpretation").innerHTML="<b>Kokonais­tulkinta:</b> "+(positive?"Indikaattorit tukevat nousupainotteista tilannetta. Odota silti hintarakenteen ja sisääntulon vahvistusta.":negative?"Indikaattorit tukevat laskupainotteista tilannetta. Odota silti hintarakenteen ja sisääntulon vahvistusta.":"Indikaattorit ovat osittain ristiriidassa tai suunta ei ole riittävän vahva. Suhtaudu tilanteeseen varovaisesti ja tarkista muut aikajaksot.")+" Arvot koskevat valittua suunnitteluaikajaksoa.";

let planIv=$("planTf")?.value||"15m",planData=data[planIv]||a.m15;
const planSignal=timeframeSignal(planData),side=planSignal.signal;
$("signal").textContent=side;
$("confidence").textContent=`${planIv.toUpperCase()} · ${planSignal.tier} · vahvuusarvio ${fmt(planSignal.conf,0)}%`;
$("signalBox").className="signal "+(side==="BUY"?"buy":side==="SELL"?"sell":"hold");
const closed=planData.candles,recent=closed.slice(-20),atrPlan=planData.atr;
const buffer=Math.max(atrPlan*.18,p*.00015),swingLow=recent.length?Math.min(...recent.map(c=>c.l)):p-atrPlan,swingHigh=recent.length?Math.max(...recent.map(c=>c.h)):p+atrPlan;
const emaEntry=planData.ema20,entryLo=emaEntry-atrPlan*.15,entryHi=emaEntry+atrPlan*.15;
const entry=side==="BUY"?entryHi:side==="SELL"?entryLo:emaEntry;
const stop=side==="BUY"?Math.min(swingLow-buffer,entry-atrPlan*Number($("atrMult").value||1.5)):side==="SELL"?Math.max(swingHigh+buffer,entry+atrPlan*Number($("atrMult").value||1.5)):null;
const dist=stop?Math.abs(entry-stop):atrPlan*Number($("atrMult").value||1.5),target=side==="BUY"?entry+dist*2:side==="SELL"?entry-dist*2:null;
$("entry").textContent=side==="HOLD"?"Odotetaan vahvistusta":`${fmtEntryPrice(entryLo)} – ${fmtEntryPrice(entryHi)}`;
$("stop").textContent=stop?fmtEntryPrice(stop):"--";$("target").textContent=target?fmtEntryPrice(target):"--";
const gap=p<entryLo?entryLo-p:p>entryHi?p-entryHi:0;
$("entryDistance").textContent=side==="HOLD"?"Signaalia odotetaan":gap===0?"Hinta entry-alueella":`${fmtEntryPrice(gap)} (${fmt(gap/Math.max(p,1)*100,3)} %)`;
const intervalMs=candleTimeframeMs(planIv),lastClosedOpen=planData.candles.at(-1)?.t||Date.now()-intervalMs;
const nextClose=lastClosedOpen+intervalMs*2;
$("candleCountdown").textContent=countdownText(nextClose-Date.now());
$("planReference").textContent=`${planIv.toUpperCase()} · Markkinahinta ${fmtEntryPrice(p)} · Entry-keskus EMA20 ${fmtEntryPrice(emaEntry)} · ATR ${fmtEntryPrice(atrPlan)}`;
$("tradeReason").textContent=side==="HOLD"?planSignal.reason:`${planSignal.tier}: ${planSignal.reason} Arvioitu riski ${fmt((Number($("capital").value)||500)*(Number($("riskPct").value)||1)/100*planSignal.riskFactor,2)} €. Entry-etäisyys kertoo nykyhinnan ja entry-alueen välisen matkan.`;
const watchTf=$("entryWatchTf")?.value||entryWatchConfig.tf||"5m";
const watchData=data[watchTf];
const activeWatches=entryWatchConfig.sides||[];
const hourlyCount=watchTf==="1m"?60:watchTf==="5m"?12:watchTf==="15m"?4:watchTf==="30m"?2:1;
for(const watchSide of ["BUY","SELL"]){
 const key=watchSide==="BUY"?"Buy":"Sell",active=activeWatches.includes(watchSide);
 const btn=$("entryWatch"+key);
 if(btn){btn.textContent=active?watchSide+"-vahti päällä":watchSide+"-vahti";btn.classList.toggle("watchActive",active);}
 if(!watchData){
  $("entryWatch"+key+"Price").textContent=fmtEntryPrice(p);
  if(active)updateEntryWatch(watchSide,NaN,NaN,null,p,watchTf);
  else{$("entryWatch"+key+"State").textContent="POIS PÄÄLTÄ";$("entryWatch"+key+"Zone").textContent="--";$("entryWatch"+key+"Reason").textContent=`Odotetaan ${watchTf.toUpperCase()}-markkinadataa entry-hinnan laskemiseksi.`;}
  continue;
 }
 // Lyhyen aikavälin entry-rakenne tarkastelee aina viimeistä 60 minuuttia.
 // Suuntasuodatin/EMA/RSI/MACD lasketaan pidemmästä historiasta (jopa 149 suljettua kynttilää).
 // Näin M15:n neljä tunnin kynttilää eivät yksin ratkaise trendiä.
 const watchAtr=watchData.atr||atrPlan;
 const hourlyBars=watchData.candles.slice(-hourlyCount);
 const watchRecent=watchData.candles.slice(-Math.max(hourlyCount,20));
 const watchBuffer=Math.max(watchAtr*.22,p*.0002);
 const hourLow=Math.min(...hourlyBars.map(c=>c.l)),hourHigh=Math.max(...hourlyBars.map(c=>c.h));
 const hourRange=Math.max(hourHigh-hourLow,watchAtr*.8);
 // BUY-alue sijoittuu tunnin vaihteluvälin alaosaan, SELL-alue yläosaan.
 // Alueiden väliin jää tarkoituksella tilaa, jotta vastakkaiset entryt eivät kasaudu päällekkäin.
 const buyLo=hourLow+hourRange*.12,buyHi=hourLow+hourRange*.28;
 const sellLo=hourHigh-hourRange*.28,sellHi=hourHigh-hourRange*.12;
 const watchSwingLow=watchRecent.length?Math.min(...watchRecent.map(c=>c.l)):p-watchAtr;
 const watchSwingHigh=watchRecent.length?Math.max(...watchRecent.map(c=>c.h)):p+watchAtr;
 const minGap=watchAtr*.35,center=(hourLow+hourHigh)/2;
 const separated=sellLo-buyHi>=minGap;
 const finalBuyLo=separated?buyLo:center-watchAtr*.85;
 const finalBuyHi=separated?buyHi:center-watchAtr*.55;
 const finalSellLo=separated?sellLo:center+watchAtr*.55;
 const finalSellHi=separated?sellHi:center+watchAtr*.85;
 const watchLo=watchSide==="BUY"?finalBuyLo:finalSellLo;
 const watchHi=watchSide==="BUY"?finalBuyHi:finalSellHi;
 const watchEntry=watchSide==="BUY"?finalBuyHi:finalSellLo;
 const watchStop=watchSide==="BUY"
  ?Math.min(watchSwingLow-watchBuffer,watchEntry-watchAtr*Number($("atrMult").value||1.5))
  :Math.max(watchSwingHigh+watchBuffer,watchEntry+watchAtr*Number($("atrMult").value||1.5));
 if(active)updateEntryWatch(watchSide,watchLo,watchHi,watchStop,p,watchTf);
 else{
  $("entryWatch"+key+"State").textContent="POIS PÄÄLTÄ";
  $("entryWatch"+key+"Zone").textContent=`${fmtEntryPrice(watchLo)} – ${fmtEntryPrice(watchHi)}`;
  $("entryWatch"+key+"Price").textContent=fmtEntryPrice(p);
  $("entryWatch"+key+"Reason").textContent=`${watchTf.toUpperCase()} · ${watchSide==="BUY"?"tunnin vaihteluvälin alaosan ostotukialue":"tunnin vaihteluvälin yläosan myyntivastusalue"}. Suuntasuodatin käyttää pidempää kynttilähistoriaa.`;
 }
}
$("entryWatchSelection").textContent=`Aikajakso ${watchTf.toUpperCase()} · aktiiviset vahdit: ${activeWatches.length?activeWatches.join(" + "):"ei yhtään"}. BUY ja SELL voivat olla päällä yhtä aikaa.`;
$("entryWindowInfo").textContent=`Entry-alueen rakenne: viimeiset ${hourlyCount} ${watchTf.toUpperCase()}-kynttilää = 60 min. Suuntasuodatin: ${watchData.candles.length} suljettua kynttilää (EMA20/50, RSI, MACD, ATR). BUY–SELL-väli vähintään noin 0,35 ATR.`;

const chartIv=$("chartTf").value,chartData=data[chartIv];
drawChart(chartData?.candles||a.m15.candles);
$("chartCaption").textContent=`Viimeiset Heikin-Ashi-kynttilät · ${chartIv.toUpperCase()}. Värit: vihreä nousu, punainen lasku.`;
calcRisk(p,atrPlan,side,dist);
updateMarketBrief();
updatePositionTracker();
updateAssetSummary(a,p,planIv,planSignal);
}
function calcRisk(price,atr15,side,forcedDist){
  let capital=Math.max(1,Number($("capital").value)||500),pct=clamp(Number($("riskPct").value)||1,.1,5),lev=Math.max(1,Number($("leverage").value)||1);
  let factor=lastAnalysis?.signal?.riskFactor??0;
  let dist=Math.max(atr15*(Number($("atrMult").value)||1.5),price*.0005);
  let plannedRisk=capital*pct/100*factor,riskUSDT=plannedRisk*eurusdt;
  let qty=dist>0?riskUSDT/dist:0,maxNotional=capital*eurusdt*lev;
  const requestedQty=Math.max(0,Number($("manualQty").value)||0);
  qty=Math.min(requestedQty>0?requestedQty:qty,maxNotional/price);
  let notional=qty*price,margin=notional/eurusdt/lev,actualRisk=qty*dist/eurusdt;
  $("riskCash").textContent=fmt(plannedRisk,2)+" €";
  $("maxLoss").textContent=fmt(actualRisk,2)+" €";
  $("qty").textContent=fmt(qty,4)+" XAU";
  $("notional").textContent=fmt(notional/eurusdt,2)+" €";
  $("margin").textContent=fmt(margin,2)+" €";
  $("maxLoss").title="Laskennallinen stop-tappio ennen kuluja, spreadiä ja slippagea.";
}
function alertTradePlan(tf,side){
  const strength=Math.round(Math.abs(tf.dir)*100);
  if((side!=="BUY"&&side!=="SELL")||strength<28) return {entry:"Odota vahvistusta",stop:"--",tps:"--",risk:0,tier:"HEIKKO",strength};
  const c=tf.candles.slice(-20),price=lastPrice??tf.close,a=Math.max(tf.atr,price*.0001);
  const lo=Math.min(...c.map(x=>x.l)),hi=Math.max(...c.map(x=>x.h));
  const entry=price,buffer=Math.max(a*.18,price*.00015);
  const stop=side==="BUY"?Math.min(lo-buffer,entry-a*1.5):Math.max(hi+buffer,entry+a*1.5);
  const dist=Math.max(Math.abs(entry-stop),a*1.5);
  const tier=Math.abs(tf.dir)>=.65?"VAHVA":"KOHTALAINEN",factor=tier==="VAHVA"?1:.5;
  const capital=Math.max(1,Number($("capital").value)||500),pct=clamp(Number($("riskPct").value)||1,.1,5),risk=capital*pct/100*factor;
  const tp=(r)=>side==="BUY"?entry+dist*r:entry-dist*r;
  return {entry:fmtEntryPrice(entry),stop:fmtEntryPrice(stop),tps:[tp(1),tp(2),tp(3)].map(fmtEntryPrice).join(" / "),risk,tier,strength};
}
function forecast(c){let vals=c.slice(-25).map(x=>x.c),n=vals.length,avg=vals.reduce((a,b)=>a+b,0)/n;let slope=0;for(let i=0;i<n;i++)slope+=(i-(n-1)/2)*(vals[i]-avg);slope/=n*(n*n-1)/12;return slope/(avg||1)*1000}
// ENTRY-VAHTI: BUY ja SELL toimivat itsenäisesti ja voivat olla yhtä aikaa päällä.
const watchTfSelect=$("entryWatchTf");
if(watchTfSelect){
 watchTfSelect.value=entryWatchConfig.tf||"5m";
 watchTfSelect.addEventListener("change",()=>{
  entryWatchConfig.tf=watchTfSelect.value;
  try{localStorage.setItem("goldProEntryWatchConfig",JSON.stringify(entryWatchConfig));}catch(e){}
  // Päivitä BUY/SELL-entryhinnat välittömästi valitun aikajakson datasta.
  if(lastAnalysis)render();
  else $("entryWatchSelection").textContent=`Aikajakso ${entryWatchConfig.tf.toUpperCase()} valittu. Entry-hinnat päivittyvät, kun markkinadata latautuu.`;
 });
}
function toggleEntryWatch(side){
 const sides=entryWatchConfig.sides||[];
 entryWatchConfig.sides=sides.includes(side)?sides.filter(x=>x!==side):[...sides,side];
 entryWatchConfig.tf=$("entryWatchTf")?.value||"5m";
 try{localStorage.setItem("goldProEntryWatchConfig",JSON.stringify(entryWatchConfig));}catch(e){}
 const active=entryWatchConfig.sides.includes(side);
 $("entryWatchSelection").textContent=`${side}-vahti ${active?"käynnistetty":"pysäytetty"} · ${entryWatchConfig.tf.toUpperCase()}. Aktiiviset: ${entryWatchConfig.sides.join(" + ")||"ei yhtään"}.`;
 if(!active){
  const key=side==="BUY"?"Buy":"Sell";
  $("entryWatch"+key+"State").textContent="POIS PÄÄLTÄ";
  $("entryWatch"+key+"Reason").textContent=side+"-vahti on pysäytetty.";
 }
 if(typeof render==="function"&&lastAnalysis)render();
}
$("entryWatchBuy")?.addEventListener("click",()=>toggleEntryWatch("BUY"));
$("entryWatchSell")?.addEventListener("click",()=>toggleEntryWatch("SELL"));

const TV_ASSETS = [
 {g:"Kryptovaluutat",a:["BINANCE:BTCUSDT.P|Bitcoin perpetual","BINANCE:ETHUSDT.P|Ethereum perpetual","BINANCE:SOLUSDT.P|Solana perpetual","COINBASE:BTCUSD|Bitcoin USD","COINBASE:ETHUSD|Ethereum USD","KRAKEN:BTCUSD|Bitcoin USD","KRAKEN:ETHUSD|Ethereum USD"]},
 {g:"Kulta ja raaka-aineet",a:["OANDA:XAUUSD|Kulta USD","OANDA:XAGUSD|Hopea USD","NYMEX:CL1!|WTI-raakaöljy futuuri","NYMEX:NG1!|Maakaasu futuuri","COMEX:GC1!|Kultafutuuri","COMEX:SI1!|Hopeafutuuri"]},
 {g:"Valuutat",a:["OANDA:EURUSD|EUR/USD","OANDA:GBPUSD|GBP/USD","OANDA:USDJPY|USD/JPY","OANDA:AUDUSD|AUD/USD","OANDA:USDCAD|USD/CAD","OANDA:USDCHF|USD/CHF","OANDA:EURJPY|EUR/JPY","OANDA:EURGBP|EUR/GBP"]},
 {g:"Yhdysvaltain osakkeet",a:["NASDAQ:AAPL|Apple","NASDAQ:MSFT|Microsoft","NASDAQ:NVDA|Nvidia","NASDAQ:AMZN|Amazon","NASDAQ:GOOGL|Alphabet","NASDAQ:TSLA|Tesla","NASDAQ:META|Meta Platforms","NYSE:BRK.B|Berkshire Hathaway","NYSE:JPM|JPMorgan","NYSE:KO|Coca-Cola"]},
 {g:"Euroopan osakkeet",a:["OMXHEX:NOKIA|Nokia","OMXHEX:KNEBV|KONE","OMXHEX:NESTE|Neste","OMXHEX:UPM|UPM-Kymmene","OMXHEX:WRT1V|Wärtsilä","OMXSTO:VOLV_B|Volvo B","XETR:SAP|SAP","XETR:BMW|BMW","LSE:AZN|AstraZeneca"]},
 {g:"ETF:t",a:["AMEX:SPY|SPDR S&P 500 ETF","NASDAQ:QQQ|Invesco QQQ","AMEX:GLD|SPDR Gold Shares","AMEX:SLV|iShares Silver Trust","AMEX:VTI|Vanguard Total Market","NASDAQ:IBIT|iShares Bitcoin Trust"]},
 {g:"Indeksit",a:["TVC:SPX|S&P 500","NASDAQ:NDX|Nasdaq 100","TVC:DJI|Dow Jones","XETR:DAX|DAX","TVC:UKX|FTSE 100","OMXHEX:OMXH25|OMX Helsinki 25","TVC:NI225|Nikkei 225"]},
 {g:"Futuurit ja korot",a:["CME_MINI:ES1!|E-mini S&P 500","CME_MINI:NQ1!|E-mini Nasdaq 100","CBOT:ZB1!|30Y Treasury Bond","CBOT:ZN1!|10Y Treasury Note","COMEX:HG1!|Kuparifutuuri","CBOT:ZC1!|Maissifutuuri"]}
];
function loadAssetList(){
 const select=$("assetSelect"),status=$("assetStatus");
 select.innerHTML="";
 TV_ASSETS.forEach(group=>{const og=document.createElement("optgroup");og.label=group.g;group.a.forEach(item=>{const [sym,label]=item.split("|");const op=document.createElement("option");op.value=sym;op.textContent=sym+" · "+label;og.appendChild(op)});select.appendChild(og)});
 const saved=localStorage.getItem("goldProSelectedTVAsset");
 symbol=[...select.options].some(o=>o.value===saved)?saved:"OANDA:XAUUSD";
 select.value=symbol;status.textContent=`${TV_ASSETS.reduce((n,g)=>n+g.a.length,0)} esimerkkisymbolia valittavissa kahdeksasta markkinaryhmästä. Symbolien saatavuus riippuu TradingViewn datalähteestä ja käyttöoikeuksista.`;
 updateAssetLabels();
}
function getTwelveDataMapping(tvSymbol){
 const [exchange="",ticker=""]=String(tvSymbol||"").split(":");
 const clean=ticker.replace(/\.P$/,"");
 const map={
  "OANDA:XAUUSD":{symbol:"XAU/USD",exchange:""},"TVC:GOLD":{symbol:"XAU/USD",exchange:""},
  "OANDA:XAGUSD":{symbol:"XAG/USD",exchange:""},"TVC:SILVER":{symbol:"XAG/USD",exchange:""},
  "BINANCE:BTCUSDT.P":{symbol:"BTC/USD",exchange:"Binance"},"BINANCE:ETHUSDT.P":{symbol:"ETH/USD",exchange:"Binance"},
  "BINANCE:SOLUSDT.P":{symbol:"SOL/USD",exchange:"Binance"},"COINBASE:BTCUSD":{symbol:"BTC/USD",exchange:"Coinbase"},
  "COINBASE:ETHUSD":{symbol:"ETH/USD",exchange:"Coinbase"},"KRAKEN:BTCUSD":{symbol:"BTC/USD",exchange:"Kraken"},
  "KRAKEN:ETHUSD":{symbol:"ETH/USD",exchange:"Kraken"},"OANDA:EURUSD":{symbol:"EUR/USD",exchange:""},
  "OANDA:GBPUSD":{symbol:"GBP/USD",exchange:""},"OANDA:USDJPY":{symbol:"USD/JPY",exchange:""},
  "OANDA:AUDUSD":{symbol:"AUD/USD",exchange:""},"OANDA:USDCAD":{symbol:"USD/CAD",exchange:""},
  "OANDA:USDCHF":{symbol:"USD/CHF",exchange:""},"OANDA:EURJPY":{symbol:"EUR/JPY",exchange:""},
  "OANDA:EURGBP":{symbol:"EUR/GBP",exchange:""}
 };
 if(map[tvSymbol])return {...map[tvSymbol]};
 if(["NASDAQ","NYSE","AMEX","OMXHEX","OMXSTO","XETR","LSE"].includes(exchange)){
  return {symbol:clean,exchange:({"OMXHEX":"NASDAQ","OMXSTO":"NASDAQ"}[exchange]||exchange)};
 }
 return {symbol:clean,exchange:""};
}
function getBiQuoteSymbol(tvSymbol){
 const exact={
  "OANDA:XAUUSD":"XAUUSD","TVC:GOLD":"XAUUSD","COMEX:GC1!":"XAUUSD",
  "OANDA:XAGUSD":"XAGUSD","TVC:SILVER":"XAGUSD","COMEX:SI1!":"XAGUSD",
  "OANDA:EURUSD":"EURUSD","OANDA:GBPUSD":"GBPUSD","OANDA:USDJPY":"USDJPY",
  "OANDA:AUDUSD":"AUDUSD","OANDA:USDCAD":"USDCAD","OANDA:USDCHF":"USDCHF",
  "OANDA:EURJPY":"EURJPY","OANDA:EURGBP":"EURGBP",
  "TVC:USOIL":"USOIL","NYMEX:CL1!":"USOIL"
 };
 if(exact[tvSymbol])return exact[tvSymbol];
 return null;
}
function currentTdMapping(){
 const auto=getTwelveDataMapping(symbol);
 return {symbol:$("tdSymbol")?.value.trim()||auto.symbol,exchange:$("tdExchange")?.value.trim()||auto.exchange};
}
function renderTradingViewWidget(tvSymbol, interval){
 const mount=$("tvWidgetContainer");
 if(!mount)return;
 const tvIntervals={"1m":"1","5m":"5","15m":"15","30m":"30","1h":"60","4h":"240","1d":"D"};
 const tvInterval=tvIntervals[String(interval||"15m")]||String(interval||"15");
 // Recreate the official TradingView Advanced Chart widget using its documented embed script.
 // A fresh mount avoids stale iframe state when the selected market changes.
 mount.replaceChildren();
 const widget=document.createElement("div");
 widget.className="tradingview-widget-container__widget";
 widget.style.cssText="width:100%;height:100%";
 mount.appendChild(widget);
 const script=document.createElement("script");
 script.type="text/javascript";
 script.async=true;
 script.src="https://s3.tradingview.com/external-embedding/embed-widget-advanced-chart.js";
 const config={
  autosize:true,
  symbol:tvSymbol,
  interval:tvInterval,
  timezone:"Europe/Helsinki",
  theme:"dark",
  style:"1",
  locale:"en",
  backgroundColor:"#0c0f16",
  gridColor:"rgba(255,255,255,0.06)",
  withdateranges:true,
  hide_side_toolbar:true,
  allow_symbol_change:true,
  save_image:false,
  calendar:false,
  details:false,
  hotlist:false,
  hide_volume:false,
  support_host:"https://www.tradingview.com"
 };
 script.textContent=JSON.stringify(config);
 script.onerror=()=>{const err=document.createElement("div");err.style.cssText="padding:14px;color:#f2c46d;font:14px sans-serif";err.textContent="TradingView-kaaviota ei voitu ladata. Tarkista verkkoyhteys tai kokeile toista symbolia.";mount.appendChild(err);};
 mount.appendChild(script);
}
function updateAssetLabels(){
 const tv=symbol;
 if($("assetEyebrow"))$("assetEyebrow").textContent=tv;
 if($("assetUnit"))$("assetUnit").textContent=tv.split(":").pop().replace(".P","");
 if($("chartAssetTitle"))$("chartAssetTitle").textContent=tv;
 if($("tvSymbolLabel"))$("tvSymbolLabel").textContent=tv;
 const interval=$("chartTf")?.value||"15";
 const tvUrl="https://www.tradingview.com/chart/?symbol="+encodeURIComponent(tv);
 const external=$("tvOpenExternal");if(external)external.href=tvUrl;
 renderTradingViewWidget(tv,interval);
 const m=getTwelveDataMapping(tv);
 if($("tdSymbol"))$("tdSymbol").value=m.symbol;
 if($("tdExchange"))$("tdExchange").value=m.exchange;
 $("price").textContent="--";$("updated").textContent="Valitaan markkinalle maksuton datalähde…";
 $("signal").textContent="HOLD";$("confidence").textContent="Signaalilaskenta odottaa varmennettua hintadataa";
 $("connection").textContent="● ODOTTAA DATAA";$("connection").style.color="#d6ad54";
}
function switchAsset(next){
 if(!next||next===symbol)return;
 if(ws){try{ws.onclose=null;ws.close()}catch(e){}ws=null;}
 clearTimeout(binanceReconnectTimer);clearTimeout(biquoteReconnectTimer);
 if(biquoteConnection){biquoteConnection.stop().catch(()=>{});biquoteConnection=null;}
 savePaper();
 symbol=next;try{localStorage.setItem("goldProSelectedTVAsset",symbol)}catch(e){}
 loadPaper();paintPaper();
 data={};binanceCandles={};biquoteCandles={};lastAnalysis=null;lastPrice=null;lastSignal="HOLD";renderDailyLevels();
 updateAssetLabels();
 $("status").textContent=`Valittu ${symbol}. Valitaan maksuton datalähde.`;
 refresh();
}
$("assetSelect")?.addEventListener("change",e=>switchAsset(e.target.value));
$("assetSearch")?.addEventListener("input",e=>{
 const q=e.target.value.trim().toUpperCase();let first=null;
 [...$("assetSelect").options].forEach(o=>{const show=!q||o.value.toUpperCase().includes(q)||o.textContent.toUpperCase().includes(q)||o.parentElement.label.toUpperCase().includes(q);o.hidden=!show;if(show&&!first)first=o;});
 if(first&&$("assetSelect").selectedOptions[0]?.hidden){$("assetSelect").value=first.value;switchAsset(first.value);}
});
async function tdRequest(symbolName,interval,exchange){
 const params=new URLSearchParams({symbol:symbolName,interval,outputsize:"100",apikey:tdApiKey});
 if(exchange)params.set("exchange",exchange);
 const response=await fetch("https://api.twelvedata.com/time_series?"+params.toString(),{cache:"no-store"});
 if(!response.ok)throw new Error("HTTP "+response.status);
 const json=await response.json();
 if(json.status==="error"||json.code||!Array.isArray(json.values))throw new Error(json.message||json.msg||"Twelve Data ei palauttanut kynttilöitä.");
 const candles=json.values.map(v=>({t:Date.parse(String(v.datetime).replace(" ","T")),o:Number(v.open),h:Number(v.high),l:Number(v.low),c:Number(v.close),v:Number(v.volume||0)}))
  .filter(c=>[c.o,c.h,c.l,c.c].every(Number.isFinite)).reverse();
 if(candles.length<60)throw new Error(`${symbolName} ${interval}: vain ${candles.length} kynttilää, tarvitaan vähintään 60.`);
 return {candles,meta:json.meta||{}};
}
function isBinancePerp(){return /^BINANCE:[A-Z0-9]+\.P$/.test(symbol)}
function isBinanceSpot(){return /^BINANCE:[A-Z0-9]+$/.test(symbol)}
function binanceTicker(){return symbol.split(":")[1].replace(/\.P$/," ").trim()}
function binanceUrls(){
 const perp=isBinancePerp(), base=perp?"https://fapi.binance.com/fapi/v1/klines":"https://data-api.binance.vision/api/v3/klines";
 const wsBase=perp?"wss://fstream.binance.com/stream?streams=":"wss://data-stream.binance.vision/stream?streams=";
 return {base,wsBase};
}
function applyBinanceCandle(iv,k){
 const candle={t:Number(k.t),o:Number(k.o),h:Number(k.h),l:Number(k.l),c:Number(k.c),v:Number(k.v)};
 const arr=binanceCandles[iv];if(!arr)return;
 const idx=arr.findIndex(x=>x.t===candle.t);
 if(idx>=0)arr[idx]=candle;else if(arr.length&&candle.t>arr[arr.length-1].t){arr.push(candle);if(arr.length>120)arr.shift();}else return;
 try{data[iv]=analyzeTF(arr);}catch(e){}
}
function currentNewsContext(){
 const s=String(symbol||"").toUpperCase();
 let category="macro",ticker="",label=s;
 if(s.includes("BINANCE:")){
  category="crypto";ticker=s.split(":").pop().replace(".P","").replace("USDT","");label=ticker;
 }else if(s.includes("OANDA:")){
  const pair=s.split(":").pop();ticker=pair;label=pair;
  category="forex";
  if(pair.includes("XAU")||pair.includes("XAG"))category="macro";
 }else if(s.includes("NASDAQ:")||s.includes("NYSE:")||s.includes("AMEX:")){
  category="stocks";ticker=s.split(":").pop();label=ticker;
 }else if(s.includes("TVC:")||s.includes("DJ:")){
  category="macro";ticker=s.split(":").pop();label=ticker;
 }
 return {category,ticker,label};
}
function explainNewsImpact(article,ctx){
 const text=((article.title||"")+" "+(article.summary||"")).toLowerCase();
 const groups=[
  {keys:["rate hike","interest rate","fed","federal reserve","ecb","central bank","inflation","cpi","pce","jobs report","payroll","yield","treasury"],name:"Korko- ja inflaatiovaikutus",why:"Korko-odotukset ja inflaatio muuttavat valuuttojen, kullan, osakkeiden ja riskisijoitusten hinnoittelua."},
  {keys:["etf inflow","etf outflow","fund inflow","fund outflow","inflow","outflow","liquidation","liquidations","exchange","bitcoin","ethereum","crypto"],name:"Krypto- ja pääomavirrat",why:"Sijoitusvirrat, pörssiuutiset ja likvidaatiot voivat muuttaa kryptokysyntää ja volatiliteettia."},
  {keys:["oil","crude","opec","supply","production","sanction","shipping","middle east","war","geopolitical"],name:"Energia- ja geopoliittinen vaikutus",why:"Tarjonta-, kuljetus- ja geopoliittiset häiriöt voivat muuttaa energian hintaa ja lisätä turvasatamakysyntää."},
  {keys:["earnings","revenue","profit","guidance","forecast","upgrade","downgrade","analyst","dividend","buyback","merger"],name:"Yhtiökohtainen vaikutus",why:"Tulokset, ohjeistus ja analyytikkomuutokset vaikuttavat suoraan yhtiön odotettuun tulokseen ja arvostukseen."},
  {keys:["dollar","dxy","euro","yen","currency","forex","trade balance","intervention"],name:"Valuuttavaikutus",why:"Valuuttauutiset ja keskuspankkien toimet muuttavat valuuttaparin suhteellista kysyntää."}
 ];
 const found=groups.filter(g=>g.keys.some(k=>text.includes(k)));
 if(!found.length)return {tag:"Vaikutus arvioitava",why:"Otsikosta ei löydy selkeää vaikutusajuria. Tarkista artikkelin sisältö ja vertaa uutisen ajankohtaa hinnan sekä volyymin muutokseen."};
 return {tag:found[0].name,why:found.map(g=>g.why).join(" ")};
}
async function loadAssetNews(){
 const key=sessionStorage.getItem("finnhubKey")||$("finnhubKey").value.trim();
 const out=$("assetNewsResults"),status=$("newsStatus"),ctx=currentNewsContext();
 $("newsAssetLabel").textContent="Kohde: "+ctx.label+" · Finnhub: "+ctx.category;
 if(!key){status.textContent="API-avain puuttuu";out.innerHTML='<div class="tiny">Lisää Finnhub API-avain ja tallenna se selainistuntoon.</div>';return;}
 status.textContent="Haetaan…";out.innerHTML='<div class="tiny">Haetaan valittuun instrumenttiin liittyviä uutisia…</div>';
 try{
  const today=new Date(),from=new Date(today.getTime()-7*86400000);
  const iso=d=>d.toISOString().slice(0,10);
  let url;
  if(ctx.category==="stocks" && ctx.ticker){
   const q=new URLSearchParams({symbol:ctx.ticker,from:iso(from),to:iso(today),token:key});
   url="https://finnhub.io/api/v1/company-news?"+q.toString();
  }else{
   const newsCategory=ctx.category==="macro"?"general":ctx.category;
   const q=new URLSearchParams({category:newsCategory,token:key});
   url="https://finnhub.io/api/v1/news?"+q.toString();
  }
  const r=await fetch(url,{cache:"no-store"});
  const items=await r.json();
  if(!r.ok)throw new Error(items?.error||"HTTP "+r.status);
  if(!Array.isArray(items))throw new Error("Finnhub palautti odottamattoman vastauksen");
  const filtered=ctx.ticker && ctx.category!=="stocks" ? items.filter(a=>((a.related||"").toUpperCase().includes(ctx.ticker.toUpperCase()) || (a.headline||"").toUpperCase().includes(ctx.ticker.toUpperCase()) || (a.summary||"").toUpperCase().includes(ctx.ticker.toUpperCase()))):items;
  const shown=(filtered.length?filtered:items).slice(0,10);
  if(!shown.length){out.innerHTML='<div class="tiny">Finnhub ei palauttanut uutisia tälle luokalle viimeisimmistä uutisista.</div>';status.textContent="Ei uutisia";return;}
  out.innerHTML=shown.map(a=>{
   const impact=explainNewsImpact({title:a.headline,summary:a.summary},ctx);
   const date=a.datetime?new Date(a.datetime*1000).toLocaleString("fi-FI"):"Aika ei saatavilla";
   const summary=a.summary||"Julkaisijalta ei ole saatavilla tiivistelmää.";
   const href=a.url||"#";
   return `<article class="newsItem"><a href="${href}" target="_blank" rel="noopener">${a.headline||"Uutinen"}</a><div class="newsMeta">${a.source||"Lähde tuntematon"} · ${date}</div><div class="tiny">${summary}</div><div class="impactText"><span class="impactTag">${impact.tag}</span><br><b>Miksi tämä voi vaikuttaa:</b> ${impact.why}</div></article>`;
  }).join("");
  status.textContent=shown.length+" uutista · Finnhub · "+new Date().toLocaleTimeString("fi-FI");
 }catch(e){status.textContent="Uutishaku epäonnistui";out.textContent="Finnhub-uutisia ei saatu: "+e.message+". Tarkista API-avain, käyttöoikeudet ja verkkoyhteys.";}
}
$("saveFinnhubKey").addEventListener("click",()=>{
 const key=$("finnhubKey").value.trim();
 if(!key){$("newsStatus").textContent="Anna API-avain";return;}
 sessionStorage.setItem("finnhubKey",key);$("newsStatus").textContent="Finnhub-avain tallennettu istuntoon";startEconomicCalendar();
});
$("loadAssetNews").addEventListener("click",loadAssetNews);


// Economic calendar: Finnhub API + official Tradays widget (display-only).
let econEvents=[], econTimer=null, econLastFetch=0;
const econSeenKey="goldProEconomicAlertSeen_v1";
function econKey(){return sessionStorage.getItem("finnhubKey")||$("finnhubKey")?.value.trim()||"";}
function econEscape(v){return String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function econDate(v){
 if(v===null||v===undefined||v==="")return null;
 // Lähteet voivat antaa aikaleiman numerona TAI numerojonona.
 // Sekunnit ja millisekunnit tunnistetaan erikseen.
 if(typeof v==="number"||(typeof v==="string"&&/^\d{9,13}(?:\.\d+)?$/.test(v.trim()))){
  const n=Number(v);
  if(Number.isFinite(n)&&n>1e9)return new Date(n>(1e12)?n:n*1000);
 }
 // Päivämäärä ilman kellonaikaa on kalenteripäivä, ei UTC-siirtymän arvaus.
 if(typeof v==="string"){
  const m=v.trim().match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if(m){const d=new Date(Date.UTC(Number(m[1]),Number(m[2])-1,Number(m[3]),12));return Number.isNaN(d.getTime())?null:d;}
 }
 const d=new Date(v);return Number.isNaN(d.getTime())?null:d;
}
// Kaikki talouskalenterin ajat näytetään aina Suomen aikavyöhykkeessä (kesä-/talviaika automaattisesti).
function econFinnishDate(v){
 const d=v instanceof Date?v:econDate(v);
 return d?new Intl.DateTimeFormat("fi-FI",{timeZone:"Europe/Helsinki",day:"2-digit",month:"2-digit",year:"numeric",hour:"2-digit",minute:"2-digit",second:"2-digit",hourCycle:"h23"}).format(d):"Aika ei saatavilla";
}
function econCountdown(v){
 const d=econDate(v);if(!d)return "";
 const ms=d.getTime()-Date.now();
 if(ms<=0)return "Tapahtuma käynnissä / julkaistu";
 const total=Math.floor(ms/1000),days=Math.floor(total/86400),hours=Math.floor((total%86400)/3600),mins=Math.floor((total%3600)/60),secs=total%60;
 return "Alkaa " +(days?days+" pv ":"")+String(hours).padStart(2,"0")+":"+String(mins).padStart(2,"0")+":"+String(secs).padStart(2,"0");
}
function updateEconomicCountdowns(){
 document.querySelectorAll("[data-econ-countdown]").forEach(el=>{el.textContent=econCountdown(el.dataset.econCountdown);});
}
function econImpactName(v){
 const x=String(v??"").toLowerCase();
 if(x.includes("high")||x==="3")return "KORKEA";
 if(x.includes("medium")||x==="2")return "KESKITASO";
 if(x.includes("low")||x==="1")return "MATALA";
 return "EI MÄÄRITETTY";
}
function econAffected(e){
 const n=String(e.event||e.name||"").toLowerCase(), c=String(e.country||e.countryCode||"").toUpperCase();
 let a=[];
 if(/cpi|inflation|pce|ppi|consumer price|producer price/.test(n))a=["XAUUSD","EURUSD","USDJPY","NASDAQ","SP500","BTCUSDT"];
 else if(/interest rate|rate decision|central bank|fomc|fed funds|ecb|boe|boj/.test(n))a=["XAUUSD","EURUSD","GBPUSD","USDJPY","NASDAQ","SP500","BTCUSDT"];
 else if(/nonfarm|payroll|unemployment|employment|jobless|wage/.test(n))a=["USDJPY","EURUSD","XAUUSD","NASDAQ","SP500","BTCUSDT"];
 else if(/gdp|retail sales| ism |pmi|industrial production/.test(" "+n+" "))a=["EURUSD","USDJPY","XAUUSD","NASDAQ","SP500","BTCUSDT"];
 else if(/oil|opec|crude|energy/.test(n))a=["USOIL","XAUUSD","CAD pairs","SP500"];
 else if(/trade balance|current account/.test(n))a=["EURUSD","USDJPY","GBPUSD"];
 else if(/china|chinese/.test(n)||c==="CN")a=["AUDUSD","NZDUSD","XAUUSD","BTCUSDT"];
 else if(c==="US")a=["USD pairs","XAUUSD","NASDAQ","SP500","BTCUSDT"];
 else if(c==="EU"||c==="DE"||c==="FR")a=["EURUSD","XAUUSD","DAX","SP500"];
 else if(c==="GB")a=["GBPUSD","EURGBP","FTSE"];
 else if(c==="JP")a=["USDJPY","EURJPY","Nikkei"];
 else a=["Valuutat: "+(c||"maa"),"XAUUSD","osakeindeksit"];
 return [...new Set(a)];
}
function econNumericValue(value){
 if(value===null||value===undefined||value==="")return NaN;
 if(typeof value==="number")return Number.isFinite(value)?value:NaN;
 let s=String(value).trim().replace(/[−–]/g,"-").replace(/\s/g,"");
 const match=s.match(/[+-]?(?:\d[\d.,]*|[.,]\d+)(?:[eE][+-]?\d+)?/);
 if(!match)return NaN;
 s=match[0];
 const comma=s.lastIndexOf(","), dot=s.lastIndexOf(".");
 if(comma>=0&&dot>=0){
  if(comma>dot)s=s.replace(/\./g,"").replace(",",".");
  else s=s.replace(/,/g,"");
 }else if(comma>=0){
  const decimals=s.length-comma-1;
  s=decimals>0&&decimals<=2?s.replace(",","."):s.replace(/,/g,"");
 }
 let n=Number(s);
 const suffix=String(value).trim().match(/([kmb])\s*%?\s*$/i);
 if(suffix){const m=suffix[1].toLowerCase();n*=m==="k"?1e3:m==="m"?1e6:1e9;}
 return Number.isFinite(n)?n:NaN;
}
function econEducation(e){
 const n=String(e.event||e.name||"").toLowerCase();
 const country=String(e.country||"").toUpperCase();
 const currency=econBiQuoteCurrency(country)||country||"valuutta";
 const impact=econImpactName(e.impact);
 let topic="Tämä on talouskalenterin julkaisu. Tarkka sisältö riippuu mittarin määritelmästä ja julkaisijasta.";
 let measures="Tarkista julkaisun virallinen määritelmä, mittayksikkö ja se, verrataanko kuukausi-, neljännes- vai vuosimuutosta.";
 let mechanism="Markkina vertaa lukua odotuksiin. Yllätys voi muuttaa korko- ja kasvuodotuksia, valuuttojen kysyntää sekä riskinottohalua.";
 let high="Ennustetta korkeampi tulos voi tukea valuuttaa, jos se tulkitaan talouden tai korkotuoton kannalta myönteiseksi.";
 let low="Ennustetta matalampi tulos voi heikentää valuuttaa, jos se tulkitaan talouden tai korkotuoton kannalta kielteiseksi.";
 let watch="Vertaa toteumaa ennusteeseen ja edelliseen lukuun. Tarkista myös markkinan ensimmäinen reaktio ja korkotuottojen suunta.";
 if(/core.*cpi|cpi.*core|core inflation/.test(n)){
  topic="Pohjainflaatio mittaa kuluttajahintojen nousua ilman tavallisesti voimakkaasti vaihtelevia eriä, kuten energiaa ja usein ruokaa. Se auttaa arvioimaan, kuinka laajaa ja sitkeää hintojen nousu on.";
  measures="Katso kuukausimuutos (m/m) ja vuosimuutos (y/y). Tarkista myös, onko kyse kokonaisindeksistä vai pohjainflaatiosta.";
  mechanism="Sitkeä inflaatio voi saada keskuspankin pitämään korot korkealla tai nostamaan niitä. Se voi nostaa valuutan korkotukea ja reaalikorkoja, mikä usein painaa kultaa. Laskevat korko-odotukset voivat tehdä päinvastoin.";
  high="Odotettua korkeampi pohjainflaatio voi vahvistaa kyseistä valuuttaa ja painaa kultaa, jos korko-odotukset nousevat.";
  low="Odotettua matalampi pohjainflaatio voi heikentää kyseistä valuuttaa ja tukea kultaa, jos markkina alkaa hinnoitella koronlaskuja.";
  watch="Seuraa kokonaisinflaatiota, palveluinflaatiota, palkkoja, keskuspankin tavoitetta sekä korkofutuureiden ja valtionlainakorkojen reaktiota.";
 }else if(/cpi|consumer price|inflation/.test(n)){
  topic="Kuluttajahintaindeksi (CPI) mittaa kotitalouksien ostamien tavaroiden ja palvelujen hintojen muutosta. Se kertoo kuluttajahintainflaation vauhdista.";
  measures="Tarkista kuukausimuutos (m/m), vuosimuutos (y/y) ja mahdollinen pohjainflaatio. Yksittäinen kuukausiluku voi heilua paljon.";
  mechanism="Korkea inflaatio voi viivästyttää koronlaskuja tai lisätä koronnosto-odotuksia. Tämä voi tukea valuuttaa korkoeron kautta ja painaa kultaa korkeampien korkojen sekä vahvemman dollarin välityksellä.";
  high="Ennustetta korkeampi CPI voi tukea kyseistä valuuttaa ja painaa kultaa, jos korko-odotukset nousevat.";
  low="Ennustetta matalampi CPI voi heikentää kyseistä valuuttaa ja tukea kultaa, jos koronlaskuodotukset vahvistuvat.";
  watch="Seuraa pohjainflaatiota, palveluhintoja, kuukausimuutosta ja markkinan korko-odotuksia. Älä päättele suuntaa pelkästä vuosiluvusta.";
 }else if(/pce/.test(n)){
  topic="PCE-hintaindeksi mittaa henkilökohtaisten kulutusmenojen hintoja. Yhdysvaltain keskuspankki seuraa erityisesti PCE-inflaatiota arvioidessaan hintavakautta.";
  measures="Tarkista kokonais-PCE ja pohja-PCE sekä kuukausi- ja vuosimuutos.";
  mechanism="Yhdysvaltain PCE-yllätys voi muuttaa Fedin korko-odotuksia, USD:n kysyntää, valtionlainakorkoja ja kullan hinnoittelua.";
  high="Odotettua korkeampi PCE voi tukea USD:tä ja painaa kultaa, jos markkina hinnoittelee korkeampia korkoja pidemmäksi aikaa.";
  low="Odotettua matalampi PCE voi heikentää USD:tä ja tukea kultaa, jos koronlaskuodotukset kasvavat.";
  watch="Seuraa pohja-PCE:tä, aiempien lukujen tarkistuksia, palkkoja ja Fedin seuraavia kommentteja.";
 }else if(/ppi|producer price/.test(n)){
  topic="Tuottajahintaindeksi mittaa yritysten saamien tuotantopanosten tai myymien tuotteiden hintojen muutosta. Se voi antaa vihjeitä kustannuspaineista ennen kuin ne näkyvät kuluttajahinnoissa.";
  measures="Tarkista kuukausi- ja vuosimuutos sekä se, sisältääkö julkaisu ruoan ja energian vai jättääkö ne pois.";
  mechanism="Tuottajahintojen nousu voi kasvattaa inflaatiopaineiden odotusta ja vaikuttaa korkoihin. Vaikutus kuluttajainflaatioon ei kuitenkaan ole automaattinen.";
  high="Korkea PPI voi tukea valuuttaa ja painaa kultaa, jos markkina tulkitsee sen merkiksi sitkeämmästä inflaatiosta.";
  low="Matala PPI voi keventää inflaatio- ja korkopaineita, mikä voi heikentää valuuttaa ja tukea kultaa.";
  watch="Vertaa PPI:tä CPI/PCE-lukuihin ja tarkista, johtuuko muutos energiasta, raaka-aineista vai laajasta hintapaineesta.";
 }else if(/non.?farm|payroll|employment change|employment report/.test(n)){
  topic="Työllisyysraportti kuvaa työpaikkojen määrän muutosta. Yhdysvaltain Nonfarm Payrolls mittaa maatalouden ulkopuolisten palkkatyöpaikkojen muutosta.";
  measures="Tarkista työpaikkojen muutos, työttömyysaste, keskituntiansiot ja aiempien kuukausien tarkistukset.";
  mechanism="Vahva työllisyys voi lisätä kulutusta ja pitää palkka- sekä inflaatiopaineita yllä. Se voi nostaa korko-odotuksia ja tukea USD:tä. Heikko raportti voi lisätä koronlaskuodotuksia, mutta myös taantumapelkoa.";
  high="Ennustetta vahvempi työllisyys voi tukea USD:tä, jos palkat ja työttömyys vahvistavat samaa viestiä. Osakkeiden reaktio riippuu siitä, tulkitaanko tulos kasvumyönteiseksi vai korkoja nostavaksi.";
  low="Ennustetta heikompi työllisyys voi painaa USD:tä ja tukea kultaa korko-odotusten kautta. Jos taantumapelko kasvaa, osakkeet voivat silti laskea.";
  watch="Katso koko raporttia, älä vain työpaikkalukua. Palkkakehitys, työttömyysaste ja aiempien lukujen tarkistukset voivat muuttaa tulkinnan.";
 }else if(/unemployment|jobless|initial claims|continuing claims/.test(n)){
  topic="Työttömyysaste tai työttömyyskorvaushakemukset kuvaavat työmarkkinoiden heikkoutta. Hakemusten kasvu voi olla varhainen merkki irtisanomisten lisääntymisestä.";
  measures="Työttömyysaste ilmoitetaan prosentteina. Hakemukset ilmoitetaan henkilömääränä, ja viikkolukujen neljän viikon keskiarvo tasoittaa vaihtelua.";
  mechanism="Heikkenevät työmarkkinat voivat lisätä koronlaskuodotuksia ja heikentää valuuttaa. Jos heikkous tulkitaan taantumariskiksi, riskisijoitukset voivat laskea.";
  high="Korkeampi työttömyys tai hakemusmäärä voi heikentää kyseistä valuuttaa ja tukea kultaa, jos koronlaskuodotukset kasvavat.";
  low="Matalampi työttömyys tai hakemusmäärä voi tukea valuuttaa, jos työmarkkinoiden vahvuus nostaa korko-odotuksia.";
  watch="Seuraa trendiä usean viikon tai kuukauden ajalta sekä palkkoja ja työllisyyden kasvua.";
 }else if(/wage|average hourly earnings|earnings/.test(n)){
  topic="Palkkadata mittaa työntekijöiden ansioiden kehitystä. Palkkojen nopea nousu voi lisätä kotitalouksien ostovoimaa mutta myös palvelujen kustannus- ja inflaatiopaineita.";
  measures="Tarkista tunti- tai kuukausiansioiden muutos sekä vuosimuutos. Vertaa palkkoja tuottavuuteen ja inflaatioon.";
  mechanism="Nopea palkkakasvu voi pitää palveluinflaation korkeana ja nostaa korko-odotuksia. Hidas kasvu voi helpottaa inflaatiopaineita.";
  high="Odotettua nopeampi palkkakasvu voi tukea valuuttaa korko-odotusten kautta ja painaa kultaa.";
  low="Odotettua hitaampi palkkakasvu voi keventää korkopaineita, heikentää valuuttaa ja tukea kultaa.";
  watch="Tarkista samalla työllisyys, työtunnit ja inflaatio. Palkkaluku yksin ei kerro koko työmarkkinasta.";
 }else if(/interest rate|rate decision|policy rate|fed funds|fomc|ecb rate|bank of england|boj/.test(n)){
  topic="Korkopäätös kertoo, muuttaako keskuspankki ohjauskorkoa. Päätöksen lisäksi tärkeää on keskuspankin arvio inflaatiosta, talouskasvusta ja tulevasta korkopolusta.";
  measures="Vertaa päätettyä korkoa markkinoiden odotukseen. Lue myös lausunto, äänestysjakauma, ennusteet ja lehdistötilaisuuden viestit.";
  mechanism="Korkoero vaikuttaa valuuttojen houkuttelevuuteen. Korkojen nousu voi tukea valuuttaa ja nostaa vaihtoehtoiskustannusta kullalle. Osakkeille korkeammat diskonttokorot voivat olla rasite.";
  high="Odotettua korkeampi korko tai haukkamainen viestintä voi vahvistaa valuuttaa ja painaa kultaa. Osakkeet voivat kärsiä korkeammista koroista.";
  low="Odotettua matalampi korko tai kyyhkymäinen viestintä voi heikentää valuuttaa ja tukea kultaa. Osakkeet voivat hyötyä, jos kasvuodotukset pysyvät vakaina.";
  watch="Tärkein yllätys voi olla viestinnässä eikä itse korkoluvussa. Seuraa sanavalintoja, tulevia korkoennusteita ja markkinakorkoja.";
 }else if(/gdp|gross domestic/.test(n)){
  topic="Bruttokansantuote (BKT/GDP) mittaa taloudessa tuotettujen tavaroiden ja palvelujen kokonaisarvoa. Se kuvaa talouskasvun vauhtia.";
  measures="Tarkista neljännesmuutos, vuositasolle korotettu luku ja aiempien neljännesten tarkistukset. Katso myös kulutuksen, investointien ja viennin osuudet.";
  mechanism="Vahva kasvu voi tukea valuuttaa ja yritysten tulosodotuksia, mutta myös vähentää koronlaskujen tarvetta. Heikko kasvu voi lisätä elvytysodotuksia tai taantumapelkoa.";
  high="Odotettua vahvempi BKT voi tukea valuuttaa ja osakkeita, jos kasvu ei samalla nosta korkoja liikaa.";
  low="Odotettua heikompi BKT voi heikentää valuuttaa. Kulta voi hyötyä korko-odotuksista tai turvasatamakysynnästä.";
  watch="Tarkista BKT:n rakenne ja onko kyse ennakko-, toinen arvio vai lopullinen julkaisu.";
 }else if(/pmi|purchasing managers|ism/.test(n)){
  topic="Ostopäällikköindeksi (PMI/ISM) perustuu yritysten kyselyihin ja kuvaa esimerkiksi tilausten, tuotannon, työllisyyden ja toimitusaikojen suuntaa. Yleensä 50 erottaa kasvun supistumisesta.";
  measures="Tarkista kokonaisindeksi sekä uudet tilaukset, työllisyys ja maksetut hinnat. Varmista, onko indeksi valmistus- vai palvelualalta.";
  mechanism="Indeksi antaa nopean kuvan suhdanteesta ennen monia virallisia tilastoja. Vahva tulos voi nostaa kasvu- ja korko-odotuksia; heikko tulos voi lisätä elvytysodotuksia.";
  high="Ennustetta korkeampi PMI/ISM voi tukea valuuttaa ja osakkeita. Jos maksetut hinnat nousevat, korkoreaktio voi kuitenkin painaa osakkeita ja kultaa.";
  low="Ennustetta matalampi PMI/ISM voi heikentää valuuttaa ja lisätä koronlaskuodotuksia. Alle 50 jäävä lukema viittaa toiminnan supistumiseen.";
  watch="Seuraa 50-rajaa, uusia tilauksia, palvelu- ja valmistusindeksejä sekä hintakomponenttia.";
 }else if(/retail sales/.test(n)){
  topic="Vähittäismyynti mittaa kuluttajien ostoksia ja antaa tietoa kotitalouksien kulutuksesta, joka on monissa talouksissa tärkeä kasvun lähde.";
  measures="Tarkista kuukausimuutos, ydinvähittäismyynti ja aiempien lukujen tarkistukset. Selvitä, sisältyvätkö autot ja polttoaine.";
  mechanism="Vahva kulutus voi tukea kasvu- ja valuuttaodotuksia mutta myös ylläpitää inflaatiota ja korkoja. Heikko kulutus voi lisätä koronlaskuodotuksia.";
  high="Ennustetta vahvempi myynti voi tukea valuuttaa ja osakkeita, jos korkojen nousu ei dominoi reaktiota.";
  low="Ennustetta heikompi myynti voi heikentää valuuttaa ja tukea kultaa, jos markkina odottaa kevyempää rahapolitiikkaa.";
  watch="Katso ydinkulutusta, inflaatiota ja sitä, johtuuko muutos hintojen noususta vai myytyjen määrien kasvusta.";
 }else if(/trade balance|current account/.test(n)){
  topic="Kauppatase tai vaihtotase kuvaa maan ulkomaankaupan ja muiden rajat ylittävien maksujen tasapainoa.";
  measures="Tarkista vienti, tuonti ja saldon muutos. Selvitä, johtuuko muutos vientimääristä, tuontihinnoista vai valuuttakurssista.";
  mechanism="Kauppavirrat vaikuttavat valuutan kysyntään ja tarjontaan, mutta korkoerot ja sijoitusvirrat liikuttavat valuuttoja usein enemmän lyhyellä aikavälillä.";
  high="Ennustetta suurempi ylijäämä voi tukea valuuttaa, jos se kertoo vahvasta viennistä tai ulkoisesta tasapainosta.";
  low="Pienempi ylijäämä tai suurempi alijäämä voi painaa valuuttaa, mutta tulkinta riippuu viennin ja tuonnin syistä.";
  watch="Seuraa vientiä, tuontia, pääomavirtoja ja keskuspankin korkoeroja.";
 }
 const actual=econNumericValue(e.actual), estimate=econNumericValue(e.estimate);
 let result="Toteumaa ei ole vielä saatavilla. Ennen julkaisua markkina liikkuu odotusten ja positioiden perusteella.";
 if(Number.isFinite(actual)&&Number.isFinite(estimate)){
  const diff=actual-estimate;
  result=Math.abs(diff)<1e-10?"Toteuma vastasi ennustetta. Reaktio voi silti syntyä edellisten lukujen tarkistuksista tai siitä, että markkina odotti vielä parempaa tai heikompaa tulosta.":(diff>0?"Toteuma ylitti ennusteen. ":"Toteuma alitti ennusteen. ")+( /unemployment|jobless|claims/.test(n)?"Tässä mittarissa korkeampi lukema on yleensä heikompi työmarkkinoille, joten tulkinta voi olla päinvastainen kuin tavallisessa kasvu- tai inflaatioluvussa.":"Vertaa yllätyksen suuruutta mittarin luonteeseen ja tarkista, vahvistaako muu julkaisu saman viestin.");
 }else if(Number.isFinite(actual)){
  result="Toteuma on julkaistu, mutta ennuste puuttuu. Yllätyksen suuntaa ei voida määrittää luotettavasti.";
 }
 return {topic,measures,mechanism,high,low,watch,result,currency,impact};
}

function econAnalyze(e){
 const n=String(e.event||e.name||"").toLowerCase(), c=String(e.country||"").toUpperCase();
 const actual=econNumericValue(e.actual), estimate=econNumericValue(e.estimate), prev=econNumericValue(e.prev);
 const hasA=e.actual!==null&&e.actual!==undefined&&e.actual!==""&&Number.isFinite(actual);
 const hasE=e.estimate!==null&&e.estimate!==undefined&&e.estimate!==""&&Number.isFinite(estimate);
 const diff=hasA&&hasE?actual-estimate:null;
 let direction="NEUTRAALI / RIIPPUU TULKINNASTA", detail="Tarkastele toteumaa suhteessa ennusteeseen, aiempaan arvoon ja markkinan korko-odotuksiin.";
 const inflation=/cpi|inflation|pce|ppi|consumer price|producer price/.test(n);
 const jobs=/nonfarm|payroll|employment|wage|unemployment/.test(n);
 const rate=/interest rate|rate decision|fomc|fed funds|central bank/.test(n);
 const growth=/gdp|retail sales|pmi|ism|industrial production/.test(n);
 if(diff!==null){
  const stronger=diff>0, weaker=diff<0;
  if(inflation){direction=stronger?"INFLAATIO YLLÄTTI YLÖS":"INFLAATIO ALITTI ENNUSTEEN";detail=stronger?"Voi nostaa korko-odotuksia ja tukea kyseistä valuuttaa, mutta painaa kultaa ja korkoherkkiä osakkeita.":"Voi laskea korko-odotuksia, heikentää kyseistä valuuttaa ja tukea kultaa sekä korkoherkkiä osakkeita.";}
  else if(jobs||growth){direction=stronger?"DATA ENNUSTETTA VAHVEMPAA":"DATA ENNUSTETTA HEIKOMPAA";detail=stronger?"Voi vahvistaa valuuttaa korko-odotusten kautta, mutta riskisentimentti ratkaisee indeksien reaktion.":"Voi heikentää valuuttaa ja lisätä koronlaskuodotuksia; taantumapelko voi silti painaa riskisijoituksia.";}
  else if(rate){direction="KORKOPÄÄTÖKSEN YLLÄTYS";detail="Päätös ja keskuspankin viestintä voivat liikuttaa valuuttaa, kultaa ja korkoherkkiä osakkeita. Vertaa päätöstä odotuksiin.";}
  else{direction=stronger?"TOTEUMA YLI ENNUSTEEN":"TOTEUMA ALLE ENNUSTEEN";detail="Yllätyksen suunta voi vaikuttaa kyseisen maan valuuttaan ja riskisentimenttiin. Suunta riippuu indikaattorin luonteesta.";}
 }
 const assets=econAffected(e);
 return {direction,detail,assets,hasA,hasE,diff,actual,estimate,prev,impact:econImpactName(e.impact)};
}
function econEventId(e){return [e.event||e.name,e.country,e.time||e.date].join("|");}
function econNotify(title,body){
 if(notifyReady&&"Notification" in window&&Notification.permission==="granted")new Notification(title,{body});
}
function econCheckAlerts(){
 const now=Date.now();let seen={};try{seen=JSON.parse(localStorage.getItem(econSeenKey)||"{}");}catch(e){}
 for(const e of econEvents){
  const d=econDate(e.time||e.date);if(!d)continue;
  const delta=d.getTime()-now,id=econEventId(e),imp=econImpactName(e.impact);
  if(delta>0&&delta<=15*60*1000&&delta>0&&!seen[id+":before"]&&imp==="KORKEA"){
   econNotify("MY AI GOLD PRO · Tapahtuma 15 min kuluttua",`${e.event||e.name} (${e.country||""}). Seurattavat: ${econAffected(e).join(", ")}`);
   seen[id+":before"]=now;
  }
  if(delta<=0&&delta>-3*60*1000&&!seen[id+":release"]){
   econNotify("MY AI GOLD PRO · Talousjulkaisu",`${e.event||e.name}. Päivitä kalenteri nähdäksesi toteuman ja AI-arvion.`);
   seen[id+":release"]=now;
  }
  if(e.actual!==null&&e.actual!==undefined&&e.actual!==""){
   const value=String(e.actual),oldValue=seen[id+":actual"];
   if(oldValue!==undefined&&oldValue!==value){
    econNotify("MY AI GOLD PRO · Toteuma päivittyi",`${e.event||e.name}: toteuma ${value}. Avaa kalenteri nähdäksesi päivitetyn AI-arvion.`);
   }
   seen[id+":actual"]=value;
  }
 }
 try{localStorage.setItem(econSeenKey,JSON.stringify(seen));}catch(e){}
}
function closeEconomicAnalysis(){
 econSelectedId=null;
 const box=$("econSelectedAnalysis");
 if(box){box.style.display="none";box.innerHTML="";}
 renderEconomicCalendar();
}
function renderEconomicCalendar(){
 const out=$("econEvents");if(!out)return;
 if(!econEvents.length){out.innerHTML='<div class="tiny">Finnhub ei palauttanut tapahtumia valitulle aikavälille.</div>';return;}
 const now=Date.now();
 const sorted=[...econEvents].sort((a,b)=>(econDate(a.time||a.date)?.getTime()||0)-(econDate(b.time||b.date)?.getTime()||0));
 out.innerHTML=sorted.slice(0,35).map(e=>{
  const d=econDate(e.time||e.date),a=econAnalyze(e),time=d?econFinnishDate(d):"Aika ei saatavilla";
  const status=a.hasA?"TOTEUMA JULKAISTU":d&&d.getTime()<now?"AIKA OHITETTU":"TULOS ODOTTAA";
  const vals=[["Toteuma",e.actual],["Ennuste",e.estimate],["Edellinen",e.prev]].map(([k,v])=>`${k}: ${v===null||v===undefined||v===""?"--":econEscape(v)}`).join(" · ");
  return `<article class="newsItem"><div style="display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap"><b>${econEscape(e.event||e.name||"Talousjulkaisu")} · ${econEscape(e.country||"")}</b><span class="impactTag">${a.impact}</span></div><div class="newsMeta">${econEscape(time)} · ${status}</div><div class="tiny">${vals}</div><div class="impactText"><b>AI-arvio: ${econEscape(a.direction)}</b><br>${econEscape(a.detail)}<br><b>Mahdolliset vaikutuskohteet:</b> ${a.assets.map(econEscape).join(", ")}</div></article>`;
 }).join("");
}
let econSelectedId=null;
function normalizeEconomicEvent(e,i){
 const dt=e.time||e.datetime||e.date||e.release_time||e.timestamp||e.ts;
 const ts=econDate(dt);
 return {
  _id:String(e.id||e.event_id||[e.event||e.name||e.title,e.currency||e.country||e.ccy,dt,i].join("|")),
  event:e.title||e.event||e.name||e.indicator||"Talousjulkaisu",
  country:e.currency||e.country||e.ccy||e.country_code||e.countryCode||"",
  eventId:e.eventId||e.event_id||e.seriesId||e.series_id||"",
  source:e.source||e.provider||e._feedSource||"ShowMyTrades",
  time:Number.isNaN(ts.getTime())?null:ts.toISOString(),
  impact:e.impact||e.importance||e.impact_level||"",
  actual:e.actual??null,
  estimate:e.forecast??e.estimate??e.consensus??null,
  prev:e.previous??e.prev??null,
  unit:e.unit||"",
  period:e.period??"",
  status:e.status??"scheduled",
  movedFrom:e.moved_from??"",
  confidence:e.confidence??"",
  sourceId:e.id??e.event_id??"",
  raw:e
 };
}
function econHistoryValues(e){
 const raw=e.raw||e;
 const candidates=[raw.history,raw.historical,raw.historical_values,raw.previous_values,raw.past_values,raw.history_values];
 for(const list of candidates){
  if(Array.isArray(list)){
   const vals=list.map(x=>econNumericValue(typeof x==="object"?(x.value??x.actual??x.close):x)).filter(Number.isFinite);
   if(vals.length)return vals.slice(-12);
  }
 }
 return [];
}
function econCompareData(e,a){
 const out=[];
 if(a.hasA&&a.hasE){
  const delta=a.actual-a.estimate;
  out.push({label:"Vertailu ennusteeseen",text:Math.abs(delta)<1e-10?"Toteuma vastasi ennustetta.":`Toteuma ${delta>0?"ylitti":"alitti"} ennusteen ${Math.abs(delta).toLocaleString("fi-FI",{maximumFractionDigits:6})} yksiköllä.`});
 }
 if(a.hasA&&Number.isFinite(a.prev)){
  const delta=a.actual-a.prev;
  const pct=a.prev!==0?(delta/Math.abs(a.prev))*100:null;
  out.push({label:"Vertailu edelliseen julkaisuun",text:`Toteuma ${delta>0?"nousi":delta<0?"laski":"pysyi samana"} ${Math.abs(delta).toLocaleString("fi-FI",{maximumFractionDigits:6})} yksikköä edellisestä arvosta (${a.prev}).${pct===null?"":` Muutos ${pct>=0?"+":""}${pct.toLocaleString("fi-FI",{maximumFractionDigits:2})} %.`}`});
 }else if(a.hasA){
  out.push({label:"Vertailu edelliseen julkaisuun",text:"Edellistä arvoa ei ole saatavilla, joten muutosta edelliseen ei voida laskea."});
 }
 const hist=econHistoryValues(e);
 if(a.hasA&&hist.length){
  const last=hist[hist.length-1],first=hist[0],delta=a.actual-last;
  out.push({label:"Vertailu saatavilla olevaan historiaan",text:`Historiatietoja löytyi ${hist.length}. Toteuma on ${delta>0?"korkeampi":delta<0?"matalampi":"samalla tasolla"} kuin historian viimeinen arvo (${last}). Historian vaihteluväli ${Math.min(...hist)}–${Math.max(...hist)}.`});
 }else{
  out.push({label:"Historiavertailu",text:"Rajapinta ei toimittanut tälle tapahtumalle erillistä historiallista arvosarjaa. Vertailu tehdään saatavilla olevista toteuma-, ennuste- ja edellinen-arvo-kentistä."});
 }
 return out;
}
function econDirectionForEvent(e,a){
 const n=(e.event||"").toLowerCase(), c=(e.country||"").toUpperCase();
 const ccy=({US:"USD",USD:"USD",EU:"EUR",EUR:"EUR",GB:"GBP",GBP:"GBP",JP:"JPY",JPY:"JPY",CA:"CAD",CAD:"CAD",AU:"AUD",AUD:"AUD",NZ:"NZD",NZD:"NZD",CH:"CHF",CHF:"CHF",CN:"CNY",CNY:"CNY"}[c]||c);
 const inflation=/cpi|inflation|pce|ppi|price index/.test(n);
 const jobs=/payroll|employment|unemployment|jobless|wage/.test(n);
 const rates=/interest rate|rate decision|central bank|fomc|policy rate/.test(n);
 const growth=/gdp|retail sales|pmi|ism|industrial production/.test(n);
 let surprise="Toteumaa ei ole vielä saatavilla.";
 if(a.hasA&&!a.hasE){
  surprise=`Toteuma ${a.actual} on saatavilla, mutta ennustearvo puuttuu. Yllätyksen suuntaa ei voida siksi verrata ennusteeseen.`;
 }else if(a.hasA&&a.hasE){
  const d=a.actual-a.estimate;
  surprise=Math.abs(d)<1e-10?"Toteuma vastasi ennustetta.":(d>0?"Toteuma ylitti ennusteen.":"Toteuma alitti ennusteen.");
 }else if(!a.hasA&&a.hasE){
  surprise="Ennuste on saatavilla, mutta toteumaa ei ole vielä julkaistu.";
 }else{
  surprise="Toteumaa ja ennustetta ei ole saatavilla.";
 }
 let currencyBias="Epäselvä / odotetaan markkinareaktiota";
 let goldBias="Neutraali, kunnes korko- ja dollarireaktio vahvistuu";
 if(a.hasA&&a.hasE){
  const beat=a.actual>a.estimate;
  if(inflation){currencyBias=beat?`${ccy} voi vahvistua korko-odotusten noustessa`:`${ccy} voi heikentyä korko-odotusten laskiessa`;goldBias=beat?"Kulta voi joutua laskupaineeseen":"Kulta voi saada tukea";}
  else if(jobs||growth){currencyBias=beat?`${ccy} voi vahvistua vahvan datan myötä`:`${ccy} voi heikentyä heikon datan myötä`;goldBias=beat?"Kullan suunta riippuu riskisentimentistä ja korkoreaktiosta":"Kulta voi saada tukea matalammista korko-odotuksista";}
 }
 const assets=econAffected({...e,country:ccy});
 return {ccy,inflation,jobs,rates,growth,surprise,currencyBias,goldBias,assets};
}
function econBiQuoteCurrency(country){
 const c=String(country||"").toUpperCase();
 return ({US:"USD",USD:"USD",EU:"EUR",EUR:"EUR",DE:"EUR",FR:"EUR",IT:"EUR",ES:"EUR",GB:"GBP",GBP:"GBP",JP:"JPY",JPY:"JPY",CA:"CAD",CAD:"CAD",AU:"AUD",AUD:"AUD",NZ:"NZD",NZD:"NZD",CH:"CHF",CHF:"CHF",CN:"CNY",CNY:"CNY"}[c]||c);
}
function econRelevantPairs(country){
 const c=econBiQuoteCurrency(country);
 const map={
  USD:["EURUSD","GBPUSD","USDJPY","AUDUSD","USDCAD","USDCHF","NZDUSD"],
  EUR:["EURUSD","EURJPY","EURGBP","EURCHF"],
  GBP:["GBPUSD","GBPJPY","EURGBP"],
  JPY:["USDJPY","EURJPY","GBPJPY","AUDJPY"],
  AUD:["AUDUSD","AUDJPY","AUDNZD"],
  NZD:["NZDUSD","NZDJPY","AUDNZD"],
  CAD:["USDCAD","CADJPY","EURCAD"],
  CHF:["USDCHF","EURCHF","CHFJPY"],
  CNY:["USDCNH","AUDUSD","NZDUSD"]
 };
 return map[c]||[];
}
function econBiQuoteHistoryRows(raw){
 if(Array.isArray(raw))return raw;
 if(Array.isArray(raw?.items))return raw.items;
 if(Array.isArray(raw?.history))return raw.history;
 if(Array.isArray(raw?.records))return raw.records;
 if(Array.isArray(raw?.data))return raw.data;
 return [];
}
async function econLoadSeriesHistory(e,targetId){
 const box=document.getElementById(targetId);if(!box)return;
 if(!e.eventId){box.innerHTML='<b>Historialliset julkaisut:</b> Tälle tapahtumalle ei saatu BiQuoten eventId-tunnistetta. Tapahtumahistoriaa ei voida hakea luotettavasti.';return;}
 box.innerHTML="<b>BiQuote-historia:</b> Haetaan aiempia julkaisuja…";
 try{
  const r=await fetch("https://biquote.io/api/calendar/"+encodeURIComponent(e.eventId)+"/history?limit=24",{cache:"no-store"});
  if(!r.ok)throw new Error("HTTP "+r.status);
  const raw=await r.json(), rows=econBiQuoteHistoryRows(raw);
  const values=rows.map(x=>({date:x.time||x.date||x.releaseTime||x.timestamp||"",actual:x.actual,forecast:x.forecast??x.estimate??null,previous:x.previous??x.prev??null,unit:x.unit||e.unit||""})).filter(x=>econNumericValue(x.actual)===econNumericValue(x.actual));
  if(!values.length){box.innerHTML="<b>BiQuote-historia:</b> Rajapinta vastasi, mutta aiempia toteumalukuja ei löytynyt.";return;}
  const nums=values.map(x=>econNumericValue(x.actual)).filter(Number.isFinite);
  const current=econNumericValue(e.actual),mean=nums.reduce((a,b)=>a+b,0)/nums.length;
  const range=`${Math.min(...nums).toLocaleString("fi-FI")}–${Math.max(...nums).toLocaleString("fi-FI")}`;
  const relation=Number.isFinite(current)?(current>Math.max(...nums)?"nykyinen toteuma ylittää historian ylimmän":current<Math.min(...nums)?"nykyinen toteuma alittaa historian alimman":"nykyinen toteuma on historian vaihteluvälillä"):"nykyistä toteumaa ei voida verrata historiarajaan";
  const rowsHtml=values.slice(0,12).map(x=>`<div>${econEscape(x.date?econFinnishDate(x.date):"Aika ei ilmoitettu")} · toteuma <b>${econEscape(x.actual??"--")}</b> · ennuste ${econEscape(x.forecast??"--")} · edellinen ${econEscape(x.previous??"--")}</div>`).join("");
  box.innerHTML=`<b>BiQuote-historia (${values.length} aiempaa julkaisua)</b><br>Historiallinen keskiarvo: ${mean.toLocaleString("fi-FI",{maximumFractionDigits:6})} · vaihteluväli: ${range}.<br><b>${econEscape(relation)}.</b><div style="margin-top:6px">${rowsHtml}</div><div class="tiny">Lähde: BiQuote · eventId ${econEscape(e.eventId)}</div>`;
 }catch(err){box.innerHTML=`<b>BiQuote-historia:</b> Haku epäonnistui (${econEscape(err.message)}). Kalenterin muut tiedot säilyvät käytössä.`;}
}
async function econLoadLiveCurrencyQuotes(e,targetId){
 const box=document.getElementById(targetId);if(!box)return;
 const pairs=econRelevantPairs(e.country);
 if(!pairs.length){box.innerHTML="<b>Valuuttaparien hintareaktio:</b> Tälle valuutalle ei ole määritelty suoraa BiQuote-parilistaa.";return;}
 box.innerHTML="<b>Valuuttaparien hintareaktio:</b> Haetaan viimeisimmät noteeraukset…";
 try{
  const params=new URLSearchParams();pairs.forEach(p=>params.append("symbols",p));
  const r=await fetch("https://biquote.io/api/latest?"+params.toString(),{cache:"no-store"});
  if(!r.ok)throw new Error("HTTP "+r.status);
  const raw=await r.json(), rows=Array.isArray(raw)?raw:(raw.items||raw.quotes||raw.data||[]);
  const bySymbol=new Map(rows.map(q=>[String(q.symbol||q.name||"").toUpperCase(),q]));
  const items=pairs.map(pair=>{
   const q=bySymbol.get(pair);
   if(!q)return `<div>${pair}: noteerausta ei palautettu</div>`;
   const price=Number(q.mid??q.bid??q.price??q.last);
   const age=Number(q.quoteAgeSeconds);
   const stale=q.stale===true||q.marketState==="closed"||Number.isFinite(age)&&age>300;
   const stamp=q.timestamp||q.lastQuoteAt||"";
   return `<div>${pair}: <b>${Number.isFinite(price)?price.toLocaleString("fi-FI",{maximumFractionDigits:6}):"hinta puuttuu"}</b> · ${econEscape(q.direction||"")}${q.dayDiffPercent!==undefined?` · päivämuutos ${Number(q.dayDiffPercent).toLocaleString("fi-FI",{maximumFractionDigits:2})}%`:""} · ${stale?"vanha/markkina kiinni":"tuore"}${stamp?" · "+econEscape(econFinnishDate(stamp)):""}</div>`;
  }).join("");
  box.innerHTML=`<b>Valuuttaparien viimeisin markkinareaktio</b><br>${items}<div class="tiny">Lähde: BiQuote · hinnat ovat viimeisimpiä saatavilla olevia noteerauksia. Suljettu tai vanhentunut markkinahinta merkitään erikseen.</div>`;
 }catch(err){box.innerHTML=`<b>Valuuttaparien hintareaktio:</b> Haku epäonnistui (${econEscape(err.message)}).`;}
}
function renderSelectedEconomicAnalysis(e,targetId){
 const box=targetId?$(targetId):$("econSelectedAnalysis");if(!box)return;
 const a=econAnalyze(e),d=econDirectionForEvent(e,a),comparisons=econCompareData(e,a),edu=econEducation(e);
 const num=v=>v===null||v===undefined||v===""?"--":econEscape(v)+(e.unit?" "+econEscape(e.unit):"");
 const impact=a.impact;
 box.style.display="block";
 box.innerHTML=`<div style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap"><b>AI-ANALYYSI · ${econEscape(e.event)}</b><div style="display:flex;align-items:center;gap:7px"><span class="impactTag">${impact}</span><button type="button" class="secondary" data-close-economic-analysis="1" aria-label="Sulje analyysi" style="padding:6px 10px">✕ Sulje</button></div></div>
 <div class="newsMeta">${econEscape(e.country||"")} · Suomen aika: ${econEscape(e.time?econFinnishDate(e.time):"Aika ei saatavilla")}</div><div class="tiny" data-econ-countdown="${econEscape(e.time||"")}" style="color:#e7bd59;font-weight:700;margin-top:4px">${econEscape(econCountdown(e.time))}</div>
 <div class="tiny" style="margin-top:8px">Toteuma: <b>${num(e.actual)}</b> · Ennuste: <b>${num(e.estimate)}</b> · Edellinen: <b>${num(e.prev)}</b></div>
 <div class="tiny">Julkaisujakso: ${econEscape(e.period||"--")} · Tila: ${econEscape(e.status||"--")} · Lähde: ${econEscape(e.source||"Kalenteri") } · Luotettavuus: ${econEscape(e.confidence||"--")}${e.movedFrom?` · Siirretty ajasta: ${econEscape(e.movedFrom)}`:""}</div>
 <div class="impactText"><b>${econEscape(d.surprise)}</b><br>${econEscape(a.detail)}</div>
 <div class="impactText"><b>1. Mitä tämä aihe käsittelee?</b><br>${econEscape(edu.topic)}<br><br><b>Mitä luvusta kannattaa lukea?</b><br>${econEscape(edu.measures)}</div>
 <div class="impactText"><b>2. Miksi markkina reagoi?</b><br>${econEscape(edu.mechanism)}</div>
 <div class="impactText"><b>3. Mahdolliset skenaariot</b><br><b>Ennustetta korkeampi:</b> ${econEscape(edu.high)}<br><br><b>Ennustetta matalampi:</b> ${econEscape(edu.low)}<br><br><b>Tämän julkaisun tilanne:</b> ${econEscape(edu.result)}</div>
 <div class="impactText"><b>4. Mitä kannattaa seurata seuraavaksi?</b><br>${econEscape(edu.watch)}</div>
 <div class="impactText"><b>Vertailu kaikkiin saatavilla oleviin lukuihin</b><br>${comparisons.map(x=>`<b>${econEscape(x.label)}:</b> ${econEscape(x.text)}`).join("<br>")}</div>
 <div class="impactText" id="econBiQuoteHistory${econEscape(e._id)}">BiQuote-historia: valmistellaan hakua…</div>
 <div class="impactText" id="econLiveQuotes${econEscape(e._id)}">Valuuttaparien hintareaktio: valmistellaan hakua…</div>
 <div class="impactText"><b>Valuutan mahdollinen reaktio:</b> ${econEscape(d.currencyBias)}<br><b>Kullan mahdollinen reaktio:</b> ${econEscape(d.goldBias)}</div>
 <div class="impactText"><b>Seurattavat assetit:</b> ${d.assets.map(econEscape).join(", ")}</div>
 <div class="tiny" style="margin-top:8px">Tulkinta on sääntöpohjainen skenaario, ei varma ennuste. Markkinan odotukset, keskuspankkien viestintä ja hintakehitys voivat muuttaa reaktion.</div>`;
 const historyId="econBiQuoteHistory"+e._id,quotesId="econLiveQuotes"+e._id;
 econLoadSeriesHistory(e,historyId);
 econLoadLiveCurrencyQuotes(e,quotesId);
 const closeBtn=box.querySelector("[data-close-economic-analysis]");
 if(closeBtn) closeBtn.addEventListener("click",()=>{
  econSelectedId=null;
  renderEconomicCalendar();
 });
}
function renderEconomicCalendar(){
 const out=$("econEvents");if(!out)return;
 if(!econEvents.length){out.innerHTML='<div class="tiny">Kalenterista ei löytynyt tapahtumia.</div>';return;}
 const now=Date.now();
 const sorted=[...econEvents].sort((a,b)=>(econDate(a.time)?.getTime()||0)-(econDate(b.time)?.getTime()||0));
 const q=(document.getElementById("econSearch")?.value||"").trim().toLocaleLowerCase("fi-FI");
 const selectedDay=document.getElementById("econDateFilter")?.value||"";
 const dayKey=v=>{
  const d=econDate(v);if(!d)return "";
  const parts=new Intl.DateTimeFormat("en-GB",{timeZone:"Europe/Helsinki",year:"numeric",month:"2-digit",day:"2-digit"}).formatToParts(d);
  const o={};parts.forEach(p=>{o[p.type]=p.value;});
  return o.year&&o.month&&o.day?`${o.year}-${o.month}-${o.day}`:"";
 };
 const filtered=sorted.filter(e=>(!q||`${e.event} ${e.country} ${e.impact}`.toLocaleLowerCase("fi-FI").includes(q))&&(!selectedDay||dayKey(e.time)===selectedDay));
 const count=document.getElementById("econCount");if(count)count.textContent=`Näytetään ${filtered.length} / ${sorted.length} tapahtumaa${selectedDay?" · päivä "+selectedDay+" (Suomen aika)":""} · kaikki vaikutustasot`;
 if(!filtered.length){
  out.innerHTML=`<div class="tiny">${selectedDay?`Valitulle päivälle ${econEscape(selectedDay)} ei löytynyt tapahtumia. Kokeile Kaikki päivät -painiketta tai tarkista kalenterin päivitys.`:"Hakuehdoilla ei löytynyt tapahtumia."}</div>`;
  return;
 }
 out.innerHTML=filtered.map((e,index)=>{
  const d=econDate(e.time),a=econAnalyze(e),time=d?econFinnishDate(d):"Aika ei saatavilla";
  const status=a.hasA?"TOTEUMA JULKAISTU":d&&d.getTime()<now?"AIKA OHITETTU":"TULOS ODOTTAA";
  const vals=`Toteuma ${e.actual??"--"} · Ennuste ${e.estimate??"--"} · Edellinen ${e.prev??"--"}`;
  const analysisId="econInlineAnalysis"+index;
  return `<div class="econEventWrap" style="margin:7px 0">
   <button type="button" class="newsItem econEventButton" data-econ-id="${econEscape(e._id)}" style="display:block;width:100%;text-align:left;color:inherit;cursor:pointer;border:1px solid ${e._id===econSelectedId?"#e7bd59":"#2b3445"};background:${e._id===econSelectedId?"#252c39":"#151a25"}">
    <div style="display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap"><b>${econEscape(e.event)} · ${econEscape(e.country)}</b><span class="impactTag">${a.impact}</span></div>
    <div class="newsMeta">Suomen aika: ${econEscape(time)} · ${status}</div>
    <div class="tiny" data-econ-countdown="${econEscape(e.time||"")}" style="color:#e7bd59;font-weight:700;margin-top:4px">${econEscape(econCountdown(e.time))}</div>
    <div class="tiny">${econEscape(vals)}</div>
    <div class="tiny">Tila: ${econEscape(e.status||"scheduled")} · Jakso: ${econEscape(e.period||"--")} · Luotettavuus: ${econEscape(e.confidence||"--")}${e.movedFrom?` · Siirretty: ${econEscape(e.movedFrom)}`:""}</div>
    <div class="tiny" style="margin-top:5px;color:#e7bd59">Napauta avataksesi AI-analyysin</div>
   </button>
   <div id="${analysisId}" class="newsItem" style="display:none;margin-top:6px;border:1px solid #e7bd59"></div>
  </div>`;
 }).join("");
 out.querySelectorAll("[data-econ-id]").forEach(btn=>btn.addEventListener("click",()=>{
  const e=econEvents.find(x=>x._id===btn.dataset.econId);if(!e)return;
  const wasSelected=econSelectedId===e._id;
  econSelectedId=wasSelected?null:e._id;
  renderEconomicCalendar();
  if(!wasSelected){
   const selected=econEvents.find(x=>x._id===econSelectedId);
   const index=filtered.findIndex(x=>x._id===econSelectedId);
   if(selected&&index>=0)renderSelectedEconomicAnalysis(selected,"econInlineAnalysis"+index);
  }
 }));

}
async function loadEconomicCalendar(){
 const status=$("econStatus");
 status.textContent="Haetaan talouskalentereita…";
 try{
  const from=new Date(Date.now()-90*86400000).toISOString();
  const to=new Date(Date.now()+30*86400000).toISOString();
  const results=await Promise.allSettled([
   fetch("https://showmytrades.com/api/public/calendar/v1?impact=all&days=30&format=json",{cache:"no-store"}).then(async r=>{if(!r.ok)throw new Error("ShowMyTrades HTTP "+r.status);return r.json();}),
   fetch("https://biquote.io/api/calendar?from="+encodeURIComponent(from)+"&to="+encodeURIComponent(to)+"&limit=500",{cache:"no-store"}).then(async r=>{if(!r.ok)throw new Error("BiQuote HTTP "+r.status);return r.json();})
  ]);
  const combined=[];
  let showCount=0,biCount=0,errors=[];
  if(results[0].status==="fulfilled"){
   const raw=results[0].value,arr=Array.isArray(raw)?raw:(raw.events||raw.data||raw.calendar||[]);
   if(Array.isArray(arr)){combined.push(...arr.map(x=>({...x,_feedSource:"ShowMyTrades"})));showCount=arr.length;}
  }else errors.push(results[0].reason?.message||"ShowMyTrades ei vastannut");
  if(results[1].status==="fulfilled"){
   const raw=results[1].value,arr=Array.isArray(raw)?raw:(raw.events||raw.items||raw.data||[]);
   if(Array.isArray(arr)){combined.push(...arr.map(x=>({...x,_feedSource:"BiQuote"})));biCount=arr.length;}
  }else errors.push(results[1].reason?.message||"BiQuote ei vastannut");
  if(!combined.length)throw new Error(errors.join("; ")||"Kumpikaan kalenterilähde ei palauttanut tapahtumia");
  const normalized=combined.map(normalizeEconomicEvent).filter(e=>e.event);
  const unique=new Map();
  normalized.forEach(e=>{
   const key=[e.event.toLowerCase().replace(/\s+/g," ").trim(),e.country.toUpperCase(),(e.time||"").slice(0,16)].join("|");
   const existing=unique.get(key);
   if(!existing||(!existing.eventId&&e.eventId))unique.set(key,e);
   else if(existing&&e.eventId&&!existing.eventId){existing.eventId=e.eventId;existing.raw=e.raw;existing.source="ShowMyTrades + BiQuote";}
  });
  econEvents=[...unique.values()];
  renderEconomicCalendar();econCheckAlerts();econLastFetch=Date.now();
  status.textContent=`${econEvents.length} tapahtumaa · ShowMyTrades ${showCount} · BiQuote ${biCount} · ${errors.length?"Osittainen yhteys: "+errors.join("; "):"molemmat lähteet toimivat"} · päivitys ${new Date().toLocaleTimeString("fi-FI")}`;
 }catch(e){
  status.textContent="Kalenterin haku epäonnistui: "+(e&&e.message?e.message:"tuntematon virhe");
  $("econEvents").innerHTML=`<div class="tiny">Tapahtumaluetteloa ei saatu ladattua: ${econEscape(e.message)}.</div>`;
 }
}

function startEconomicCalendar(){
 if(econTimer)clearInterval(econTimer);
 loadEconomicCalendar();
 econTimer=setInterval(()=>{if(document.visibilityState==="visible")loadEconomicCalendar();},900000);
}
document.getElementById("econSearch")?.addEventListener("input",renderEconomicCalendar);
document.getElementById("econDateFilter")?.addEventListener("change",renderEconomicCalendar);
document.getElementById("econDateClear")?.addEventListener("click",()=>{const d=document.getElementById("econDateFilter");if(d)d.value="";renderEconomicCalendar();});
document.addEventListener("visibilitychange",()=>{if(document.visibilityState==="visible"&&Date.now()-econLastFetch>900000)loadEconomicCalendar();});
setInterval(updateEconomicCountdowns,1000);

const marketCategoryAssets={
 crypto:["BINANCE:BTCUSDT.P","BINANCE:ETHUSDT.P","BINANCE:BNBUSDT.P","BINANCE:SOLUSDT.P","BINANCE:XRPUSDT.P","BINANCE:ADAUSDT.P","BINANCE:DOGEUSDT.P","BINANCE:AVAXUSDT.P","BINANCE:LINKUSDT.P","BINANCE:DOTUSDT.P"],
 forex:["OANDA:EURUSD","OANDA:GBPUSD","OANDA:USDJPY","OANDA:AUDUSD","OANDA:USDCAD","OANDA:USDCHF","OANDA:NZDUSD","OANDA:EURJPY","OANDA:EURGBP"],
 commodities:["OANDA:XAUUSD","OANDA:XAGUSD","TVC:USOIL","TVC:UKOIL"],
 indices:["TVC:SPX","NASDAQ:NDX","DJ:DJI","TVC:DAX","TVC:NI225","TVC:UKX"],
 stocks:["NASDAQ:AAPL","NASDAQ:MSFT","NASDAQ:NVDA","NASDAQ:AMZN","NASDAQ:GOOGL","NASDAQ:TSLA","NYSE:BRK.B"],
 etfs:["AMEX:SPY","NASDAQ:QQQ","AMEX:GLD","AMEX:SLV","AMEX:VOO"]
};
const marketCategoryNames={crypto:"Krypto",forex:"Forex",commodities:"Commodities",indices:"Indeksit",stocks:"Osakkeet",etfs:"ETF:t"};
function openMarketCategory(key){
 const panel=$("categoryResults"),tiles=document.querySelectorAll("[data-category]");
 if(!panel)return;
 tiles.forEach(t=>t.classList.toggle("active",t.dataset.category===key));
 const items=marketCategoryAssets[key]||[];
 panel.style.display="block";
 panel.innerHTML=`<div class="categoryResultsHead"><b>${marketCategoryNames[key]||key} · ${items.length} kohdetta</b><button type="button" id="closeCategory" class="secondary">Sulje ✕</button></div>`+
 items.map(sym=>`<button class="categoryAsset" type="button" data-category-asset="${sym}"><span>${sym.split(":").pop().replace(".P","")}</span><small>${sym.split(":")[0]} · Avaa analyysi →</small></button>`).join("");
 $("closeCategory").onclick=()=>{panel.style.display="none";tiles.forEach(t=>t.classList.remove("active"));};
 panel.querySelectorAll("[data-category-asset]").forEach(btn=>btn.onclick=()=>{
  const sym=btn.dataset.categoryAsset,select=$("assetSelect");
  let opt=[...select.options].find(o=>o.value===sym);
  if(!opt){opt=document.createElement("option");opt.value=sym;opt.textContent=sym+" · "+(marketCategoryNames[key]||key);select.add(opt);}
  select.value=sym;switchAsset(sym);window.scrollTo({top:0,behavior:"smooth"});
 });
}
document.querySelectorAll("[data-category]").forEach(tile=>tile.addEventListener("click",()=>openMarketCategory(tile.dataset.category)));

let radarTimer=null,radarBusy=false;
async function refreshMarketRadar(){
 if(radarBusy)return;radarBusy=true;
 try{
  const base=binanceUrls().base;
  const url=base.replace(/\/klines\/?$/,"/ticker/24hr");
  const response=await fetch(url,{cache:"no-store"});
  if(!response.ok)throw new Error("HTTP "+response.status);
  const rows=await response.json();
  const liquid=rows.filter(x=>x.symbol.endsWith("USDT")&&!/(UP|DOWN|BULL|BEAR)USDT$/.test(x.symbol)&&Number(x.quoteVolume)>5000000&&Number(x.lastPrice)>0);
  const movers=[...liquid].sort((a,b)=>Number(b.priceChangePercent)-Number(a.priceChangePercent));
  const g=movers[0],l=movers[movers.length-1],v=[...liquid].sort((a,b)=>Number(b.quoteVolume)-Number(a.quoteVolume))[0];
  const mood=liquid.filter(x=>Number(x.priceChangePercent)>0).length/liquid.length;
  const fmtPct=n=>(Number(n)>=0?"+":"")+Number(n).toFixed(2)+"%";
  const fmtVol=n=>Number(n)>=1e9?(Number(n)/1e9).toFixed(2)+" mrd $":(Number(n)/1e6).toFixed(0)+" milj. $";
  $("radarGainer").textContent=g?g.symbol.replace("USDT","") +" "+fmtPct(g.priceChangePercent):"--";
  $("radarLoser").textContent=l?l.symbol.replace("USDT","")+" "+fmtPct(l.priceChangePercent):"--";
  $("radarVolume").textContent=v?v.symbol.replace("USDT","")+" · "+fmtVol(v.quoteVolume):"--";
  $("radarMood").textContent=Number.isFinite(mood)?Math.round(mood*100)+"% pareista nousussa":"--";
  // Kiinnostavuuspisteet yhdistävät 24 h liikkeen ja kaupankäyntivolyymin.
  // Tämä on seulontalista, ei BUY/SELL-signaali.
  const ranked=liquid.map(x=>{
   const move=Math.abs(Number(x.priceChangePercent));
   const volume=Number(x.quoteVolume);
   const score=move*Math.log10(Math.max(volume,1));
   return {...x,interestScore:score};
  }).sort((a,b)=>b.interestScore-a.interestScore).slice(0,10);
  $("radarList").innerHTML=ranked.map((x,i)=>{
   const ticker=x.symbol.replace("USDT","");
   const up=Number(x.priceChangePercent)>=0;
   return `<button class="radarCard" type="button" data-radar-symbol="${x.symbol}">
    <div style="display:flex;justify-content:space-between;gap:6px"><small>#${i+1} KIINNOSTAVA</small><small>${up?"NOUSU":"LASKU"}</small></div>
    <b>${ticker}/USDT</b>
    <strong class="${up?"radarUp":"radarDown"}">${fmtPct(x.priceChangePercent)}</strong>
    <small>Vaihto ${fmtVol(x.quoteVolume)}</small>
   </button>`;
  }).join("");
  $("radarList").querySelectorAll("[data-radar-symbol]").forEach(btn=>btn.addEventListener("click",()=>{
   const pair=btn.dataset.radarSymbol;
   const tv="BINANCE:"+pair.replace("USDT","USDT.P");
   const select=$("assetSelect");
   let option=[...select.options].find(o=>o.value===tv);
   if(!option){option=document.createElement("option");option.value=tv;option.textContent=tv+" · Binance radar";select.add(option);}
   select.value=tv;switchAsset(tv);
   window.scrollTo({top:0,behavior:"smooth"});
  }));
  $("radarUpdated").textContent="Päivitetty "+new Date().toLocaleTimeString("fi-FI");
 }catch(e){
  $("radarUpdated").textContent="Tutka ei juuri nyt saatavilla";
  $("radarList").innerHTML='<div class="tiny">Binancen markkinatutkaa ei saatu ladattua. Muu sovellus voi silti toimia.</div>';
 }finally{radarBusy=false;}
}
refreshMarketRadar();
if(radarTimer)clearInterval(radarTimer);
radarTimer=setInterval(refreshMarketRadar,180000);

function priceDecimalsForSymbol(value){ return priceDecimalsForValue(value??lastPrice??1); }
function fmtLevel(n){
 return Number.isFinite(Number(n))?Number(n).toLocaleString("fi-FI",{minimumFractionDigits:priceDecimalsForSymbol(n),maximumFractionDigits:priceDecimalsForSymbol(n)}):"--";
}
function candlesForTimeframe(iv){
 if(binanceCandles&&binanceCandles[iv])return binanceCandles[iv];
 if(biquoteCandles&&biquoteCandles[iv])return biquoteCandles[iv];
 const x=data&&data[iv];return x&&Array.isArray(x.candles)?x.candles:[];
}
function renderDailyLevels(){
 const grid=$("timeframeLevelsGrid");if(!grid)return;
 const cards=TF.map(([iv,label])=>{
  const candles=candlesForTimeframe(iv),prev=candles.length>1?candles[candles.length-2]:null;
  if(!prev)return `<div class="panel" style="margin:0;padding:10px"><b>${label}</b><div class="tiny">Kynttilädata puuttuu</div></div>`;
  const H=Number(prev.h),L=Number(prev.l),C=Number(prev.c);
  if(![H,L,C].every(Number.isFinite))return `<div class="panel" style="margin:0;padding:10px"><b>${label}</b><div class="tiny">Virheellinen kynttilädata</div></div>`;
  const P=(H+L+C)/3,R1=2*P-L,S1=2*P-H,R2=P+(H-L),S2=P-(H-L);
  return `<div class="panel" style="margin:0;padding:10px"><div style="display:flex;justify-content:space-between;gap:6px"><b>${label}</b><span class="tiny">Pivot ${fmtLevel(P)}</span></div><div class="tiny" style="display:grid;grid-template-columns:1fr 1fr;gap:5px;margin-top:7px"><span>SUPPORT 1<br><b style="color:#35c98a">${fmtLevel(S1)}</b></span><span>SUPPORT 2<br><b style="color:#35c98a">${fmtLevel(S2)}</b></span><span>RESISTANCE 1<br><b style="color:#ff6475">${fmtLevel(R1)}</b></span><span>RESISTANCE 2<br><b style="color:#ff6475">${fmtLevel(R2)}</b></span></div></div>`;
 }).join("");
 grid.innerHTML=cards;
 const available=TF.filter(([iv])=>candlesForTimeframe(iv).length>1).length;
 $("dailyLevelsLabel").textContent="Kohde: "+symbol+" · edellisen sulkeutuneen kynttilän klassiset pivot-tasot";
 $("dailyLevelsStatus").textContent=available+"/"+TF.length+" aikajaksoa päivitetty · "+new Date().toLocaleTimeString("fi-FI");
 $("dailyPivot").textContent="Tasot lasketaan erikseen M1-, M5-, M15-, M30-, H1-, H4- ja D1-kynttilöistä.";
}

async function refreshBinance(){
 if(binanceBusy)return;binanceBusy=true;
 const ticker=binanceTicker(),{base,wsBase}=binanceUrls(),intervals=["1m","5m","15m","30m","1h","4h","1d"];
 try{
  $("tdStatus").textContent="Binance: ladataan maksutonta kynttilähistoriaa…";
  $("status").textContent=`Haetaan ${ticker} · Binance julkinen markkinadata`;
  $("connection").textContent="● BINANCE YHDISTÄÄ";$("connection").style.color="#f0b84e";
  const pairs=await Promise.all(intervals.map(async iv=>{
   const u=new URL(base);u.searchParams.set("symbol",ticker);u.searchParams.set("interval",iv);u.searchParams.set("limit","100");
   const r=await fetch(u.toString(),{cache:"no-store"});if(!r.ok)throw new Error("Binance kynttilähaku HTTP "+r.status);
   const raw=await r.json();if(!Array.isArray(raw))throw new Error("Binance ei palauttanut kynttilädataa");
   return [iv,raw.map(parseK)];
  }));
  const next={};binanceCandles={};for(const [iv,candles] of pairs){binanceCandles[iv]=candles;next[iv]=analyzeTF(candles);}
  data=next;lastPrice=binanceCandles["1m"].at(-1).c;
  renderDailyLevels();
  const daily=binanceCandles["1d"],prev=daily.length>1?daily.at(-2).c:null;
  const change24=prev?((lastPrice-prev)/prev)*100:null;
  const m15=next["15m"];lastAnalysis={price:lastPrice,change24,signal:weightedSignal(),m15,regime:m15.trend==="UP"?"Nousutrendi":m15.trend==="DOWN"?"Laskutrendi":"Sivuttaisliike",patterns:patterns(m15),forecast:forecast(m15.candles)};
  lastSignal=lastAnalysis.signal.signal;render();renderDailyLevels();checkPaperOpenAgainstPrice();paperOnNewClosedBar();
  ["paperToggle","runBacktest","trackBuy","trackSell","entryWatchBuy","entryWatchSell"].forEach(id=>{const b=$(id);if(b){b.disabled=false;b.title="Binancen julkinen markkinadata ladattu.";b.style.opacity="1";}});
  $("tvDataNotice").style.display="none";$("twelveDataPanel").style.display="none";
  $("connection").textContent="● BINANCE LIVE";$("connection").style.color="#35c98a";
  $("tdStatus").textContent=`Binance-yhteys valmisteltu: ${ticker} · 7 aikajaksoa · reaaliaikainen WebSocket.`;
  $("status").textContent=`${symbol}: Binance-historia ladattu. Reaaliaikainen hintavirta käynnistetään.`;
  $("refreshState").textContent="Binance WebSocket · reaaliaikainen";
  connectBinanceStream(ticker,intervals,wsBase);
 }catch(err){
  $("connection").textContent="● BINANCE VIRHE";$("connection").style.color="#ff6475";
  $("tdStatus").textContent="Binance-datan haku epäonnistui: "+err.message;
  $("status").textContent="Binance-yhteys ei onnistunut. Tarkista verkkoyhteys tai kokeile myöhemmin.";
 }finally{binanceBusy=false;}
}
function connectBinanceStream(ticker,intervals,wsBase){
 if(ws){try{ws.onclose=null;ws.close()}catch(e){}}
 const streams=intervals.map(iv=>ticker.toLowerCase()+"@kline_"+iv).join("/");
 try{
  ws=new WebSocket(wsBase+streams);
  ws.onopen=()=>{$("connection").textContent="● BINANCE LIVE";$("connection").style.color="#35c98a";$("status").textContent=`${ticker}: reaaliaikainen Binance-yhteys toimii.`;};
  ws.onmessage=(event)=>{
   try{
    const msg=JSON.parse(event.data),d=msg.data||msg,k=d.k;if(!k)return;
    const iv=k.i;applyBinanceCandle(iv,k);lastPrice=Number(k.c);
    if(data["1m"]&&data["15m"]){const m15=data["15m"],daily=binanceCandles["1d"]||[],prev=daily.length>1?daily.at(-2).c:null,change24=prev?((lastPrice-prev)/prev)*100:null;
     lastAnalysis={price:lastPrice,change24,signal:weightedSignal(),m15,regime:m15.trend==="UP"?"Nousutrendi":m15.trend==="DOWN"?"Laskutrendi":"Sivuttaisliike",patterns:patterns(m15),forecast:forecast(m15.candles)};
     lastSignal=lastAnalysis.signal.signal;render();checkPaperOpenAgainstPrice();if(k.x)paperOnNewClosedBar();
    }
    $("updated").textContent=`Reaaliaikainen · Binance ${new Date().toLocaleTimeString("fi-FI")}`;
   }catch(e){}
  };
  ws.onerror=()=>{$("connection").textContent="● BINANCE YHTEYSVIRHE";$("connection").style.color="#ff6475";};
  ws.onclose=()=>{if(running&&(isBinancePerp()||isBinanceSpot())){ $("connection").textContent="● YHDISTÄÄ UUDELLEEN";$("connection").style.color="#f0b84e";binanceReconnectTimer=setTimeout(()=>connectBinanceStream(ticker,intervals,wsBase),5000);}};
 }catch(e){$("tdStatus").textContent="WebSocket ei käynnistynyt: "+e.message;}
}
function biQuoteIntervals(){return {"1m":"1m","5m":"5m","15m":"15m","30m":"30m","1h":"1h","4h":"4h","1d":"1d"};}
function biQuoteBar(b){return {t:Date.parse(b.openTime),o:Number(b.open),h:Number(b.high),l:Number(b.low),c:Number(b.close),v:Number(b.volume||b.tickVolume||0),isOpen:!!b.isOpen};}
async function refreshBiQuote(){
 if(biquoteBusy)return;biquoteBusy=true;
 const name=getBiQuoteSymbol(symbol);if(!name){biquoteBusy=false;return false;}
 try{
  $("connection").textContent="● BIQUOTE YHDISTÄÄ";$("connection").style.color="#f0b84e";
  $("status").textContent=`Haetaan ${name} · maksuton BiQuote-markkinadata`;
  const intervals=biQuoteIntervals();
  // Älä hylkää koko EURUSD-yhteyttä yhden puuttuvan aikajakson vuoksi.
  // M15, H1 ja H4 ovat signaalin vähimmäisvaatimukset; muut aikajaksot ovat lisädataa.
  const results=await Promise.allSettled(Object.entries(intervals).map(async([iv,apiIv])=>{
   const url=`https://biquote.io/api/${encodeURIComponent(name)}/ohlc?interval=${apiIv}&limit=200`;
   const json=await getJSON(url);
   if(!Array.isArray(json.bars))throw new Error(json.message||`${name} ${iv}: OHLC-vastaus ei sisältänyt bars-taulukkoa.`);
   const candles=json.bars.map(biQuoteBar).filter(c=>[c.t,c.o,c.h,c.l,c.c].every(Number.isFinite)).reverse();
   if(candles.length<56)throw new Error(`${iv}: vain ${candles.length} kelvollista kynttilää.`);
   return [iv,candles];
  }));
  biquoteCandles={};const next={},missing=[];
  results.forEach((result,index)=>{
   const iv=Object.keys(intervals)[index];
   if(result.status!=="fulfilled"){missing.push(`${iv}: ${result.reason?.message||"data puuttuu"}`);return;}
   const [key,candles]=result.value;
   try{biquoteCandles[key]=candles;next[key]=analyzeTF(candles);}
   catch(err){missing.push(`${key}: ${err.message}`);}
  });
  const required=["15m","1h","4h"],missingRequired=required.filter(iv=>!next[iv]);
  if(missingRequired.length)throw new Error(`EURUSD:n signaalin pääaikajakso puuttuu (${missingRequired.join(", ")}). ${missing.join(" | ")}`);
  data=next;renderDailyLevels();
  const tick=await getJSON(`https://biquote.io/api/${encodeURIComponent(name)}?allowStale=false`);
  lastPrice=Number(tick.mid||((Number(tick.bid)+Number(tick.ask))/2));
  if(!Number.isFinite(lastPrice)||lastPrice<=0)throw new Error("BiQuote ei palauttanut kelvollista EURUSD-hintaa.");
  if(tick.stale===true||tick.marketState==="closed")throw new Error("EURUSD-noteeraus on vanhentunut tai markkina on suljettu. Uutta live-hintaa ei näytetä.");
  const daily=biquoteCandles["1d"],prev=daily.length>1?daily.at(-2).c:null;
  const change24=prev?((lastPrice-prev)/prev)*100:null,m15=next["15m"];
  lastAnalysis={price:lastPrice,change24,signal:weightedSignal(),m15,regime:m15.trend==="UP"?"Nousutrendi":m15.trend==="DOWN"?"Laskutrendi":"Sivuttaisliike",patterns:patterns(m15),forecast:forecast(m15.candles)};
  lastSignal=lastAnalysis.signal.signal;render();renderDailyLevels();checkPaperOpenAgainstPrice();paperOnNewClosedBar();
  ["paperToggle","runBacktest","trackBuy","trackSell","entryWatchBuy","entryWatchSell"].forEach(id=>{const b=$(id);if(b){b.disabled=false;b.title="BiQuote-historiadata ladattu.";b.style.opacity="1";}});
  $("twelveDataPanel").style.display="none";$("tvDataNotice").style.display="none";
  $("connection").textContent="● BIQUOTE LIVE";$("connection").style.color="#35c98a";
  $("updated").textContent=`BiQuote · ${new Date(tick.timestamp||Date.now()).toLocaleTimeString("fi-FI")} · ${tick.marketState||"open"}${tick.stale?" · vanha noteeraus":""}`;
  $("tdStatus").textContent=`BiQuote-yhteys toimii: ${name} · ${Object.keys(next).length}/7 aikajaksoa ladattu${missing.length?` · puuttuu: ${missing.join(" | ")}`:""} · ${tick.source||"markkinasyöte"}.`;
  $("status").textContent=`${name}: hintadata ladattu. Käynnistetään reaaliaikainen hintavirta.`;
  $("refreshState").textContent="BiQuote SignalR · reaaliaikainen";
  await connectBiQuote(name);
  return true;
 }catch(err){
  $("connection").textContent="● BIQUOTE DATA EI SAATAVILLA";$("connection").style.color="#f0b84e";
  $("tdStatus").textContent=`BiQuote ei saanut symbolia ${name}: ${err.message}`;
  $("status").textContent="Tämä symboli ei ole tällä hetkellä saatavilla BiQuoten maksuttomasta syötteestä. Voit kokeilla Twelve Data -avainta, jos sinulla on sellainen.";
  return false;
 }finally{biquoteBusy=false;}
}
async function connectBiQuote(name){
 if(!window.signalR){$("tdStatus").textContent="BiQuote-historia ladattu, mutta SignalR-kirjasto ei latautunut. Tarkista internetyhteys.";return;}
 if(biquoteConnection){try{await biquoteConnection.stop()}catch(e){}biquoteConnection=null;}
 const conn=new signalR.HubConnectionBuilder().withUrl("https://biquote.io/hubs/tick").withAutomaticReconnect().build();
 biquoteConnection=conn;
 conn.on("ReceiveTick",tick=>{if(!tick||tick.symbol!==name)return;applyBiQuoteTick(tick);});
 conn.onreconnecting(()=>{$("connection").textContent="● BIQUOTE YHDISTÄÄ UUDELLEEN";$("connection").style.color="#f0b84e";});
 conn.onreconnected(async()=>{try{await conn.invoke("Subscribe",[name]);$("connection").textContent="● BIQUOTE LIVE";$("connection").style.color="#35c98a";}catch(e){}});
 try{await conn.start();await conn.invoke("Subscribe",[name]);$("connection").textContent="● BIQUOTE LIVE";$("connection").style.color="#35c98a";$("status").textContent=`${name}: reaaliaikainen BiQuote-yhteys toimii.`;}
 catch(e){$("tdStatus").textContent=`Historiadata toimii, mutta reaaliaikainen yhteys ei käynnistynyt: ${e.message}`;}
}
function applyBiQuoteTick(tick){
 const price=Number(tick.mid||((Number(tick.bid)+Number(tick.ask))/2));if(!Number.isFinite(price)||price<=0)return;
 lastPrice=price;const time=Date.parse(tick.timestamp)||Date.now();let newBar=false;
 const ms={"1m":60000,"5m":300000,"15m":900000,"30m":1800000,"1h":3600000,"4h":14400000,"1d":86400000};
 for(const iv of Object.keys(ms)){
  const arr=biquoteCandles[iv];if(!arr?.length)continue;const start=Math.floor(time/ms[iv])*ms[iv];let bar=arr[arr.length-1];
  if(bar.t!==start){bar={t:start,o:price,h:price,l:price,c:price,v:0,isOpen:true};arr.push(bar);if(arr.length>150)arr.shift();newBar=true;}
  else{bar.h=Math.max(bar.h,price);bar.l=Math.min(bar.l,price);bar.c=price;bar.isOpen=true;}
  try{data[iv]=analyzeTF(arr);}catch(e){}
 }
 const daily=biquoteCandles["1d"]||[],prev=daily.length>1?daily[daily.length-2].c:null,change24=prev?((price-prev)/prev)*100:null,m15=data["15m"];
 renderDailyLevels();
 if(m15){lastAnalysis={price,change24,signal:weightedSignal(),m15,regime:m15.trend==="UP"?"Nousutrendi":m15.trend==="DOWN"?"Laskutrendi":"Sivuttaisliike",patterns:patterns(m15),forecast:forecast(m15.candles)};lastSignal=lastAnalysis.signal.signal;render();checkPaperOpenAgainstPrice();if(newBar)paperOnNewClosedBar();}
 $("updated").textContent=`Reaaliaikainen · BiQuote ${new Date(time).toLocaleTimeString("fi-FI")}`;
 if(tick.marketState==="closed"){$("connection").textContent="● MARKKINA KIINNI · VIIMEINEN HINTA";$("connection").style.color="#f0b84e";}
}
async function refresh(){
 if(isBinancePerp()||isBinanceSpot()){await refreshBinance();return;}
 const biQuoteSymbol=getBiQuoteSymbol(symbol);
 if(biQuoteSymbol){const ok=await refreshBiQuote();if(ok)return;if(!tdApiKey)return;}
 if($("twelveDataPanel"))$("twelveDataPanel").style.display="";
 if($("twelveDataPanel"))$("twelveDataPanel").style.display="";
 if(!tdApiKey){
  $("price").textContent="--";$("signal").textContent="HOLD";$("confidence").textContent="Lisää Twelve Data API-avain";
  $("status").textContent="Twelve Data -yhteys ei ole vielä käytössä. Lisää API-avain yllä.";
  $("connection").textContent="● EI YHTEYTTÄ";$("connection").style.color="#f0b84e";return;
 }
 if(tdBusy)return;
 tdBusy=true;$("status").textContent=`Haetaan ${symbol} · 7 aikajaksoa Twelve Datasta…`;
 $("tdStatus").textContent="Haetaan markkinadataa…";$("connection").textContent="● HAETAAN";$("connection").style.color="#f0b84e";
 try{
  const mapping=currentTdMapping();
  if(!mapping.symbol)throw new Error("Twelve Data -symboli puuttuu.");
  const entries=await Promise.all(Object.entries(TD_INTERVALS).map(async([iv,tdIv])=>[iv,await tdRequest(mapping.symbol,tdIv,mapping.exchange)]));
  const nextData={};for(const [iv,result] of entries)nextData[iv]=analyzeTF(result.candles);
  data=nextData;lastPrice=nextData["1m"].candles.at(-1).c;
  const daily=nextData["1d"].candles,prevDaily=daily.length>1?daily.at(-2).c:null;
  const change24=prevDaily?((lastPrice-prevDaily)/prevDaily)*100:null;
  if(mapping.symbol!=="EUR/USD"){
   try{const fx=await tdRequest("EUR/USD","1min","");eurusdt=fx.candles.at(-1).c;}catch(e){}
  }else eurusdt=lastPrice;
  const signal=weightedSignal(),m15=nextData["15m"];
  lastAnalysis={price:lastPrice,change24,signal,m15,regime:m15.trend==="UP"?"Nousutrendi":m15.trend==="DOWN"?"Laskutrendi":"Sivuttaisliike",patterns:patterns(m15),forecast:forecast(m15.candles)};
  lastSignal=signal.signal;render();renderDailyLevels();checkPaperOpenAgainstPrice();paperOnNewClosedBar();
  ["paperToggle","runBacktest","trackBuy","trackSell","entryWatchBuy","entryWatchSell"].forEach(id=>{const b=$(id);if(b){b.disabled=false;b.title="Hintadata ladattu Twelve Datasta.";b.style.opacity="1";}});
  $("tvDataNotice").style.display="none";
  $("connection").textContent="● TWELVE DATA";$("connection").style.color="#35c98a";
  const time=new Date().toLocaleTimeString("fi-FI");
  $("updated").textContent=`Päivitetty ${time} · ${mapping.symbol} · Twelve Data`;
  $("tdStatus").textContent=`Yhteys toimii: ${mapping.symbol} · 7 aikajaksoa ladattu · viimeisin 1 min kynttilä ${time}.`;
  $("status").textContent=`${symbol}: hintadata ladattu. Seuraava automaattinen päivitys noin 20 minuutin kuluttua.`;
  $("refreshState").textContent="Twelve Data · päivitys 20 min välein";
 }catch(err){
  $("price").textContent="--";$("signal").textContent="HOLD";$("confidence").textContent="Ei varmennettua dataa";
  $("connection").textContent="● DATA VIRHE";$("connection").style.color="#ff6475";
  $("tdStatus").textContent="Datayhteys epäonnistui: "+err.message;
  $("status").textContent="Tarkista API-avain, symboli, pörssi ja Basic-tilauksen käyttöoikeus. Paikallinen HTML voi myös aiheuttaa selaimen CORS-rajoituksen.";
  $("updated").textContent="Hintaa ei voitu vahvistaa";
 }finally{tdBusy=false}
}
function connectWS(){ if(isBinancePerp()||isBinanceSpot())refreshBinance(); }

function emaAt(values,period,end){
 const start=Math.max(0,end-period*4),slice=values.slice(start,end+1);
 if(slice.length<period)return null;
 const k=2/(period+1);let e=slice[0];
 for(let i=1;i<slice.length;i++)e=slice[i]*k+e*(1-k);
 return e;
}
function atrAt(candles,end,period=14){
 if(end<period+1)return null;let sum=0;
 for(let i=end-period+1;i<=end;i++){
  const c=candles[i],p=candles[i-1];
  sum+=Math.max(c.h-c.l,Math.abs(c.h-p.c),Math.abs(c.l-p.c));
 }
 return sum/period;
}
function historicalSide(candles,i){
 const closes=candles.slice(0,i+1).map(x=>x.c);
 const e20=emaAt(closes,20,i),e50=emaAt(closes,50,i),mom=closes[i]-closes[i-5];
 if(e20==null||e50==null)return "HOLD";
 if(e20>e50&&closes[i]>e20&&mom>0)return "BUY";
 if(e20<e50&&closes[i]<e20&&mom<0)return "SELL";
 return "HOLD";
}
function runHistoricalBacktest(){
 const iv=$("testTf").value,tf=data[iv],capital=Math.max(1,Number($("paperCapital").value)||500);
 if(!tf||tf.candles.length<65){$("backtestNote").textContent="Aikajaksolta ei ole riittävästi kynttilöitä. Päivitä markkinadata ja yritä uudelleen.";return}
 const c=tf.candles,results=[];let equity=capital,peak=capital,maxDD=0,grossWin=0,grossLoss=0;
 for(let i=55;i<c.length-2;i++){
  const side=historicalSide(c,i);if(side==="HOLD")continue;
  const entry=c[i+1].o,atrNow=atrAt(c,i),risk=atrNow*1.5;
  if(!Number.isFinite(risk)||risk<=0)continue;
  const sl=side==="BUY"?entry-risk:entry+risk,tp=side==="BUY"?entry+2*risk:entry-2*risk;
  let outcome="TIME",exit=entry,jEnd=Math.min(c.length-1,i+25);
  for(let j=i+1;j<=jEnd;j++){
   const bar=c[j],stopHit=side==="BUY"?bar.l<=sl:bar.h>=sl,takeHit=side==="BUY"?bar.h>=tp:bar.l<=tp;
   if(stopHit){outcome="LOSS";exit=sl;break}
   if(takeHit){outcome="WIN";exit=tp;break}
   if(j===jEnd)exit=bar.c;
  }
  const r=(side==="BUY"?exit-entry:entry-exit)/risk;
  const pnl=capital*.01*r;
  results.push({side,outcome,r,pnl});
  equity+=pnl;peak=Math.max(peak,equity);maxDD=Math.max(maxDD,(peak-equity)/peak*100);
  if(pnl>0)grossWin+=pnl;else grossLoss+=Math.abs(pnl);
  i=Math.max(i,jEnd-1);
 }
 const wins=results.filter(x=>x.pnl>0).length,net=results.reduce((s,x)=>s+x.pnl,0),pf=grossLoss?grossWin/grossLoss:(grossWin?Infinity:0);
 const sideRate=side=>{const a=results.filter(x=>x.side===side);return a.length?fmt(a.filter(x=>x.pnl>0).length/a.length*100,1)+"% ("+a.length+")":"--";};
 $("btTrades").textContent=String(results.length);
 $("btWin").textContent=results.length?fmt(wins/results.length*100,1)+"% ("+results.length+")":"--";
 $("btBuyWin").textContent=sideRate("BUY");
 $("btSellWin").textContent=sideRate("SELL");
 $("btPf").textContent=Number.isFinite(pf)?fmt(pf,2):grossWin?"∞":"--";
 $("btNet").textContent=results.length?fmt(net,2)+" €":"--";
 $("btNet").className=net>=0?"up":"down";
 $("btDd").textContent=results.length?fmt(maxDD,2)+"%":"--";
 $("backtestNote").textContent=`${iv.toUpperCase()} · ${c.length} sulkeutunutta kynttilää · ${results.length} simuloitua kauppaa. Kiinteä 1 % alkupääomasta per kauppa, SL 1,5 × ATR, TP 2R. Ei kulumallia; tulos ei ole ennuste.`;
}
function loadPaper(){
 try{
  paperTrades=JSON.parse(localStorage.getItem(paperKey("trades"))||"[]");
  const saved=JSON.parse(localStorage.getItem(paperKey("open"))||"null");
  paperOpen=Array.isArray(saved)?saved:(saved?[saved]:[]);
  // Migrate the older single-position format and preserve its original fields.
  paperOpen=paperOpen.map(pos=>{
   if(Number(pos.qty)>0&&Number(pos.marginEUR)>=0)return pos;
   const entry=Number(pos.entry)||0,risk=Math.max(Number(pos.risk)||0,entry*.0005,1e-9);
   const oldCapital=Math.max(1,Number(pos.capital)||500),lev=Math.max(1,Number(pos.lev)||1);
   const qty=oldCapital*.01*Math.max(eurusdt,1)/risk;
   return {...pos,qty,lev,marginEUR:qty*entry/Math.max(eurusdt,1e-9)/lev,riskEUR:oldCapital*.01,lastPnlEUR:0};
  });
  paperRunning=localStorage.getItem(paperKey("running"))==="true";
  lastPaperBar=Number(localStorage.getItem(paperKey("lastBar"))||0);
 }catch(e){paperTrades=[];paperOpen=[];paperRunning=false;lastPaperBar=0}
}
function savePaper(){
 try{
  localStorage.setItem(paperKey("trades"),JSON.stringify(paperTrades.slice(-500)));
  localStorage.setItem(paperKey("open"),JSON.stringify(paperOpen));
  localStorage.setItem(paperKey("running"),String(paperRunning));
  localStorage.setItem(paperKey("lastBar"),String(lastPaperBar));
 }catch(e){}
}
function paperMarginUsed(){
 // Yhteinen 10 000 € marginaalikatto kaikkien valittujen assettien välillä.
 let total=paperOpen.reduce((sum,p)=>sum+(Number(p.marginEUR)||0),0);
 try{
  for(let i=0;i<localStorage.length;i++){
   const key=localStorage.key(i);
   if(!key||!key.startsWith("goldProMulti_")||!key.endsWith("_open")||key===paperKey("open"))continue;
   const saved=JSON.parse(localStorage.getItem(key)||"[]");
   if(Array.isArray(saved))total+=saved.reduce((sum,p)=>sum+(Number(p.marginEUR)||0),0);
  }
 }catch(e){}
 return total;
}
function paperPnlAt(pos,price){
 const move=pos.side==="BUY"?price-pos.entry:pos.entry-price;
 return move*pos.qty/Math.max(eurusdt,1e-9);
}
function paintPaper(){
 const done=paperTrades.filter(x=>["CLOSED","WIN","LOSS"].includes(x.status)&&Number.isFinite(Number(x.pnl)));
 const wins=done.filter(x=>Number(x.pnl)>0).length,net=done.reduce((sum,x)=>sum+Number(x.pnl),0);
 const bySide=side=>done.filter(x=>x.side===side);
 const rate=arr=>arr.length?fmt(arr.filter(x=>Number(x.pnl)>0).length/arr.length*100,1)+"% ("+arr.length+")":"--";
 const used=paperMarginUsed(),free=Math.max(0,PAPER_BUDGET_EUR-used);
 const openPnl=paperOpen.reduce((sum,pos)=>sum+paperPnlAt(pos,Number(lastPrice)||pos.entry),0);
 $("paperStatus").textContent=paperRunning?"AUTOMAATTINEN · KÄYNNISSÄ":"Pysäytetty";
 $("paperWinAll").textContent=rate(done);
 $("paperWinBuy").textContent=rate(bySide("BUY"));
 $("paperWinSell").textContent=rate(bySide("SELL"));
 $("paperSummary").textContent=`Suljettuja ${done.length} · voittoja ${wins} · tappioita ${done.length-wins} · nettotulos ${fmt(net,2)} € ennen kuluja. Avoimia ${paperOpen.length} · marginaali ${fmt(used,2)} € / 10 000 € · vapaana ${fmt(free,2)} € · avoin P/L ${openPnl>=0?"+":""}${fmt(openPnl,2)} €. Riski enintään ${PAPER_RISK_EUR.toFixed(0)} € / kauppa.`;
 $("paperLog").innerHTML=[
  ...paperOpen.slice().reverse().map(pos=>`<div style="padding:5px 0;border-bottom:1px solid #333"><b>AVOIN ${pos.side}</b> · entry ${fmtEntryPrice(pos.entry)} · SL ${fmtEntryPrice(pos.sl)} · TP ${fmtEntryPrice(pos.tp)} · määrä ${fmt(pos.qty,4)} ${symbol} · marginaali ${fmt(pos.marginEUR,2)} €</div>`),
  ...done.slice(-8).reverse().map(x=>`<div style="padding:4px 0;border-bottom:1px solid #333">${x.side} · ${x.status} · ${fmt(x.pnl,2)} € · ${new Date(x.time).toLocaleString("fi-FI")}</div>`)
 ].join("");
 $("paperToggle").textContent=paperRunning?"Pysäytä automaattinen paper trading":"Käynnistä automaattinen paper trading";
}
function autoPaperSignal(c,i){
 if(i<55)return "HOLD";
 const closes=c.slice(0,i+1).map(x=>x.c),e20=emaAt(closes,20,i),e50=emaAt(closes,50,i);
 const mom=closes[i]-closes[i-5],rr=rsi(closes,14),bar=c[i];
 if(e20==null||e50==null)return "HOLD";
 if(e20>e50&&bar.c>e20&&mom>0&&rr>=52&&bar.c>bar.o)return "BUY";
 if(e20<e50&&bar.c<e20&&mom<0&&rr<=48&&bar.c<bar.o)return "SELL";
 return "HOLD";
}
function closeAutoPaperPosition(pos,bar,reason,exitPrice){
 const exit=Number(exitPrice),pnl=paperPnlAt(pos,exit);
 paperTrades.push({...pos,status:pnl>0?"WIN":"LOSS",exit,pnl,closeReason:reason,time:bar.t||Date.now()});
}
function checkPaperOpenAgainstPrice(){
 if(!paperOpen.length||!Number.isFinite(lastPrice))return;
 let changed=false;
 for(let i=paperOpen.length-1;i>=0;i--){
  const pos=paperOpen[i],price=lastPrice;
  const stopHit=pos.side==="BUY"?price<=pos.sl:price>=pos.sl;
  const takeHit=pos.side==="BUY"?price>=pos.tp:price<=pos.tp;
  if(stopHit||takeHit){
   closeAutoPaperPosition(pos,{t:Date.now()},stopHit?"SL":"TP",stopHit?pos.sl:pos.tp);
   paperOpen.splice(i,1);changed=true;
  }
 }
 if(changed)savePaper();
 paintPaper();
}
function paperOnNewClosedBar(){
 const iv=$("testTf").value,tf=data[iv];
 if(!tf||tf.candles.length<60)return;
 const c=tf.candles;
 if(!lastPaperBar){lastPaperBar=c.at(-1).t;savePaper();paintPaper();return;}
 const newBars=c.filter(x=>x.t>lastPaperBar);
 if(!newBars.length){paintPaper();return;}
 for(const bar of newBars){
  const i=c.findIndex(x=>x.t===bar.t);if(i<55)continue;
  // Conservative candle simulation: if both TP and SL are touched, SL is assumed first.
  for(let n=paperOpen.length-1;n>=0;n--){
   const pos=paperOpen[n],stopHit=pos.side==="BUY"?bar.l<=pos.sl:bar.h>=pos.sl;
   const takeHit=pos.side==="BUY"?bar.h>=pos.tp:bar.l<=pos.tp;
   if(stopHit||takeHit){
    closeAutoPaperPosition(pos,bar,stopHit?"SL":"TP",stopHit?pos.sl:pos.tp);
    paperOpen.splice(n,1);
   }else pos.lastPnlEUR=paperPnlAt(pos,bar.c);
  }
  if(paperRunning){
   const side=autoPaperSignal(c,i);
   const already=paperOpen.some(pos=>pos.side===side);
   if((side==="BUY"||side==="SELL")&&!already&&paperOpen.length<2){
    // The signal is evaluated on a closed candle. Use next candle open when
    // replaying missed bars; otherwise use current live price after the close.
    const entry=i+1<c.length?c[i+1].o:(Number(lastPrice)||bar.c);
    const atrNow=atrAt(c,i),stopDist=Math.max((atrNow||0)*1.5,entry*.0005);
    const lev=clamp(Number($("leverage")?.value)||1,1,100);
    const free=Math.max(0,PAPER_BUDGET_EUR-paperMarginUsed());
    const qtyRisk=(PAPER_RISK_EUR*eurusdt)/stopDist;
    const qtyMargin=free*eurusdt*lev/entry;
    const qty=Math.min(qtyRisk,qtyMargin);
    const marginEUR=qty*entry/Math.max(eurusdt,1e-9)/lev;
    if(Number.isFinite(qty)&&qty>0&&marginEUR<=free+0.01){
     const sl=side==="BUY"?entry-stopDist:entry+stopDist,tp=side==="BUY"?entry+2*stopDist:entry-2*stopDist;
     paperOpen.push({id:`${side}-${bar.t}`,side,entry,risk:stopDist,sl,tp,qty,lev,marginEUR,
      riskEUR:qty*stopDist/Math.max(eurusdt,1e-9),openedAt:bar.t,lastPnlEUR:0,tf:iv,capital:PAPER_BUDGET_EUR});
    }
   }
  }
  lastPaperBar=bar.t;
 }
 savePaper();paintPaper();
}
function togglePaper(){
 paperRunning=!paperRunning;
 if(paperRunning){
  const iv=$("testTf").value;
  if(!lastPaperBar)lastPaperBar=data[iv]?.candles?.at(-1)?.t||0;
  $("backtestNote").textContent=`Automaattinen paper trading etsii BUY- ja SELL-signaaleja ${iv.toUpperCase()}-kynttilöiden sulkeutuessa. Yhteinen marginaalibudjetti 10 000 €, riski enintään 200 € per kauppa.`;
 }else{
  $("backtestNote").textContent="Uusien kauppojen avaaminen pysäytetty. Avoimet simuloidut positiot jatkavat TP/SL-seurantaa sovelluksen ollessa auki.";
 }
 savePaper();paintPaper();
}
$("testTf").addEventListener("change",()=>{
 const iv=$("testTf").value;
 // Re-anchor the candle cursor whenever the timeframe changes, even while
 // paused, so a new selection never replays old candles as fresh signals.
 lastPaperBar=data[iv]?.candles?.at(-1)?.t||0;
 savePaper();
 $("backtestNote").textContent=`Aikajakso vaihdettu ${iv.toUpperCase()}. Uusia signaaleja seurataan tästä eteenpäin. Avoimien positioiden TP/SL-seuranta jatkuu.`;
});
async function fastRefresh(){ /* Disabled until a licensed/provider market feed is connected. */ }
function start(){running=true;refresh();clearInterval(refreshTimer);clearInterval(fastTimer);clearInterval(tdRefreshTimer);tdRefreshTimer=setInterval(()=>{if(running&&!isBinancePerp()&&!isBinanceSpot()&&!getBiQuoteSymbol(symbol)&&tdApiKey)refresh()},TD_REFRESH_MS);$("autoBtn").textContent="Keskeytä seuranta";$("refreshState").textContent=(isBinancePerp()||isBinanceSpot())?"Binance WebSocket · reaaliaikainen":getBiQuoteSymbol(symbol)?"BiQuote SignalR · reaaliaikainen":"Twelve Data · päivitys 20 min välein"}

function stop(){running=false;clearInterval(refreshTimer);clearInterval(fastTimer);clearInterval(tdRefreshTimer);clearTimeout(binanceReconnectTimer);clearTimeout(biquoteReconnectTimer);if(biquoteConnection){biquoteConnection.stop().catch(()=>{});biquoteConnection=null;}if(ws){ws.onclose=null;ws.close();ws=null;}$("autoBtn").textContent="Jatka seurantaa";$("refreshState").textContent="Seuranta keskeytetty"}
$("runBacktest").onclick=runHistoricalBacktest;
$("paperToggle").onclick=togglePaper;
loadPaper();paintPaper();
restoreTrackedPosition();updatePositionTracker();
loadAssetList();
if(tdApiKey)$("tdApiKey").value=tdApiKey;
$("tdConnect").addEventListener("click",()=>{
 const key=$("tdApiKey").value.trim();
 if(!key){$("tdStatus").textContent="Liitä ensin Twelve Data API-avain.";return;}
 tdApiKey=key;try{sessionStorage.setItem("tdApiKeySession",key)}catch(e){}
 refresh();
});
$("tdClear").addEventListener("click",()=>{
 tdApiKey="";$("tdApiKey").value="";try{sessionStorage.removeItem("tdApiKeySession")}catch(e){}
 data={};lastAnalysis=null;lastPrice=null;$("tdStatus").textContent="API-avain tyhjennetty tästä selainistunnosta.";refresh();
});
$("tdSymbol").addEventListener("change",()=>{if(tdApiKey)refresh()});
$("tdExchange").addEventListener("change",()=>{if(tdApiKey)refresh()});
$("status").textContent="Kryptojen reaaliaikainen data tulee Binancesta. Kulta, hopea ja tuetut valuutat tulevat BiQuotesta.";
start();
$("trackBuy").onclick=()=>startTrackedPosition("BUY");
$("trackSell").onclick=()=>startTrackedPosition("SELL");
$("closeTracked").onclick=endTrackedPosition;
$("refreshBtn").onclick=refresh;$("autoBtn").onclick=()=>running?stop():start();
document.querySelectorAll(".alertTf").forEach(el=>el.addEventListener("change",()=>{
 const names=[...document.querySelectorAll(".alertTf:checked")].map(x=>({ "5m":"M5","15m":"M15","1h":"H1"}[x.value]));
 $("alertTfStatus").textContent=names.length?"Hälytykset valittuna: "+names.join(", "):"Yhtään aikajaksoa ei ole valittu.";
 alertState={};alertPrimed=false;
}));
$("notifyBtn").onclick=async()=>{if(!("Notification"in window)){alert("Tämä selain ei tue ilmoituksia.");return}let p=await Notification.requestPermission();notifyReady=p==="granted";$("notifyBtn").textContent=notifyReady?"Ilmoitukset sallittu":"Salli ilmoitukset";$("status").textContent=notifyReady?"Ilmoitukset sallittu. BUY/SELL-signaalin muutos ilmoitetaan sovelluksen ollessa auki.":"Ilmoituslupaa ei myönnetty."};
["capital","riskPct","leverage","manualQty","atrMult"].forEach(id=>$(id).addEventListener("input",()=>{if(lastAnalysis)render()}));
$("chartTf").addEventListener("change",()=>{if(lastAnalysis)render();updateAssetLabels()});
const tvPanel=$("tvPanel"),tvMount=$("tvWidgetMount"),tvHeight=$("tvHeight"),tvFullscreen=$("tvFullscreen");
if(tvPanel&&tvMount&&tvHeight&&tvFullscreen){
 tvHeight.addEventListener("change",()=>{
  if(!tvPanel.classList.contains("tvExpanded")) tvMount.style.height=Number(tvHeight.value)+"px";
 });
 const setTvExpanded=(expanded)=>{
  tvPanel.classList.toggle("tvExpanded",expanded);
  document.body.classList.toggle("tvNoScroll",expanded);
  tvFullscreen.textContent=expanded?"Pienennä":"Koko näyttö";
  if(!expanded) tvMount.style.height=Number(tvHeight.value)+"px";
 };
 tvFullscreen.addEventListener("click",()=>setTvExpanded(!tvPanel.classList.contains("tvExpanded")));
 document.addEventListener("keydown",(ev)=>{if(ev.key==="Escape"&&tvPanel.classList.contains("tvExpanded"))setTvExpanded(false);});
}

$("planTf").addEventListener("change",()=>{if(lastAnalysis)render()});$("planTf").addEventListener("change",()=>{if(lastAnalysis)render()});
if("serviceWorker"in navigator && location.protocol.startsWith("http"))navigator.serviceWorker.register("./sw.js").catch(()=>{});
// ShowMyTrades-kalenteri: handlers are registered inside the same scope as its functions.
const econRefreshButton=$("econRefresh");
if(econRefreshButton) econRefreshButton.addEventListener("click",async()=>{
  econRefreshButton.disabled=true;
  econRefreshButton.classList.add("is-working");
  const oldLabel=econRefreshButton.textContent;
  econRefreshButton.textContent="Haetaan kalenteria…";
  try { await loadEconomicCalendar(); }
  finally { econRefreshButton.disabled=false; econRefreshButton.classList.remove("is-working"); econRefreshButton.textContent=oldLabel; }
});
const econNotifyButton=$("econNotify");
if(econNotifyButton) econNotifyButton.addEventListener("click",async()=>{
  if(!("Notification" in window)){ $("econStatus").textContent="Selain ei tue ilmoituksia"; return; }
  const permission=await Notification.requestPermission();
  $("econStatus").textContent=permission==="granted"?"Kalenteri-ilmoitukset sallittu": "Ilmoituslupaa ei myönnetty";
  econNotifyButton.textContent=permission==="granted"?"Ilmoitukset sallittu":"Salli kalenteri-ilmoitukset";
});
// Kalenteri käynnistyy samassa JavaScript-skoopissa kuin sen lataustoiminnot.
startEconomicCalendar();

// Käynnistys tapahtuu assettilistan latauksen jälkeen.
})();
setInterval(()=>{if(running&&lastAnalysis)render()},1000);
setInterval(()=>{if(running&&lastAnalysis&&data["5m"]&&data["15m"]&&data["1h"]&&data["4h"])updateMarketBrief()},60000);


;

(function(){
 function addCollapsers(){
  const panels=[...document.querySelectorAll('.panel, .grid')];
  panels.forEach((panel,i)=>{
   if(panel.dataset.collapsibleReady || panel.classList.contains('hero')) return;
   // Preserve the key live market summary on screen; other information panels start compact.
   const keepOpen=panel.id==='marketBriefPanel';
   const heading=panel.querySelector(':scope > .row h2, :scope > h2, :scope > h3');
   const title=heading ? heading.textContent.trim() : (panel.id==='assetPanel'?'MARKKINAN VALINTA':panel.id==='tvDataNotice'?'MARKKINADATAN HUOMAUTUS':'LISÄTIEDOT');
   const bar=document.createElement('div');
   bar.className='collapseBar';
   const label=document.createElement('div');
   label.className='collapseTitle';
   label.textContent=title;
   const btn=document.createElement('button');
   btn.type='button';
   btn.className='collapseBtn';
   btn.setAttribute('aria-expanded',keepOpen?'true':'false');
   const body=document.createElement('div');
   body.className='collapseBody'+(keepOpen?'':' isCollapsed');
   // Keep existing panel contents and event-bound elements intact inside the body.
   while(panel.firstChild) body.appendChild(panel.firstChild);
   // Add a concise, panel-specific guide inside every collapsible section.
   const guides = {
    'MARKKINATUTKA':'Tämä näkymä seuloo markkinoita ja nostaa esiin voimakkaimmat nousijat, laskijat sekä aktiiviset kohteet. Muutos kuvaa valitun jakson hintakehitystä, kun taas vaihto kertoo kaupankäynnin aktiivisuudesta. Tutka auttaa löytämään analysoitavia kohteita, mutta ei yksin anna osto- tai myyntikäskyä.',
    'UUTISET & HINTAVAIKUTUS':'Tässä seurataan valittuun instrumenttiin liittyviä uutisia ja niiden mahdollista markkinavaikutusta. Tarkista uutisen aika, lähde, sisältö ja se, koskeeko uutinen juuri valittua omaisuuserää. Uutisotsikon vaikutusarvio on tulkinta, ei varma ennuste hinnan suunnasta.',
    'AI ECONOMIC CALENDAR':'Kalenteri näyttää talousjulkaisuja niiden ajankohdan, valuutan ja vaikutusluokan mukaan. Toteuma on julkaistu arvo, ennuste markkinoiden odotus ja edellinen aiempi julkaistu arvo. Toteuman ero ennusteeseen voi liikuttaa valuuttaa, mutta vaikutus riippuu myös odotuksista ja markkinatilanteesta.',
    'SUPPORT & RESISTANCE · KAIKKI AIKAJAKSOT':'Tuki- ja vastustasot ovat alueita, joilla hinta on aiemmin pysähtynyt, kääntynyt tai reagoinut. Tuki voi jarruttaa laskua ja vastus nousua, mutta kumpikaan ei takaa käännettä. Tason läpimurto ja sen jälkeinen vahvistus voivat kertoa liikkeen jatkumisesta. Suurempien aikajaksojen tasot ovat usein merkityksellisempiä.',
    'Maksuton markkinadata · BiQuote / Twelve Data varalla':'Tässä hallitaan tai näytetään markkinadatan lähteitä ja yhteyden tilaa. Lähteen nimi kertoo, mistä hintatietoa yritetään hakea. Tarkista viimeisin päivitysaika ja mahdolliset virheilmoitukset: vanha tai puuttuva data voi tehdä indikaattoreista epäluotettavia. Eri lähteiden hinnat voivat poiketa hieman toisistaan.',
    'Markkinahavainnot · päätöksenteon tuki':'Tämä osio kokoaa teknisiä havaintoja, jotka auttavat arvioimaan markkinan tilaa. Yksittäinen havainto ei ole itsenäinen kaupankäyntisignaali. Vertaa havaintoja trendiin, hintarakenteeseen, volyymiin ja riskitasoon ennen päätöstä.',
    'Moniaikajaksoinen trendi':'Tässä verrataan markkinan suuntaa useilla aikajaksoilla. Lyhyet aikajaksot näyttävät nopeita liikkeitä, pidemmät aikajaksot laajempaa trendiä. Yhteinen suunta vahvistaa trendinäkemystä; ristiriita kertoo epävarmuudesta, mutta yksittäinen vastakkainen aikajakso ei yksin mitätöi muuta analyysiä.',
    'Hinnan rakenne · BTCUSDT':'Hintarakenteessa tarkastellaan viimeisimpiä huippuja, pohjia ja mahdollisia rakenteellisia läpimurtoja. Nousevat huiput ja pohjat tukevat nousurakennetta, laskevat huiput ja pohjat laskurakennetta. Yksittäinen läpimurto voi olla myös väärä läpimurto, joten odota tarvittaessa sulkeutumista ja jatkovahvistusta.',
    'Pattern Recognition Matrix':'Tämä matriisi kokoaa tunnistettuja kynttilä- ja hintakuvioita. Kuvion nimi kertoo havaitusta muodostelmasta, mutta kuvio ei takaa sen oppikirjamaista lopputulosta. Tarkista kuvion sijainti trendissä, aikajakso, volyymi ja seuraavien kynttilöiden vahvistus.',
    'Markkinan ominaisuudet':'Mittaripalkit kuvaavat trendin voimakkuutta, volatiliteettia, volyymiaktiivisuutta, momentumia, markkinarakennetta ja suunta-arviota. Mittareiden asteikot eivät tarkoita samaa asiaa keskenään. Avaa tämän osion erillinen mittariselitys nähdäksesi jokaisen asteikon tulkinnan.',
    'Kauppasuunnitelma':'Kauppasuunnitelma kokoaa mahdollisen suunnan, sisääntulon, stop lossin ja tavoitehinnan. Entry on suunniteltu sisääntulo, stop loss riskin raja ja take profit tavoite. Tarkista, että hinnat vastaavat nykyistä markkinaa ja että position koko sopii omaan riskirajaasi. HOLD tarkoittaa, ettei ehdotettua kauppaa pidä avata.',
    'Strategian testaus ja paper trading':'Historiatesti käy läpi ladattua kynttilähistoriaa valitulla strategialla. Paper trading simuloi kauppoja ilman oikeaa toimeksiantoa. Tulokset riippuvat datan määrästä, kuluoletuksista ja testin säännöistä, eivätkä ne takaa tulevaa tuottoa. Tarkista myös, miten stop ja tavoite käsitellään saman kynttilän sisällä.',
    'Riskilaskuri':'Riskilaskuri arvioi position kokoa pääoman, riskiprosentin ja entryn sekä stop lossin välisen etäisyyden perusteella. Euromääräinen riski kertoo suunnitellun tappion, jos stop toteutuu suunnitellusti. Todellinen tappio voi olla suurempi liukuman, kulujen tai hintakatkon vuoksi.',
    'Ilmoitukset ja päivitykset':'Tässä hallitaan sovelluksen ilmoituksia ja seurantapäivityksiä. Ilmoitus kertoo, että jokin määritelty ehto on täyttynyt, ei että kauppa olisi automaattisesti kannattava. Varmista, että selain tai puhelin sallii ilmoitukset ja että sovellus pysyy käynnissä silloin kun päivityksiä tarvitaan.'
   };
   const guideText = guides[title] || (title==='LISÄTIEDOT'
    ? 'Tämä avattava osio sisältää lisäasetuksia tai täydentävää markkinatietoa. Tarkista kenttien nimet, yksiköt ja datan päivitysaika ennen arvojen muuttamista. Muuta vain niitä asetuksia, joiden vaikutuksen ymmärrät.'
    : 'Tämä osio kokoaa yhteen siihen liittyvät tiedot ja työkalut. Lue otsikot ja yksiköt ennen lukemien tulkintaa. Markkinadata voi viivästyä tai puuttua, joten tarkista yhteyden tila ja viimeisin päivitys ennen päätöksiä.');
   const guide=document.createElement('div');
   guide.className='collapseHint';
   guide.style.cssText='font-size:12px;line-height:1.55;color:#b9c1d2;background:rgba(255,255,255,.035);border-left:3px solid #c6a04b;padding:9px 11px;margin:0 0 12px;border-radius:0 8px 8px 0';
   guide.textContent=guideText;
   body.insertBefore(guide,body.firstChild);
   bar.append(label,btn);
   panel.append(bar,body);
   function update(){btn.textContent=body.classList.contains('isCollapsed')?'Näytä tiedot +':'Piilota tiedot −';btn.setAttribute('aria-expanded',String(!body.classList.contains('isCollapsed')));}
   btn.addEventListener('click',()=>{body.classList.toggle('isCollapsed');update();});
   update();
   panel.dataset.collapsibleReady='1';
  });
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',addCollapsers);
 else addCollapsers();
})();

;

(function(){
 let toastTimer=null;
 let toast=document.getElementById('appActionToast');
 if(!toast){toast=document.createElement('div');toast.id='appActionToast';toast.setAttribute('role','status');toast.setAttribute('aria-live','polite');document.body.appendChild(toast);}
 document.addEventListener('pointerdown',function(ev){const b=ev.target.closest('button');if(!b||b.disabled)return;b.classList.add('button-pressed');},{capture:true});
 ['pointerup','pointercancel','pointerleave'].forEach(type=>document.addEventListener(type,function(ev){const b=ev.target.closest&&ev.target.closest('button');if(b)b.classList.remove('button-pressed');},{capture:true}));
 document.addEventListener('click',function(ev){
  const b=ev.target.closest('button');if(!b)return;
  b.classList.remove('button-pressed');
  const label=(b.innerText||b.getAttribute('aria-label')||b.title||'Painike').replace(/\s+/g,' ').trim();
  toast.textContent='✓ '+(label.length>54?label.slice(0,51)+'…':label);
  toast.classList.add('show');
  clearTimeout(toastTimer);toastTimer=setTimeout(()=>toast.classList.remove('show'),1700);
 },false);
})();

;

(()=>{
 const $=id=>document.getElementById(id);
 const endpoint=$("goldAiChatEndpoint"), status=$("goldAiChatStatus"), box=$("goldAiChatMessages"), input=$("goldAiChatInput"), send=$("goldAiChatSend"), count=$("goldAiChatCount");
 if(!endpoint||!status||!box||!input||!send)return;
 let history=[];
 const saved=localStorage.getItem("goldAiChatEndpoint")||"";
 endpoint.value=saved;
 const safe=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
 const add=(role,text)=>{
  const item=document.createElement("div");
  item.style.cssText="margin:8px 0;padding:9px 11px;border-radius:10px;max-width:95%;white-space:pre-wrap;overflow-wrap:anywhere;"+(role==="user"?"margin-left:auto;background:rgba(80,140,220,.18)":"margin-right:auto;background:rgba(130,130,130,.13)");
  item.innerHTML="<b>"+(role==="user"?"Sinä":"AI-avustaja")+"</b><div style='margin-top:4px'>"+safe(text)+"</div>";
  box.appendChild(item);box.scrollTop=box.scrollHeight;
 };
 const updateCount=()=>{count.textContent=history.length+" viestiä";};
 const getContext=()=>{
  const ids=["assetSelect","tdStatus","tvDataNotice","econSelectedAnalysis","econSelected","signalSummary","analysisSummary","indicatorSummary","signalStatus"];
  const parts=[];
  ids.forEach(id=>{const el=$(id);if(el){const t=(el.innerText||el.value||"").trim();if(t)parts.push(id+": "+t.slice(0,5000));}});
  const asset=$("assetSelect");if(asset)parts.unshift("Valittu instrumentti: "+(asset.selectedOptions?.[0]?.textContent||asset.value));
  const priceEls=[...document.querySelectorAll("[id*='price'],[id*='Price']")].slice(0,8);
  priceEls.forEach(el=>{const t=(el.innerText||"").trim();if(t&&t.length<100)parts.push(el.id+": "+t);});
  return parts.join("\n\n").slice(0,12000)||"Sovelluksen lisätietoja ei juuri nyt löytynyt. Pyydä käyttäjää tarkentamaan instrumentti tai tapahtuma.";
 };
 const setStatus=(t,bad=false)=>{status.textContent=t;status.style.borderColor=bad?"#c66":"var(--line,#555)";};
 $("goldAiChatSaveEndpoint").addEventListener("click",()=>{
  const v=endpoint.value.trim().replace(/\/+$/,"");
  if(!/^https?:\/\//i.test(v)){setStatus("Anna kelvollinen palvelimen https://-osoite.",true);return;}
  localStorage.setItem("goldAiChatEndpoint",v);endpoint.value=v;setStatus("Palvelimen osoite tallennettu tähän selaimeen.");
 });
 const call=async(messages)=>{
  const base=(localStorage.getItem("goldAiChatEndpoint")||endpoint.value.trim()).replace(/\/+$/,"");
  if(!base)throw new Error("AI-palvelimen osoite puuttuu. Avaa Yhteysasetukset ja lisää palvelimen /api/chat-osoite.");
  const response=await fetch(base,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({messages,context:getContext()})});
  const data=await response.json().catch(()=>({}));
  if(!response.ok)throw new Error(data.error||("Palvelin vastasi virhekoodilla "+response.status));
  if(!data.reply)throw new Error("Palvelin ei palauttanut vastaustekstiä.");
  return data.reply;
 };
 const test=async()=>{
  setStatus("Testataan AI-palvelimen yhteyttä…");
  try{const reply=await call([{role:"user",content:"Vastaa yhdellä sanalla: yhteys toimii."}]);setStatus("Yhteys toimii. AI vastasi: "+reply.slice(0,160));}
  catch(e){setStatus(e.message,true);}
 };
 $("goldAiChatTest").addEventListener("click",test);
 const submit=async()=>{
  const text=input.value.trim();if(!text)return;
  if(send.disabled)return;
  history.push({role:"user",content:text});add("user",text);input.value="";updateCount();send.disabled=true;send.textContent="…";
  const pending=document.createElement("div");pending.className="tiny";pending.textContent="AI miettii vastausta…";box.appendChild(pending);box.scrollTop=box.scrollHeight;
  try{
   const reply=await call(history.slice(-12));pending.remove();history.push({role:"assistant",content:reply});add("assistant",reply);updateCount();setStatus("AI-yhteys toimii.");
  }catch(e){pending.remove();history.pop();updateCount();setStatus(e.message,true);add("assistant","En saanut vastausta: "+e.message);}
  finally{send.disabled=false;send.textContent="Lähetä";input.focus();}
 };
 send.addEventListener("click",submit);
 input.addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();submit();}});
 $("goldAiChatClear").addEventListener("click",()=>{history=[];box.innerHTML="<div class='tiny'>Uusi keskustelu. Sovelluksen markkinatiedot välitetään tekoälylle jokaisen kysymyksen yhteydessä.</div>";updateCount();setStatus("Uusi keskustelu aloitettu.");});
 updateCount();
 if(saved)setStatus("Palvelimen osoite ladattu. Voit testata yhteyden.");
})();
