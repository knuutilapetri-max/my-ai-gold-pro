MY AI GOLD PRO Android Studio -projekti (v70)

Projektiversio 70.0. Tämä on natiivin Android-sovelluksen lähdeprojekti, ei vielä valmiiksi käännetty APK.
HTML-sovellus on pakattu sovelluksen sisään, joten käyttäjä avaa MY AI GOLD PRO:n Androidin sovellusvalikosta eikä selaimesta.

APK:n rakentaminen:
1. Avaa kansio Android Studiossa: File > Open.
2. Anna Android Studion synkronoida Gradle-projekti ja ladata riippuvuudet.
3. Valitse Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK löytyy yleensä: app/build/outputs/apk/debug/app-debug.apk.
5. Siirrä APK Android-puhelimeen ja asenna se. Android voi pyytää sallimaan tämän lähteen sovellusasennukset.

Huomioita:
- Tämä paketti ei sisällä allekirjoitettua julkaisu-APK:ta.
- Sovellus tarvitsee internet-yhteyden markkinadataa varten.
- AI-keskustelu tarvitsee edelleen suojatun palvelimen ja erillisen OpenAI API -laskutuksen.
- AI-palvelimen CORS-asetukseen on lisättävä alkuperä https://appassets.androidplatform.net.
- API-avainta ei saa lisätä index.html-tiedostoon tai APK:hon.
- Android Studio / Android SDK tarvitaan APK:n kääntämiseen.


VERSIO 70.0 - TALOUSKALENTERI AI-KESKUSTELUUN
- Unix-aikaleimat tunnistetaan sekä numeroina että numerojonoina (sekunnit/millisekunnit).
- Päivämäärät ilman kellonaikaa säilyttävät valitun kalenteripäivän.
- Päiväsuodatus muodostaa päivän Europe/Helsinki-aikavyöhykkeellä.
- Tyhjä tulos näyttää selkeän ilmoituksen.


Versio 70: AI-keskustelun kontekstiin liitetään sovelluksen ladatut XAUUSD/USD-vaikutukseen luokitellut taloustapahtumat. Mukana ovat tapahtuma-aika Suomen ajassa, vaikutusluokka, toteuma, ennuste, edellinen arvo, lähde ja sovelluksen sääntöpohjainen tulkinta. Jos kalenteritietoja ei ole ladattu, AI:lle välitetään tästä selkeä tieto eikä tapahtumia keksitä.

Versio 69: Finnhubin ulkoiset linkit avautuvat Androidin selaimessa. ENTRY-VAHTI näyttää Entry-alueen lisäksi SL:n sekä riskietäisyyteen perustuvat TP1-, TP2- ja TP3-hinnat BUY- ja SELL-vahdeille.


Projektin versionumerot: Android versionCode 70, versionName 70.0.
HTML-käyttöliittymän otsikko on päivitetty vastaamaan versiota 69.
