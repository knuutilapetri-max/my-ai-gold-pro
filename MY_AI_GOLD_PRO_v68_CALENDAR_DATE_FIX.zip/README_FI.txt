MY AI GOLD PRO Android Studio -projekti (v66)

Tämä on natiivin Android-sovelluksen lähdeprojekti, ei vielä valmiiksi käännetty APK.
HTML-sovellus on pakattu sovelluksen sisään, joten käyttäjä avaa MY AI GOLD PRO:n Androidin sovellusvalikosta eikä selaimesta.

APK:n rakentaminen:
1. Avaa kansio Android Studiossa: File > Open.
2. Anna Android Studion synkronoida Gradle-projekti ja ladata riippuvuudet.
3. Valitse Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK löytyy yleensä: app/build/outputs/apk/debug/app-debug.apk.
5. Siirrä APK Android-puhelimeen ja asenna se. Android voi pyytää sallimaan tämän lähteen sovellusasennukset.

Huomioita:
- Tämä paketti ei sisällä allekirjoitettua julkaisu-APK:ta.
- Sovellus tarvitsee internet-yhteyden markkinadataa varten.
- AI-keskustelu tarvitsee edelleen suojatun palvelimen ja erillisen OpenAI API -laskutuksen.
- AI-palvelimen CORS-asetukseen on lisättävä alkuperä https://appassets.androidplatform.net.
- API-avainta ei saa lisätä index.html-tiedostoon tai APK:hon.
- Android Studio / Android SDK tarvitaan APK:n kääntämiseen.


VERSIO 68.0 - KALENTERIN PÄIVÄSUODATUKSEN KORJAUS
- Unix-aikaleimat tunnistetaan sekä numeroina että numerojonoina (sekunnit/millisekunnit).
- Päivämäärät ilman kellonaikaa säilyttävät valitun kalenteripäivän.
- Päiväsuodatus muodostaa päivän Europe/Helsinki-aikavyöhykkeellä.
- Tyhjä tulos näyttää selkeän ilmoituksen.
