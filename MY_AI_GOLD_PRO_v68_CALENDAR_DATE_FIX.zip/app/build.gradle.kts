plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val releaseStoreFile = rootProject.file("release-key.jks")
val releaseStorePassword = System.getenv("ANDROID_KEYSTORE_PASSWORD")

android {
    namespace = "com.myaigoldpro.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.myaigoldpro.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 68
        versionName = "68.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    signingConfigs {
        create("release") {
            storeFile = releaseStoreFile
            storePassword = releaseStorePassword
            keyAlias = "my-ai-gold-pro"
            keyPassword = releaseStorePassword
        }
    }
    buildTypes {
        getByName("release") {
            signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = false
        }
    }
}

dependencies {
    implementation("androidx.webkit:webkit:1.12.1")
}
