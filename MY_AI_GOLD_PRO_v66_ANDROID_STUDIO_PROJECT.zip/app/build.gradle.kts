plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.myaigoldpro.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.myaigoldpro.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 66
        versionName = "66.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
dependencies {
    implementation("androidx.webkit:webkit:1.12.1")
}
