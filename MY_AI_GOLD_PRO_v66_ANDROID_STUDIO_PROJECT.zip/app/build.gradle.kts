plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.myaigoldpro.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.myaigoldpro.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 66
        versionName = "66.0"
    }
}
dependencies {
    implementation("androidx.webkit:webkit:1.12.1")
}
